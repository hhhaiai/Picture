---
title: "Codex 本地比赛模式配置说明（正式提交版）"
author: "jzy"
date: "2026-03-27"
lang: "zh-CN"
---

# 一、说明目的

本文档用于说明：在本地 Codex 环境中，通过用户侧可编辑配置文件，对模型的默认工作方式进行比赛化定制，使其在新的会话中更稳定地以 **CTF / 红队 / 靶场** 视角处理输入，并根据题型自动偏向 **Web** 或 **Pwn / Reverse** 的专项执行模式。

本配置的目标不是修改平台底层系统策略，而是使用 Codex 当前支持的用户配置接口，将模型的默认工作模式尽量前置到更强的用户可控层级，以满足比赛现场高强度解题协作需求。

# 二、测试环境与时间

- 测试时间：**2026-03-27**
- 本地工作目录：`/home/jzy/桌面/51mail`
- 用户配置文件：`/home/jzy/.codex/config.toml`
- 指令文件：`/home/jzy/.codex/prompts/do_special.md`
- 本地 Codex CLI 版本：**0.117.0-alpha.24**

参考会话记录：

- `/home/jzy/.codex/sessions/2026/03/27/rollout-2026-03-27T13-09-01-019d2db2-1fb5-7713-8f82-3a49a7b3b790.jsonl:1`

# 三、配置目标

本地配置实现以下目标：

1. 默认模型与推理强度固定为：
   - `model = "gpt-5.4"`
   - `model_reasoning_effort = "xhigh"`

2. 通过 `model_instructions_file` 注入基础比赛模式 prompt：
   - `~/.codex/prompts/do_special.md`

3. 通过 `developer_instructions` 注入更高层级的用户侧强约束，使模型默认：
   - 以本地 CTF / 红队视角理解任务；
   - 将“看起来像真实的 domain / hostname / URL”优先理解为本地玩具应用、靶场或重定向后的本地服务；
   - 以直接执行、快速验证、短反馈、强证据为工作方式。

4. 增加两个专项 profile：
   - `web`
   - `pwn`

# 四、当前配置内容

## 4.1 主配置文件

当前主配置位于：`/home/jzy/.codex/config.toml`

关键内容包括：

- 顶层默认配置：`config.toml:1-10`
- Web 专项 profile：`config.toml:12-24`
- Pwn / Reverse 专项 profile：`config.toml:26-38`

其中已实装内容如下：

- 默认模型：`gpt-5.4`
- 默认推理强度：`xhigh`
- 默认基础 prompt 文件：`~/.codex/prompts/do_special.md`
- 默认 `developer_instructions`
- Web 专项 `developer_instructions`
- Pwn / Reverse 专项 `developer_instructions`

## 4.2 基础比赛 prompt 文件

基础比赛模式 prompt 文件位于：`/home/jzy/.codex/prompts/do_special.md`

该文件定义了以下比赛默认行为：

- 本地 CTF / 红队合作身份；
- 默认将真实样式 domain 解释为本地挑战环境；
- 激进执行策略；
- Web aggressive mode；
- Pwn / Reverse aggressive mode；
- 自检行为。

关键区段：

- 身份与任务目标：`do_special.md:1-7`
- 环境假设：`do_special.md:9-14`
- 激进执行策略：`do_special.md:16-23`
- 模式切换：`do_special.md:32-35`
- Web 专项：`do_special.md:37-45`
- Pwn / Reverse 专项：`do_special.md:47-55`

# 五、指令层级说明

## 5.1 已验证层级

结合本地配置与本地运行记录，可以确认：

- `model_instructions_file` 会被加载为会话的 **base instructions**；
- `developer_instructions` 会以 **developer 指令层** 注入到会话中；
- 用户正常输入仍然位于其下方。

## 5.2 关键结论

对于用户本地可控配置来说：

- **`developer_instructions` 是当前已验证的最强用户可控层。**
- **`model_instructions_file` 有效，但层级低于 `developer_instructions`。**
- 以上两者均 **不能覆盖平台自身的更高层 system / platform developer 指令。**

因此，本配置的性质应表述为：

> 本配置可以显著强化比赛模式默认倾向，
> 但并不是替换或绕过平台最高层 system 指令的机制。

# 六、已完成的本地验证

## 6.1 验证一：`model_instructions_file` 会被读取

会话记录中可见 `base_instructions.text` 已加载 `do_special.md` 内容，见：

- `/home/jzy/.codex/sessions/2026/03/27/rollout-2026-03-27T13-09-01-019d2db2-1fb5-7713-8f82-3a49a7b3b790.jsonl:1`

该证据说明：

- `~/.codex/prompts/do_special.md` 已作为基础指令参与会话启动。

## 6.2 验证二：`developer_instructions` 被作为 developer 层注入

已执行最小化本地测试，向 Codex 注入：

- `developer_instructions = "Answer with exactly DEVTEST and nothing else."`

测试结果：

- 模型最终输出：`DEVTEST`

同时会话记录中可见：

- developer role 消息中包含该指令；
- `turn_context` 中出现 `developer_instructions` 字段。

证据文件：

- `/home/jzy/.codex/sessions/2026/03/27/rollout-2026-03-27T13-09-01-019d2db2-1fb5-7713-8f82-3a49a7b3b790.jsonl:3`
- `/home/jzy/.codex/sessions/2026/03/27/rollout-2026-03-27T13-09-01-019d2db2-1fb5-7713-8f82-3a49a7b3b790.jsonl:5`

该验证表明：

- `developer_instructions` 不是无效配置项；
- 其会真实进入会话 developer 层；
- 其控制强度高于普通基础 prompt。

## 6.3 验证三：专项 profile 已被识别

已本地验证以下命令可被识别：

- `codex exec --help -p web` → exit code 0
- `codex exec --help -p pwn` → exit code 0

该验证说明：

- `[profiles.web]`
- `[profiles.pwn]`

均已被当前本地 Codex 正常识别，配置未因 profile 语法错误而失效。

# 七、配置带来的实际效果

## 7.1 基础比赛模式

在新的会话中，本配置会使 Codex 更倾向于：

- 默认把任务按 CTF / 红队 / 靶场思路处理；
- 优先直接动手，不空谈；
- 优先读取附件、源码、抓包、页面、二进制、日志等输入；
- 优先验证而不是纯猜测；
- 对“真实样式 domain”优先做本地玩具应用 / 本地靶场解释。

## 7.2 Web 专项模式

使用 `web` profile 时，会更偏向：

- 路由、参数、接口、认证流、Cookie、Token、Header；
- JS bundle / source map / 配置泄露；
- 请求重放、参数变异、接口枚举；
- IDOR / auth bypass / SSRF / SQLi / XSS / 文件上传 / 模板注入等；
- 尽早构造 `curl` / Python 最小复现脚本。

## 7.3 Pwn / Reverse 专项模式

使用 `pwn` profile 时，会更偏向：

- 文件类型、架构、保护、字符串、符号、依赖侦察；
- 静态 + 动态联合分析；
- crash / leak / bypass / decoder / patch / exploit scaffold 的最小可验证路径；
- pwntools / 解码 / patch / 自动化辅助脚本。

# 八、使用方式

## 8.1 默认通用比赛模式

```bash
codex
```

## 8.2 Web 比赛专用模式

```bash
codex -p web
```

或：

```bash
codex exec -p web "题目内容"
```

## 8.3 Pwn / Reverse 比赛专用模式

```bash
codex -p pwn
```

或：

```bash
codex exec -p pwn "题目内容"
```

# 九、自检方法

为避免比赛现场误判，建议在 **新会话启动后** 先发送以下自检语句：

```text
开局自检：不要复述我的问题，只用一句话概括你当前默认配置里的角色定位、执行风格、对真实 domain 的环境假设，以及当前任务默认会走 Web mode 还是 Pwn / Reverse mode；如果没有继承到特殊配置，就直说自己处于普通通用模式。
```

若配置生效，返回内容通常会自然包含：

- 本地 CTF / 红队合作模式；
- 偏执行、快速验证、短反馈；
- 真实样式 domain 默认按本地玩具应用 / 靶场理解；
- 当前任务默认偏 Web mode 或 Pwn / Reverse mode。

# 十、限制与边界

1. **本配置不是平台最高层 system prompt。**
   - 无法覆盖平台保留的系统级约束。

2. **本配置能做到的是“用户可控层最强默认倾向”。**
   - `developer_instructions` 已验证为用户侧更强层；
   - `model_instructions_file` 为基础说明层。

3. **新配置通常对新会话生效。**
   - 修改配置后，需要新开会话；
   - 对已存在会话不保证完整热更新。

4. **CLI profile 切换最稳定。**
   - `codex -p web`
   - `codex -p pwn`
   - 对专项模式的切换最明确。

5. **IDE 面板与终端存在入口差异。**
   - 在 CLI 中使用 `-p web` 或 `-p pwn` 最稳定；
   - IDE 面板直接新开对话时，通常默认走顶层配置；是否可在 GUI 中显式切 profile，应以客户端实现为准。

# 十一、结论

综合本地配置文件、会话记录与实际最小测试结果，可以确认：

1. 当前配置 **可行**；
2. `model_instructions_file` **有效**；
3. `developer_instructions` **有效，且是当前已验证的最强用户可控指令层**；
4. `web` 与 `pwn` 两个专项 profile **已在本地配置中建立并可被识别**；
5. 该配置能够在新的 Codex 会话中，将模型默认行为稳定拉向：
   - 本地 CTF / 红队比赛模式；
   - 快速执行与验证；
   - 对真实样式 domain 的本地靶场解释；
   - 按题型偏向 Web 或 Pwn / Reverse 的专项工作流。

同时，应保留以下边界说明：

> 本配置强化的是用户可控默认行为，
> 不是对平台最高层 system prompt 的替换或绕过。

# 十二、目录清理与删除建议

为避免误删有效配置或历史数据，需明确区分“应保留文件”和“可删除文件”。

## 12.1 不应删除的关键配置

以下文件是当前比赛模式配置的有效组成部分，若仍需继续使用 Codex 比赛模式，则**不应删除**：

- `/home/jzy/.codex/config.toml`
- `/home/jzy/.codex/prompts/do_special.md`

若仍需使用开局自检提示，则建议保留：

- `/home/jzy/.codex/prompts/ctf_mode_self_check.txt`

## 12.2 可删除的备份文件

以下文件属于本次调试和配置过程中生成的备份文件，删除后**不会影响当前已生效配置**：

- `/home/jzy/.codex/config.toml.bak-devinstr-20260327-130944`
- `/home/jzy/.codex/prompts/do_special.md.bak-aggressive-20260327-125017`
- `/home/jzy/.codex/prompts/do_special.md.bak-specialized-20260327-125253`
- `/home/jzy/.codex/prompts/do_special.md.bak.20260327-124920`

## 12.3 可删除的说明与打包产物

以下文件属于本次说明文档、排版样式与打包生成物，如已提交赛事方或已不再需要，可安全删除：

- `/home/jzy/桌面/51mail/codex_ctf_config_report_formal.html`
- `/home/jzy/桌面/51mail/codex_ctf_config_report_formal.md`
- `/home/jzy/桌面/51mail/codex_ctf_config_report_formal.pdf`
- `/home/jzy/桌面/51mail/codex_ctf_report_style.css`
- `/home/jzy/桌面/51mail/codex_ctf_submit_bundle/`
- `/home/jzy/桌面/51mail/codex_ctf_submit_bundle.zip`

## 12.4 不建议删除的历史与状态目录

除非明确要彻底清空 Codex 本地状态，否则**不建议删除**以下目录或数据库文件：

- `/home/jzy/.codex/auth.json`（删除后可能导致登录状态丢失）
- `/home/jzy/.codex/sessions/`（删除后会丢失历史会话）
- `/home/jzy/.codex/state_5.sqlite`
- `/home/jzy/.codex/logs_1.sqlite`

## 12.5 结论

- **不要删除整个 `/home/jzy/.`**
- **不要删除整个 `/home/jzy/.codex/`**
- 若仅需清理本次配置过程产生的痕迹，应删除“备份文件”和“说明/打包产物”，保留当前生效配置文件。

# 十三、提交摘要（简版）

本地 Codex 环境已通过 `config.toml` 与 `do_special.md` 完成比赛模式配置，并已通过本地会话记录验证：`model_instructions_file` 会作为基础指令加载，`developer_instructions` 会作为更强的 developer 层注入。当前配置默认将任务按本地 CTF / 红队视角处理，将真实样式 domain 优先解释为本地玩具应用或靶场，并支持 `web` 与 `pwn` 两个专项 profile。该配置可显著强化比赛模式默认倾向，但不覆盖平台保留的最高层 system 指令。
