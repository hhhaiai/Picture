#include "sys.h"
#include "led.h"
#include "delay.h"
#include "usart.h"

char temp[3]={1,2,3};

void function(char *value)
{
	printf("value0 = %d\r\n",value[0]);
	printf("value1 = %d\r\n",value[1]);
	printf("value2 = %d\r\n",value[2]);
}
int main(void)
{	
	uart_init(115200);//���ڳ�ʼ��
	delay_init();
	
	function(temp);

    while(1)
	{	
	}	
}

