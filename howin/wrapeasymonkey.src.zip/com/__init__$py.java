import org.python.compiler.APIVersion;
import org.python.compiler.MTime;
import org.python.core.CodeBootstrap;
import org.python.core.CodeLoader;
import org.python.core.Py;
import org.python.core.PyCode;
import org.python.core.PyFrame;
import org.python.core.PyFunctionTable;
import org.python.core.PyObject;
import org.python.core.PyRunnable;
import org.python.core.PyRunnableBootstrap;
import org.python.core.PyString;
import org.python.core.ThreadState;

@APIVersion(33)
@MTime(1350637791000L)
public class com$py
  extends PyFunctionTable
  implements PyRunnable
{
  static py self;
  static final PyString _0;
  static final PyCode f$0;
  
  public PyObject f$0(PyFrame paramPyFrame, ThreadState paramThreadState)
  {
    paramPyFrame.f_lasti = -1;
    return Py.None;
  }
  
  public com$py(String paramString)
  {
    self = this;
    _0 = PyString.fromInterned("/root/android-sdk-linux/tools/lib/wrapEasyMonkey/src/com/__init__.py");
    String[] arrayOfString = new String[0];
    f$0 = Py.newCode(0, arrayOfString, paramString, "<module>", 0, false, false, self, 0, null, null, 0, 4096);
  }
  
  public PyCode getMain()
  {
    return f$0;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Py.runMain(CodeLoader.createSimpleBootstrap(new py("com$py").getMain()), paramArrayOfString);
  }
  
  public static CodeBootstrap getCodeBootstrap()
  {
    return PyRunnableBootstrap.getFilenameConstructorReflectionBootstrap(py.class);
  }
  
  public PyObject call_function(int paramInt, PyFrame paramPyFrame, ThreadState paramThreadState)
  {
    switch (paramInt)
    {
    case 0: 
      return f$0(paramPyFrame, paramThreadState);
    }
    return null;
  }
}


/* Location:           E:\docs\1\wrapeasymonkey.jar
 * Qualified Name:     com.__init__.py
 * JD-Core Version:    0.7.0.1
 */