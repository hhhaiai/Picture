# mdout-theme-github

mdout默认主题，改自仿github主题。

支持MathJax数学公式、Mermaid流程图、Highlight.js语法高亮。

可以通过 [示例站点预览](https://preview-mdout-theme-github.vercel.app/) 主题效果。