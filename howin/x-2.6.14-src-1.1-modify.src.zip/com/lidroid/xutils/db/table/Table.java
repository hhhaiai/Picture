/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.DbUtils;
/*   5:    */ import com.lidroid.xutils.DbUtils.DaoConfig;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ 
/*   9:    */ public class Table
/*  10:    */ {
/*  11:    */   public final DbUtils db;
/*  12:    */   public final String tableName;
/*  13:    */   public final Id id;
/*  14:    */   public final HashMap<String, Column> columnMap;
/*  15:    */   public final HashMap<String, Finder> finderMap;
/*  16: 44 */   private static final HashMap<String, Table> tableMap = new HashMap();
/*  17:    */   private boolean checkedDatabase;
/*  18:    */   
/*  19:    */   private Table(DbUtils db, Class<?> entityType)
/*  20:    */   {
/*  21: 48 */     this.db = db;
/*  22: 49 */     this.tableName = TableUtils.getTableName(entityType);
/*  23: 50 */     this.id = TableUtils.getId(entityType);
/*  24: 51 */     this.columnMap = TableUtils.getColumnMap(entityType);
/*  25:    */     
/*  26: 53 */     this.finderMap = new HashMap();
/*  27: 54 */     for (Column column : this.columnMap.values())
/*  28:    */     {
/*  29: 56 */       column.setTable(this);
/*  30: 57 */       if ((column instanceof Finder)) {
/*  31: 59 */         this.finderMap.put(column.getColumnName(), (Finder)column);
/*  32:    */       }
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static synchronized Table get(DbUtils db, Class<?> entityType)
/*  37:    */   {
/*  38: 66 */     String tableKey = db.getDaoConfig().getDbName() + "#" + entityType.getName();
/*  39: 67 */     Table table = (Table)tableMap.get(tableKey);
/*  40: 68 */     if (table == null)
/*  41:    */     {
/*  42: 70 */       table = new Table(db, entityType);
/*  43: 71 */       tableMap.put(tableKey, table);
/*  44:    */     }
/*  45: 74 */     return table;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static synchronized void remove(DbUtils db, Class<?> entityType)
/*  49:    */   {
/*  50: 79 */     String tableKey = db.getDaoConfig().getDbName() + "#" + entityType.getName();
/*  51: 80 */     tableMap.remove(tableKey);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static synchronized void remove(DbUtils db, String tableName)
/*  55:    */   {
/*  56: 85 */     if (tableMap.size() > 0)
/*  57:    */     {
/*  58: 87 */       String key = null;
/*  59: 88 */       for (Map.Entry<String, Table> entry : tableMap.entrySet())
/*  60:    */       {
/*  61: 90 */         Table table = (Table)entry.getValue();
/*  62: 91 */         if ((table != null) && (table.tableName.equals(tableName)))
/*  63:    */         {
/*  64: 93 */           key = (String)entry.getKey();
/*  65: 94 */           if (key.startsWith(db.getDaoConfig().getDbName() + "#")) {
/*  66:    */             break;
/*  67:    */           }
/*  68:    */         }
/*  69:    */       }
/*  70:100 */       if (TextUtils.isEmpty(key)) {
/*  71:102 */         tableMap.remove(key);
/*  72:    */       }
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isCheckedDatabase()
/*  77:    */   {
/*  78:111 */     return this.checkedDatabase;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setCheckedDatabase(boolean checkedDatabase)
/*  82:    */   {
/*  83:116 */     this.checkedDatabase = checkedDatabase;
/*  84:    */   }
/*  85:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.Table
 * JD-Core Version:    0.7.0.1
 */