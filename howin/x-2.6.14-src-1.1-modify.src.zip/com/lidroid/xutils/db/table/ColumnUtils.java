/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.db.annotation.Check;
/*   5:    */ import com.lidroid.xutils.db.annotation.Column;
/*   6:    */ import com.lidroid.xutils.db.annotation.Id;
/*   7:    */ import com.lidroid.xutils.db.annotation.NotNull;
/*   8:    */ import com.lidroid.xutils.db.annotation.Transient;
/*   9:    */ import com.lidroid.xutils.db.annotation.Unique;
/*  10:    */ import com.lidroid.xutils.db.converter.ColumnConverter;
/*  11:    */ import com.lidroid.xutils.db.converter.ColumnConverterFactory;
/*  12:    */ import com.lidroid.xutils.db.sqlite.FinderLazyLoader;
/*  13:    */ import com.lidroid.xutils.db.sqlite.ForeignLazyLoader;
/*  14:    */ import com.lidroid.xutils.util.LogUtils;
/*  15:    */ import java.lang.reflect.Field;
/*  16:    */ import java.lang.reflect.Method;
/*  17:    */ import java.util.HashSet;
/*  18:    */ import java.util.List;
/*  19:    */ 
/*  20:    */ public class ColumnUtils
/*  21:    */ {
/*  22: 43 */   private static final HashSet<String> DB_PRIMITIVE_TYPES = new HashSet(14);
/*  23:    */   
/*  24:    */   static
/*  25:    */   {
/*  26: 47 */     DB_PRIMITIVE_TYPES.add(Integer.TYPE.getName());
/*  27: 48 */     DB_PRIMITIVE_TYPES.add(Long.TYPE.getName());
/*  28: 49 */     DB_PRIMITIVE_TYPES.add(Short.TYPE.getName());
/*  29: 50 */     DB_PRIMITIVE_TYPES.add(Byte.TYPE.getName());
/*  30: 51 */     DB_PRIMITIVE_TYPES.add(Float.TYPE.getName());
/*  31: 52 */     DB_PRIMITIVE_TYPES.add(Double.TYPE.getName());
/*  32:    */     
/*  33: 54 */     DB_PRIMITIVE_TYPES.add(Integer.class.getName());
/*  34: 55 */     DB_PRIMITIVE_TYPES.add(Long.class.getName());
/*  35: 56 */     DB_PRIMITIVE_TYPES.add(Short.class.getName());
/*  36: 57 */     DB_PRIMITIVE_TYPES.add(Byte.class.getName());
/*  37: 58 */     DB_PRIMITIVE_TYPES.add(Float.class.getName());
/*  38: 59 */     DB_PRIMITIVE_TYPES.add(Double.class.getName());
/*  39: 60 */     DB_PRIMITIVE_TYPES.add(String.class.getName());
/*  40: 61 */     DB_PRIMITIVE_TYPES.add([B.class.getName());
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static boolean isDbPrimitiveType(Class<?> fieldType)
/*  44:    */   {
/*  45: 66 */     return DB_PRIMITIVE_TYPES.contains(fieldType.getName());
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static Method getColumnGetMethod(Class<?> entityType, Field field)
/*  49:    */   {
/*  50: 71 */     String fieldName = field.getName();
/*  51: 72 */     Method getMethod = null;
/*  52: 73 */     if (field.getType() == Boolean.TYPE) {
/*  53: 75 */       getMethod = getBooleanColumnGetMethod(entityType, fieldName);
/*  54:    */     }
/*  55: 77 */     if (getMethod == null)
/*  56:    */     {
/*  57: 79 */       String methodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/*  58:    */       try
/*  59:    */       {
/*  60: 82 */         getMethod = entityType.getDeclaredMethod(methodName, new Class[0]);
/*  61:    */       }
/*  62:    */       catch (NoSuchMethodException e)
/*  63:    */       {
/*  64: 85 */         LogUtils.d(methodName + " not exist");
/*  65:    */       }
/*  66:    */     }
/*  67: 89 */     if ((getMethod == null) && (!Object.class.equals(entityType.getSuperclass()))) {
/*  68: 91 */       return getColumnGetMethod(entityType.getSuperclass(), field);
/*  69:    */     }
/*  70: 93 */     return getMethod;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static Method getColumnSetMethod(Class<?> entityType, Field field)
/*  74:    */   {
/*  75: 98 */     String fieldName = field.getName();
/*  76: 99 */     Method setMethod = null;
/*  77:100 */     if (field.getType() == Boolean.TYPE) {
/*  78:102 */       setMethod = getBooleanColumnSetMethod(entityType, field);
/*  79:    */     }
/*  80:104 */     if (setMethod == null)
/*  81:    */     {
/*  82:106 */       String methodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/*  83:    */       try
/*  84:    */       {
/*  85:109 */         setMethod = entityType.getDeclaredMethod(methodName, new Class[] { field.getType() });
/*  86:    */       }
/*  87:    */       catch (NoSuchMethodException e)
/*  88:    */       {
/*  89:112 */         LogUtils.d(methodName + " not exist");
/*  90:    */       }
/*  91:    */     }
/*  92:116 */     if ((setMethod == null) && (!Object.class.equals(entityType.getSuperclass()))) {
/*  93:118 */       return getColumnSetMethod(entityType.getSuperclass(), field);
/*  94:    */     }
/*  95:120 */     return setMethod;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static String getColumnNameByField(Field field)
/*  99:    */   {
/* 100:125 */     Column column = (Column)field.getAnnotation(Column.class);
/* 101:126 */     if ((column != null) && (!TextUtils.isEmpty(column.column()))) {
/* 102:128 */       return column.column();
/* 103:    */     }
/* 104:131 */     Id id = (Id)field.getAnnotation(Id.class);
/* 105:132 */     if ((id != null) && (!TextUtils.isEmpty(id.column()))) {
/* 106:134 */       return id.column();
/* 107:    */     }
/* 108:137 */     com.lidroid.xutils.db.annotation.Foreign foreign = (com.lidroid.xutils.db.annotation.Foreign)field.getAnnotation(com.lidroid.xutils.db.annotation.Foreign.class);
/* 109:138 */     if ((foreign != null) && (!TextUtils.isEmpty(foreign.column()))) {
/* 110:140 */       return foreign.column();
/* 111:    */     }
/* 112:143 */     com.lidroid.xutils.db.annotation.Finder finder = (com.lidroid.xutils.db.annotation.Finder)field.getAnnotation(com.lidroid.xutils.db.annotation.Finder.class);
/* 113:144 */     if (finder != null) {
/* 114:146 */       return field.getName();
/* 115:    */     }
/* 116:149 */     return field.getName();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static String getForeignColumnNameByField(Field field)
/* 120:    */   {
/* 121:155 */     com.lidroid.xutils.db.annotation.Foreign foreign = (com.lidroid.xutils.db.annotation.Foreign)field.getAnnotation(com.lidroid.xutils.db.annotation.Foreign.class);
/* 122:156 */     if (foreign != null) {
/* 123:158 */       return foreign.foreign();
/* 124:    */     }
/* 125:161 */     return field.getName();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static String getColumnDefaultValue(Field field)
/* 129:    */   {
/* 130:166 */     Column column = (Column)field.getAnnotation(Column.class);
/* 131:167 */     if ((column != null) && (!TextUtils.isEmpty(column.defaultValue()))) {
/* 132:169 */       return column.defaultValue();
/* 133:    */     }
/* 134:171 */     return null;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static boolean isTransient(Field field)
/* 138:    */   {
/* 139:176 */     return field.getAnnotation(Transient.class) != null;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static boolean isForeign(Field field)
/* 143:    */   {
/* 144:181 */     return field.getAnnotation(com.lidroid.xutils.db.annotation.Foreign.class) != null;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static boolean isFinder(Field field)
/* 148:    */   {
/* 149:186 */     return field.getAnnotation(com.lidroid.xutils.db.annotation.Finder.class) != null;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static boolean isUnique(Field field)
/* 153:    */   {
/* 154:191 */     return field.getAnnotation(Unique.class) != null;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static boolean isNotNull(Field field)
/* 158:    */   {
/* 159:196 */     return field.getAnnotation(NotNull.class) != null;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static String getCheck(Field field)
/* 163:    */   {
/* 164:205 */     Check check = (Check)field.getAnnotation(Check.class);
/* 165:206 */     if (check != null) {
/* 166:208 */       return check.value();
/* 167:    */     }
/* 168:211 */     return null;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static Class<?> getForeignEntityType(Foreign foreignColumn)
/* 172:    */   {
/* 173:218 */     Class<?> result = foreignColumn.getColumnField().getType();
/* 174:219 */     if ((result.equals(ForeignLazyLoader.class)) || (result.equals(List.class))) {
/* 175:221 */       result = (Class)((java.lang.reflect.ParameterizedType)foreignColumn.getColumnField().getGenericType()).getActualTypeArguments()[0];
/* 176:    */     }
/* 177:223 */     return result;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static Class<?> getFinderTargetEntityType(Finder finderColumn)
/* 181:    */   {
/* 182:229 */     Class<?> result = finderColumn.getColumnField().getType();
/* 183:230 */     if ((result.equals(FinderLazyLoader.class)) || (result.equals(List.class))) {
/* 184:232 */       result = (Class)((java.lang.reflect.ParameterizedType)finderColumn.getColumnField().getGenericType()).getActualTypeArguments()[0];
/* 185:    */     }
/* 186:234 */     return result;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public static Object convert2DbColumnValueIfNeeded(Object value)
/* 190:    */   {
/* 191:240 */     Object result = value;
/* 192:241 */     if (value != null)
/* 193:    */     {
/* 194:243 */       Class<?> valueType = value.getClass();
/* 195:244 */       if (!isDbPrimitiveType(valueType))
/* 196:    */       {
/* 197:246 */         ColumnConverter converter = ColumnConverterFactory.getColumnConverter(valueType);
/* 198:247 */         if (converter != null) {
/* 199:249 */           result = converter.fieldValue2ColumnValue(value);
/* 200:    */         } else {
/* 201:252 */           result = value;
/* 202:    */         }
/* 203:    */       }
/* 204:    */     }
/* 205:256 */     return result;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private static boolean isStartWithIs(String fieldName)
/* 209:    */   {
/* 210:261 */     return (fieldName != null) && (fieldName.startsWith("is"));
/* 211:    */   }
/* 212:    */   
/* 213:    */   private static Method getBooleanColumnGetMethod(Class<?> entityType, String fieldName)
/* 214:    */   {
/* 215:266 */     String methodName = "is" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/* 216:267 */     if (isStartWithIs(fieldName)) {
/* 217:269 */       methodName = fieldName;
/* 218:    */     }
/* 219:    */     try
/* 220:    */     {
/* 221:273 */       return entityType.getDeclaredMethod(methodName, new Class[0]);
/* 222:    */     }
/* 223:    */     catch (NoSuchMethodException e)
/* 224:    */     {
/* 225:276 */       LogUtils.d(methodName + " not exist");
/* 226:    */     }
/* 227:278 */     return null;
/* 228:    */   }
/* 229:    */   
/* 230:    */   private static Method getBooleanColumnSetMethod(Class<?> entityType, Field field)
/* 231:    */   {
/* 232:283 */     String fieldName = field.getName();
/* 233:284 */     String methodName = null;
/* 234:285 */     if (isStartWithIs(field.getName())) {
/* 235:287 */       methodName = "set" + fieldName.substring(2, 3).toUpperCase() + fieldName.substring(3);
/* 236:    */     } else {
/* 237:290 */       methodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
/* 238:    */     }
/* 239:    */     try
/* 240:    */     {
/* 241:294 */       return entityType.getDeclaredMethod(methodName, new Class[] { field.getType() });
/* 242:    */     }
/* 243:    */     catch (NoSuchMethodException e)
/* 244:    */     {
/* 245:297 */       LogUtils.d(methodName + " not exist");
/* 246:    */     }
/* 247:299 */     return null;
/* 248:    */   }
/* 249:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.ColumnUtils
 * JD-Core Version:    0.7.0.1
 */