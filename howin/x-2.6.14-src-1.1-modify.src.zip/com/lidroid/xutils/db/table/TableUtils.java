/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.db.annotation.Table;
/*   5:    */ import com.lidroid.xutils.db.converter.ColumnConverterFactory;
/*   6:    */ import com.lidroid.xutils.util.LogUtils;
/*   7:    */ import java.lang.reflect.Field;
/*   8:    */ import java.lang.reflect.Modifier;
/*   9:    */ import java.util.HashMap;
/*  10:    */ import java.util.concurrent.ConcurrentHashMap;
/*  11:    */ 
/*  12:    */ public class TableUtils
/*  13:    */ {
/*  14:    */   public static String getTableName(Class<?> entityType)
/*  15:    */   {
/*  16: 38 */     Table table = (Table)entityType.getAnnotation(Table.class);
/*  17: 39 */     if ((table == null) || (TextUtils.isEmpty(table.name()))) {
/*  18: 41 */       return entityType.getName().replace('.', '_');
/*  19:    */     }
/*  20: 43 */     return table.name();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static String getExecAfterTableCreated(Class<?> entityType)
/*  24:    */   {
/*  25: 48 */     Table table = (Table)entityType.getAnnotation(Table.class);
/*  26: 49 */     if (table != null) {
/*  27: 51 */       return table.execAfterTableCreated();
/*  28:    */     }
/*  29: 53 */     return null;
/*  30:    */   }
/*  31:    */   
/*  32: 59 */   private static ConcurrentHashMap<String, HashMap<String, Column>> entityColumnsMap = new ConcurrentHashMap();
/*  33:    */   
/*  34:    */   static synchronized HashMap<String, Column> getColumnMap(Class<?> entityType)
/*  35:    */   {
/*  36: 65 */     if (entityColumnsMap.containsKey(entityType.getName())) {
/*  37: 67 */       return (HashMap)entityColumnsMap.get(entityType.getName());
/*  38:    */     }
/*  39: 70 */     HashMap<String, Column> columnMap = new HashMap();
/*  40: 71 */     String primaryKeyFieldName = getPrimaryKeyFieldName(entityType);
/*  41: 72 */     addColumns2Map(entityType, primaryKeyFieldName, columnMap);
/*  42: 73 */     entityColumnsMap.put(entityType.getName(), columnMap);
/*  43:    */     
/*  44: 75 */     return columnMap;
/*  45:    */   }
/*  46:    */   
/*  47:    */   private static void addColumns2Map(Class<?> entityType, String primaryKeyFieldName, HashMap<String, Column> columnMap)
/*  48:    */   {
/*  49: 80 */     if (Object.class.equals(entityType)) {
/*  50: 81 */       return;
/*  51:    */     }
/*  52:    */     try
/*  53:    */     {
/*  54: 84 */       Field[] fields = entityType.getDeclaredFields();
/*  55: 85 */       for (Field field : fields) {
/*  56: 87 */         if ((!ColumnUtils.isTransient(field)) && (!Modifier.isStatic(field.getModifiers()))) {
/*  57: 91 */           if (ColumnConverterFactory.isSupportColumnConverter(field.getType()))
/*  58:    */           {
/*  59: 93 */             if (!field.getName().equals(primaryKeyFieldName))
/*  60:    */             {
/*  61: 95 */               Column column = new Column(entityType, field);
/*  62: 96 */               if (!columnMap.containsKey(column.getColumnName())) {
/*  63: 98 */                 columnMap.put(column.getColumnName(), column);
/*  64:    */               }
/*  65:    */             }
/*  66:    */           }
/*  67:101 */           else if (ColumnUtils.isForeign(field))
/*  68:    */           {
/*  69:103 */             Foreign column = new Foreign(entityType, field);
/*  70:104 */             if (!columnMap.containsKey(column.getColumnName())) {
/*  71:106 */               columnMap.put(column.getColumnName(), column);
/*  72:    */             }
/*  73:    */           }
/*  74:108 */           else if (ColumnUtils.isFinder(field))
/*  75:    */           {
/*  76:110 */             Finder column = new Finder(entityType, field);
/*  77:111 */             if (!columnMap.containsKey(column.getColumnName())) {
/*  78:113 */               columnMap.put(column.getColumnName(), column);
/*  79:    */             }
/*  80:    */           }
/*  81:    */         }
/*  82:    */       }
/*  83:118 */       if (!Object.class.equals(entityType.getSuperclass())) {
/*  84:120 */         addColumns2Map(entityType.getSuperclass(), primaryKeyFieldName, columnMap);
/*  85:    */       }
/*  86:    */     }
/*  87:    */     catch (Throwable e)
/*  88:    */     {
/*  89:124 */       LogUtils.e(e.getMessage(), e);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   static Column getColumnOrId(Class<?> entityType, String columnName)
/*  94:    */   {
/*  95:131 */     if (getPrimaryKeyColumnName(entityType).equals(columnName)) {
/*  96:133 */       return getId(entityType);
/*  97:    */     }
/*  98:135 */     return (Column)getColumnMap(entityType).get(columnName);
/*  99:    */   }
/* 100:    */   
/* 101:141 */   private static ConcurrentHashMap<String, Id> entityIdMap = new ConcurrentHashMap();
/* 102:    */   
/* 103:    */   static synchronized Id getId(Class<?> entityType)
/* 104:    */   {
/* 105:146 */     if (Object.class.equals(entityType)) {
/* 106:148 */       throw new RuntimeException("field 'id' not found");
/* 107:    */     }
/* 108:151 */     if (entityIdMap.containsKey(entityType.getName())) {
/* 109:153 */       return (Id)entityIdMap.get(entityType.getName());
/* 110:    */     }
/* 111:156 */     Field primaryKeyField = null;
/* 112:157 */     Field[] fields = entityType.getDeclaredFields();
/* 113:158 */     if (fields != null)
/* 114:    */     {
/* 115:161 */       for (Field field : fields) {
/* 116:163 */         if (field.getAnnotation(com.lidroid.xutils.db.annotation.Id.class) != null)
/* 117:    */         {
/* 118:165 */           primaryKeyField = field;
/* 119:166 */           break;
/* 120:    */         }
/* 121:    */       }
/* 122:170 */       if (primaryKeyField == null) {
/* 123:172 */         for (Field field : fields) {
/* 124:174 */           if (("id".equals(field.getName())) || ("_id".equals(field.getName())))
/* 125:    */           {
/* 126:176 */             primaryKeyField = field;
/* 127:177 */             break;
/* 128:    */           }
/* 129:    */         }
/* 130:    */       }
/* 131:    */     }
/* 132:183 */     if (primaryKeyField == null) {
/* 133:185 */       return getId(entityType.getSuperclass());
/* 134:    */     }
/* 135:188 */     Id id = new Id(entityType, primaryKeyField);
/* 136:189 */     entityIdMap.put(entityType.getName(), id);
/* 137:190 */     return id;
/* 138:    */   }
/* 139:    */   
/* 140:    */   private static String getPrimaryKeyFieldName(Class<?> entityType)
/* 141:    */   {
/* 142:195 */     Id id = getId(entityType);
/* 143:196 */     return id == null ? null : id.getColumnField().getName();
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static String getPrimaryKeyColumnName(Class<?> entityType)
/* 147:    */   {
/* 148:201 */     Id id = getId(entityType);
/* 149:202 */     return id == null ? null : id.getColumnName();
/* 150:    */   }
/* 151:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.TableUtils
 * JD-Core Version:    0.7.0.1
 */