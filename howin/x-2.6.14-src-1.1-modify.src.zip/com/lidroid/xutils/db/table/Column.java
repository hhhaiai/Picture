/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import com.lidroid.xutils.db.converter.ColumnConverter;
/*   5:    */ import com.lidroid.xutils.db.converter.ColumnConverterFactory;
/*   6:    */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*   7:    */ import com.lidroid.xutils.util.LogUtils;
/*   8:    */ import java.lang.reflect.Field;
/*   9:    */ import java.lang.reflect.Method;
/*  10:    */ 
/*  11:    */ public class Column
/*  12:    */ {
/*  13:    */   private Table table;
/*  14: 32 */   private int index = -1;
/*  15:    */   protected final String columnName;
/*  16:    */   private final Object defaultValue;
/*  17:    */   protected final Method getMethod;
/*  18:    */   protected final Method setMethod;
/*  19:    */   protected final Field columnField;
/*  20:    */   protected final ColumnConverter columnConverter;
/*  21:    */   
/*  22:    */   Column(Class<?> entityType, Field field)
/*  23:    */   {
/*  24: 45 */     this.columnField = field;
/*  25: 46 */     this.columnConverter = ColumnConverterFactory.getColumnConverter(field.getType());
/*  26: 47 */     this.columnName = ColumnUtils.getColumnNameByField(field);
/*  27: 48 */     if (this.columnConverter != null) {
/*  28: 50 */       this.defaultValue = this.columnConverter.getFieldValue(ColumnUtils.getColumnDefaultValue(field));
/*  29:    */     } else {
/*  30: 53 */       this.defaultValue = null;
/*  31:    */     }
/*  32: 55 */     this.getMethod = ColumnUtils.getColumnGetMethod(entityType, field);
/*  33: 56 */     this.setMethod = ColumnUtils.getColumnSetMethod(entityType, field);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void setValue2Entity(Object entity, Cursor cursor, int index)
/*  37:    */   {
/*  38: 62 */     this.index = index;
/*  39: 63 */     Object value = this.columnConverter.getFieldValue(cursor, index);
/*  40: 64 */     if ((value == null) && (this.defaultValue == null)) {
/*  41: 65 */       return;
/*  42:    */     }
/*  43: 67 */     if (this.setMethod != null) {
/*  44:    */       try
/*  45:    */       {
/*  46: 71 */         this.setMethod.invoke(entity, new Object[] { value == null ? this.defaultValue : value });
/*  47:    */       }
/*  48:    */       catch (Throwable e)
/*  49:    */       {
/*  50: 74 */         LogUtils.e(e.getMessage(), e);
/*  51:    */       }
/*  52:    */     } else {
/*  53:    */       try
/*  54:    */       {
/*  55: 80 */         this.columnField.setAccessible(true);
/*  56: 81 */         this.columnField.set(entity, value == null ? this.defaultValue : value);
/*  57:    */       }
/*  58:    */       catch (Throwable e)
/*  59:    */       {
/*  60: 84 */         LogUtils.e(e.getMessage(), e);
/*  61:    */       }
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Object getColumnValue(Object entity)
/*  66:    */   {
/*  67: 92 */     Object fieldValue = getFieldValue(entity);
/*  68: 93 */     return this.columnConverter.fieldValue2ColumnValue(fieldValue);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Object getFieldValue(Object entity)
/*  72:    */   {
/*  73: 98 */     Object fieldValue = null;
/*  74: 99 */     if (entity != null) {
/*  75:101 */       if (this.getMethod != null) {
/*  76:    */         try
/*  77:    */         {
/*  78:105 */           fieldValue = this.getMethod.invoke(entity, new Object[0]);
/*  79:    */         }
/*  80:    */         catch (Throwable e)
/*  81:    */         {
/*  82:108 */           LogUtils.e(e.getMessage(), e);
/*  83:    */         }
/*  84:    */       } else {
/*  85:    */         try
/*  86:    */         {
/*  87:114 */           this.columnField.setAccessible(true);
/*  88:115 */           fieldValue = this.columnField.get(entity);
/*  89:    */         }
/*  90:    */         catch (Throwable e)
/*  91:    */         {
/*  92:118 */           LogUtils.e(e.getMessage(), e);
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:122 */     return fieldValue;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Table getTable()
/* 100:    */   {
/* 101:127 */     return this.table;
/* 102:    */   }
/* 103:    */   
/* 104:    */   void setTable(Table table)
/* 105:    */   {
/* 106:132 */     this.table = table;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int getIndex()
/* 110:    */   {
/* 111:142 */     return this.index;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public String getColumnName()
/* 115:    */   {
/* 116:147 */     return this.columnName;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Object getDefaultValue()
/* 120:    */   {
/* 121:152 */     return this.defaultValue;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public Field getColumnField()
/* 125:    */   {
/* 126:157 */     return this.columnField;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public ColumnConverter getColumnConverter()
/* 130:    */   {
/* 131:162 */     return this.columnConverter;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public ColumnDbType getColumnDbType()
/* 135:    */   {
/* 136:167 */     return this.columnConverter.getColumnDbType();
/* 137:    */   }
/* 138:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.Column
 * JD-Core Version:    0.7.0.1
 */