/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import com.lidroid.xutils.DbUtils;
/*   5:    */ import com.lidroid.xutils.db.converter.ColumnConverter;
/*   6:    */ import com.lidroid.xutils.db.converter.ColumnConverterFactory;
/*   7:    */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*   8:    */ import com.lidroid.xutils.db.sqlite.ForeignLazyLoader;
/*   9:    */ import com.lidroid.xutils.exception.DbException;
/*  10:    */ import com.lidroid.xutils.util.LogUtils;
/*  11:    */ import java.lang.reflect.Field;
/*  12:    */ import java.lang.reflect.Method;
/*  13:    */ import java.util.List;
/*  14:    */ 
/*  15:    */ public class Foreign
/*  16:    */   extends Column
/*  17:    */ {
/*  18:    */   private final String foreignColumnName;
/*  19:    */   private final ColumnConverter foreignColumnConverter;
/*  20:    */   
/*  21:    */   Foreign(Class<?> entityType, Field field)
/*  22:    */   {
/*  23: 37 */     super(entityType, field);
/*  24:    */     
/*  25: 39 */     this.foreignColumnName = ColumnUtils.getForeignColumnNameByField(field);
/*  26: 40 */     Class<?> foreignColumnType = TableUtils.getColumnOrId(getForeignEntityType(), this.foreignColumnName).columnField.getType();
/*  27: 41 */     this.foreignColumnConverter = ColumnConverterFactory.getColumnConverter(foreignColumnType);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String getForeignColumnName()
/*  31:    */   {
/*  32: 46 */     return this.foreignColumnName;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Class<?> getForeignEntityType()
/*  36:    */   {
/*  37: 51 */     return ColumnUtils.getForeignEntityType(this);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setValue2Entity(Object entity, Cursor cursor, int index)
/*  41:    */   {
/*  42: 58 */     Object fieldValue = this.foreignColumnConverter.getFieldValue(cursor, index);
/*  43: 59 */     if (fieldValue == null) {
/*  44: 60 */       return;
/*  45:    */     }
/*  46: 62 */     Object value = null;
/*  47: 63 */     Class<?> columnType = this.columnField.getType();
/*  48: 64 */     if (columnType.equals(ForeignLazyLoader.class)) {
/*  49: 66 */       value = new ForeignLazyLoader(this, fieldValue);
/*  50: 67 */     } else if (columnType.equals(List.class)) {
/*  51:    */       try
/*  52:    */       {
/*  53: 71 */         value = new ForeignLazyLoader(this, fieldValue).getAllFromDb();
/*  54:    */       }
/*  55:    */       catch (DbException e)
/*  56:    */       {
/*  57: 74 */         LogUtils.e(e.getMessage(), e);
/*  58:    */       }
/*  59:    */     } else {
/*  60:    */       try
/*  61:    */       {
/*  62: 80 */         value = new ForeignLazyLoader(this, fieldValue).getFirstFromDb();
/*  63:    */       }
/*  64:    */       catch (DbException e)
/*  65:    */       {
/*  66: 83 */         LogUtils.e(e.getMessage(), e);
/*  67:    */       }
/*  68:    */     }
/*  69: 87 */     if (this.setMethod != null) {
/*  70:    */       try
/*  71:    */       {
/*  72: 91 */         this.setMethod.invoke(entity, new Object[] { value });
/*  73:    */       }
/*  74:    */       catch (Throwable e)
/*  75:    */       {
/*  76: 94 */         LogUtils.e(e.getMessage(), e);
/*  77:    */       }
/*  78:    */     } else {
/*  79:    */       try
/*  80:    */       {
/*  81:100 */         this.columnField.setAccessible(true);
/*  82:101 */         this.columnField.set(entity, value);
/*  83:    */       }
/*  84:    */       catch (Throwable e)
/*  85:    */       {
/*  86:104 */         LogUtils.e(e.getMessage(), e);
/*  87:    */       }
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Object getColumnValue(Object entity)
/*  92:    */   {
/*  93:113 */     Object fieldValue = getFieldValue(entity);
/*  94:114 */     Object columnValue = null;
/*  95:116 */     if (fieldValue != null)
/*  96:    */     {
/*  97:118 */       Class<?> columnType = this.columnField.getType();
/*  98:119 */       if (columnType.equals(ForeignLazyLoader.class)) {
/*  99:121 */         columnValue = ((ForeignLazyLoader)fieldValue).getColumnValue();
/* 100:122 */       } else if (columnType.equals(List.class)) {
/* 101:    */         try
/* 102:    */         {
/* 103:126 */           List<?> foreignEntities = (List)fieldValue;
/* 104:127 */           if (foreignEntities.size() <= 0) {
/* 105:    */             return columnValue;
/* 106:    */           }
/* 107:130 */           Class<?> foreignEntityType = ColumnUtils.getForeignEntityType(this);
/* 108:131 */           Column column = TableUtils.getColumnOrId(foreignEntityType, this.foreignColumnName);
/* 109:132 */           columnValue = column.getColumnValue(foreignEntities.get(0));
/* 110:    */           
/* 111:    */ 
/* 112:135 */           Table table = getTable();
/* 113:136 */           if ((table != null) && ((column instanceof Id))) {
/* 114:138 */             for (Object foreignObj : foreignEntities)
/* 115:    */             {
/* 116:140 */               Object idValue = column.getColumnValue(foreignObj);
/* 117:141 */               if (idValue == null) {
/* 118:143 */                 table.db.saveOrUpdate(foreignObj);
/* 119:    */               }
/* 120:    */             }
/* 121:    */           }
/* 122:148 */           columnValue = column.getColumnValue(foreignEntities.get(0));
/* 123:    */         }
/* 124:    */         catch (Throwable e)
/* 125:    */         {
/* 126:152 */           LogUtils.e(e.getMessage(), e);
/* 127:    */         }
/* 128:    */       } else {
/* 129:    */         try
/* 130:    */         {
/* 131:158 */           Column column = TableUtils.getColumnOrId(columnType, this.foreignColumnName);
/* 132:159 */           columnValue = column.getColumnValue(fieldValue);
/* 133:    */           
/* 134:161 */           Table table = getTable();
/* 135:162 */           if ((table != null) && (columnValue == null) && ((column instanceof Id))) {
/* 136:164 */             table.db.saveOrUpdate(fieldValue);
/* 137:    */           }
/* 138:167 */           columnValue = column.getColumnValue(fieldValue);
/* 139:    */         }
/* 140:    */         catch (Throwable e)
/* 141:    */         {
/* 142:170 */           LogUtils.e(e.getMessage(), e);
/* 143:    */         }
/* 144:    */       }
/* 145:    */     }
/* 146:175 */     return columnValue;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public ColumnDbType getColumnDbType()
/* 150:    */   {
/* 151:181 */     return this.foreignColumnConverter.getColumnDbType();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public Object getDefaultValue()
/* 155:    */   {
/* 156:192 */     return null;
/* 157:    */   }
/* 158:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.Foreign
 * JD-Core Version:    0.7.0.1
 */