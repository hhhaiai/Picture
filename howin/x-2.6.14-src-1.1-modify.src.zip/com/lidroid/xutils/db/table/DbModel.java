/*  1:   */ package com.lidroid.xutils.db.table;
/*  2:   */ 
/*  3:   */ import android.text.TextUtils;
/*  4:   */ import java.util.HashMap;
/*  5:   */ 
/*  6:   */ public class DbModel
/*  7:   */ {
/*  8:29 */   private HashMap<String, String> dataMap = new HashMap();
/*  9:   */   
/* 10:   */   public String getString(String columnName)
/* 11:   */   {
/* 12:33 */     return (String)this.dataMap.get(columnName);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int getInt(String columnName)
/* 16:   */   {
/* 17:38 */     return Integer.valueOf((String)this.dataMap.get(columnName)).intValue();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean getBoolean(String columnName)
/* 21:   */   {
/* 22:43 */     String value = (String)this.dataMap.get(columnName);
/* 23:44 */     if (value != null) {
/* 24:46 */       return value.length() == 1 ? "1".equals(value) : Boolean.valueOf(value).booleanValue();
/* 25:   */     }
/* 26:48 */     return false;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public double getDouble(String columnName)
/* 30:   */   {
/* 31:53 */     return Double.valueOf((String)this.dataMap.get(columnName)).doubleValue();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public float getFloat(String columnName)
/* 35:   */   {
/* 36:58 */     return Float.valueOf((String)this.dataMap.get(columnName)).floatValue();
/* 37:   */   }
/* 38:   */   
/* 39:   */   public long getLong(String columnName)
/* 40:   */   {
/* 41:63 */     return Long.valueOf((String)this.dataMap.get(columnName)).longValue();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public java.util.Date getDate(String columnName)
/* 45:   */   {
/* 46:68 */     long date = Long.valueOf((String)this.dataMap.get(columnName)).longValue();
/* 47:69 */     return new java.util.Date(date);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public java.sql.Date getSqlDate(String columnName)
/* 51:   */   {
/* 52:74 */     long date = Long.valueOf((String)this.dataMap.get(columnName)).longValue();
/* 53:75 */     return new java.sql.Date(date);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void add(String columnName, String valueStr)
/* 57:   */   {
/* 58:80 */     this.dataMap.put(columnName, valueStr);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public HashMap<String, String> getDataMap()
/* 62:   */   {
/* 63:88 */     return this.dataMap;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public boolean isEmpty(String columnName)
/* 67:   */   {
/* 68:97 */     return TextUtils.isEmpty((CharSequence)this.dataMap.get(columnName));
/* 69:   */   }
/* 70:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.DbModel
 * JD-Core Version:    0.7.0.1
 */