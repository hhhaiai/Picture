/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.db.annotation.NoAutoIncrement;
/*   4:    */ import com.lidroid.xutils.util.LogUtils;
/*   5:    */ import java.lang.reflect.Field;
/*   6:    */ import java.lang.reflect.Method;
/*   7:    */ import java.util.HashSet;
/*   8:    */ 
/*   9:    */ public class Id
/*  10:    */   extends Column
/*  11:    */ {
/*  12:    */   private String columnFieldClassName;
/*  13: 28 */   private boolean isAutoIncrementChecked = false;
/*  14: 29 */   private boolean isAutoIncrement = false;
/*  15:    */   
/*  16:    */   Id(Class<?> entityType, Field field)
/*  17:    */   {
/*  18: 33 */     super(entityType, field);
/*  19: 34 */     this.columnFieldClassName = this.columnField.getType().getName();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public boolean isAutoIncrement()
/*  23:    */   {
/*  24: 39 */     if (!this.isAutoIncrementChecked)
/*  25:    */     {
/*  26: 41 */       this.isAutoIncrementChecked = true;
/*  27: 42 */       this.isAutoIncrement = ((this.columnField.getAnnotation(NoAutoIncrement.class) == null) && (AUTO_INCREMENT_TYPES.contains(this.columnFieldClassName)));
/*  28:    */     }
/*  29: 44 */     return this.isAutoIncrement;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setAutoIncrementId(Object entity, long value)
/*  33:    */   {
/*  34: 49 */     Object idValue = Long.valueOf(value);
/*  35: 50 */     if (INTEGER_TYPES.contains(this.columnFieldClassName)) {
/*  36: 52 */       idValue = Integer.valueOf((int)value);
/*  37:    */     }
/*  38: 55 */     if (this.setMethod != null) {
/*  39:    */       try
/*  40:    */       {
/*  41: 59 */         this.setMethod.invoke(entity, new Object[] { idValue });
/*  42:    */       }
/*  43:    */       catch (Throwable e)
/*  44:    */       {
/*  45: 62 */         LogUtils.e(e.getMessage(), e);
/*  46:    */       }
/*  47:    */     } else {
/*  48:    */       try
/*  49:    */       {
/*  50: 68 */         this.columnField.setAccessible(true);
/*  51: 69 */         this.columnField.set(entity, idValue);
/*  52:    */       }
/*  53:    */       catch (Throwable e)
/*  54:    */       {
/*  55: 72 */         LogUtils.e(e.getMessage(), e);
/*  56:    */       }
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Object getColumnValue(Object entity)
/*  61:    */   {
/*  62: 80 */     Object idValue = super.getColumnValue(entity);
/*  63: 81 */     if (idValue != null)
/*  64:    */     {
/*  65: 83 */       if ((isAutoIncrement()) && ((idValue.equals(Integer.valueOf(0))) || (idValue.equals(Long.valueOf(0L))))) {
/*  66: 85 */         return null;
/*  67:    */       }
/*  68: 88 */       return idValue;
/*  69:    */     }
/*  70: 91 */     return null;
/*  71:    */   }
/*  72:    */   
/*  73: 94 */   private static final HashSet<String> INTEGER_TYPES = new HashSet(2);
/*  74: 95 */   private static final HashSet<String> AUTO_INCREMENT_TYPES = new HashSet(4);
/*  75:    */   
/*  76:    */   static
/*  77:    */   {
/*  78: 99 */     INTEGER_TYPES.add(Integer.TYPE.getName());
/*  79:100 */     INTEGER_TYPES.add(Integer.class.getName());
/*  80:    */     
/*  81:102 */     AUTO_INCREMENT_TYPES.addAll(INTEGER_TYPES);
/*  82:103 */     AUTO_INCREMENT_TYPES.add(Long.TYPE.getName());
/*  83:104 */     AUTO_INCREMENT_TYPES.add(Long.class.getName());
/*  84:    */   }
/*  85:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.Id
 * JD-Core Version:    0.7.0.1
 */