/*   1:    */ package com.lidroid.xutils.db.table;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*   5:    */ import com.lidroid.xutils.db.sqlite.FinderLazyLoader;
/*   6:    */ import com.lidroid.xutils.exception.DbException;
/*   7:    */ import com.lidroid.xutils.util.LogUtils;
/*   8:    */ import java.lang.reflect.Field;
/*   9:    */ import java.lang.reflect.Method;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ public class Finder
/*  13:    */   extends Column
/*  14:    */ {
/*  15:    */   private final String valueColumnName;
/*  16:    */   private final String targetColumnName;
/*  17:    */   
/*  18:    */   Finder(Class<?> entityType, Field field)
/*  19:    */   {
/*  20: 23 */     super(entityType, field);
/*  21:    */     
/*  22: 25 */     com.lidroid.xutils.db.annotation.Finder finder = (com.lidroid.xutils.db.annotation.Finder)field.getAnnotation(com.lidroid.xutils.db.annotation.Finder.class);
/*  23: 26 */     this.valueColumnName = finder.valueColumn();
/*  24: 27 */     this.targetColumnName = finder.targetColumn();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public Class<?> getTargetEntityType()
/*  28:    */   {
/*  29: 32 */     return ColumnUtils.getFinderTargetEntityType(this);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getTargetColumnName()
/*  33:    */   {
/*  34: 37 */     return this.targetColumnName;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setValue2Entity(Object entity, Cursor cursor, int index)
/*  38:    */   {
/*  39: 43 */     Object value = null;
/*  40: 44 */     Class<?> columnType = this.columnField.getType();
/*  41: 45 */     Object finderValue = TableUtils.getColumnOrId(entity.getClass(), this.valueColumnName).getColumnValue(entity);
/*  42: 46 */     if (columnType.equals(FinderLazyLoader.class)) {
/*  43: 48 */       value = new FinderLazyLoader(this, finderValue);
/*  44: 49 */     } else if (columnType.equals(List.class)) {
/*  45:    */       try
/*  46:    */       {
/*  47: 53 */         value = new FinderLazyLoader(this, finderValue).getAllFromDb();
/*  48:    */       }
/*  49:    */       catch (DbException e)
/*  50:    */       {
/*  51: 56 */         LogUtils.e(e.getMessage(), e);
/*  52:    */       }
/*  53:    */     } else {
/*  54:    */       try
/*  55:    */       {
/*  56: 62 */         value = new FinderLazyLoader(this, finderValue).getFirstFromDb();
/*  57:    */       }
/*  58:    */       catch (DbException e)
/*  59:    */       {
/*  60: 65 */         LogUtils.e(e.getMessage(), e);
/*  61:    */       }
/*  62:    */     }
/*  63: 69 */     if (this.setMethod != null) {
/*  64:    */       try
/*  65:    */       {
/*  66: 73 */         this.setMethod.invoke(entity, new Object[] { value });
/*  67:    */       }
/*  68:    */       catch (Throwable e)
/*  69:    */       {
/*  70: 76 */         LogUtils.e(e.getMessage(), e);
/*  71:    */       }
/*  72:    */     } else {
/*  73:    */       try
/*  74:    */       {
/*  75: 82 */         this.columnField.setAccessible(true);
/*  76: 83 */         this.columnField.set(entity, value);
/*  77:    */       }
/*  78:    */       catch (Throwable e)
/*  79:    */       {
/*  80: 86 */         LogUtils.e(e.getMessage(), e);
/*  81:    */       }
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Object getColumnValue(Object entity)
/*  86:    */   {
/*  87: 94 */     return null;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Object getDefaultValue()
/*  91:    */   {
/*  92:100 */     return null;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public ColumnDbType getColumnDbType()
/*  96:    */   {
/*  97:106 */     return ColumnDbType.TEXT;
/*  98:    */   }
/*  99:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.Finder
 * JD-Core Version:    0.7.0.1
 */