/*  1:   */ package com.lidroid.xutils.db.table;
/*  2:   */ 
/*  3:   */ public class KeyValue
/*  4:   */ {
/*  5:   */   public final String key;
/*  6:   */   public final Object value;
/*  7:   */   
/*  8:   */   public KeyValue(String key, Object value)
/*  9:   */   {
/* 10:25 */     this.key = key;
/* 11:26 */     this.value = value;
/* 12:   */   }
/* 13:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.table.KeyValue
 * JD-Core Version:    0.7.0.1
 */