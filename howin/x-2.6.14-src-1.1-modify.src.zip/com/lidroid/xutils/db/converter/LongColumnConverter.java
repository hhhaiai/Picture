/*  1:   */ package com.lidroid.xutils.db.converter;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import android.text.TextUtils;
/*  5:   */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*  6:   */ 
/*  7:   */ public class LongColumnConverter
/*  8:   */   implements ColumnConverter<Long>
/*  9:   */ {
/* 10:   */   public Long getFieldValue(Cursor cursor, int index)
/* 11:   */   {
/* 12:15 */     return cursor.isNull(index) ? null : Long.valueOf(cursor.getLong(index));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public Long getFieldValue(String fieldStringValue)
/* 16:   */   {
/* 17:21 */     if (TextUtils.isEmpty(fieldStringValue)) {
/* 18:22 */       return null;
/* 19:   */     }
/* 20:23 */     return Long.valueOf(fieldStringValue);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Object fieldValue2ColumnValue(Long fieldValue)
/* 24:   */   {
/* 25:29 */     return fieldValue;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public ColumnDbType getColumnDbType()
/* 29:   */   {
/* 30:35 */     return ColumnDbType.INTEGER;
/* 31:   */   }
/* 32:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.converter.LongColumnConverter
 * JD-Core Version:    0.7.0.1
 */