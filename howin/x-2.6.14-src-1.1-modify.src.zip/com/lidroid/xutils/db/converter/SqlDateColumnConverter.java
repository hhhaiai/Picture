/*  1:   */ package com.lidroid.xutils.db.converter;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import android.text.TextUtils;
/*  5:   */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*  6:   */ import java.sql.Date;
/*  7:   */ 
/*  8:   */ public class SqlDateColumnConverter
/*  9:   */   implements ColumnConverter<Date>
/* 10:   */ {
/* 11:   */   public Date getFieldValue(Cursor cursor, int index)
/* 12:   */   {
/* 13:15 */     return cursor.isNull(index) ? null : new Date(cursor.getLong(index));
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Date getFieldValue(String fieldStringValue)
/* 17:   */   {
/* 18:21 */     if (TextUtils.isEmpty(fieldStringValue)) {
/* 19:22 */       return null;
/* 20:   */     }
/* 21:23 */     return new Date(Long.valueOf(fieldStringValue).longValue());
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Object fieldValue2ColumnValue(Date fieldValue)
/* 25:   */   {
/* 26:29 */     if (fieldValue == null) {
/* 27:30 */       return null;
/* 28:   */     }
/* 29:31 */     return Long.valueOf(fieldValue.getTime());
/* 30:   */   }
/* 31:   */   
/* 32:   */   public ColumnDbType getColumnDbType()
/* 33:   */   {
/* 34:37 */     return ColumnDbType.INTEGER;
/* 35:   */   }
/* 36:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.converter.SqlDateColumnConverter
 * JD-Core Version:    0.7.0.1
 */