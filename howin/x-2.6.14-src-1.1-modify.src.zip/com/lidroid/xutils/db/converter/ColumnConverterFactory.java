/*   1:    */ package com.lidroid.xutils.db.converter;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*   4:    */ import java.util.concurrent.ConcurrentHashMap;
/*   5:    */ 
/*   6:    */ public class ColumnConverterFactory
/*   7:    */ {
/*   8:    */   public static ColumnConverter getColumnConverter(Class columnType)
/*   9:    */   {
/*  10: 20 */     if (columnType_columnConverter_map.containsKey(columnType.getName())) {
/*  11: 22 */       return (ColumnConverter)columnType_columnConverter_map.get(columnType.getName());
/*  12:    */     }
/*  13: 23 */     if (ColumnConverter.class.isAssignableFrom(columnType)) {
/*  14:    */       try
/*  15:    */       {
/*  16: 27 */         ColumnConverter columnConverter = (ColumnConverter)columnType.newInstance();
/*  17: 28 */         if (columnConverter != null) {
/*  18: 30 */           columnType_columnConverter_map.put(columnType.getName(), columnConverter);
/*  19:    */         }
/*  20: 32 */         return columnConverter;
/*  21:    */       }
/*  22:    */       catch (Throwable localThrowable) {}
/*  23:    */     }
/*  24: 37 */     return null;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static ColumnDbType getDbColumnType(Class columnType)
/*  28:    */   {
/*  29: 42 */     ColumnConverter converter = getColumnConverter(columnType);
/*  30: 43 */     if (converter != null) {
/*  31: 45 */       return converter.getColumnDbType();
/*  32:    */     }
/*  33: 47 */     return ColumnDbType.TEXT;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void registerColumnConverter(Class columnType, ColumnConverter columnConverter)
/*  37:    */   {
/*  38: 52 */     columnType_columnConverter_map.put(columnType.getName(), columnConverter);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static boolean isSupportColumnConverter(Class columnType)
/*  42:    */   {
/*  43: 57 */     if (columnType_columnConverter_map.containsKey(columnType.getName())) {
/*  44: 59 */       return true;
/*  45:    */     }
/*  46: 60 */     if (ColumnConverter.class.isAssignableFrom(columnType)) {
/*  47:    */       try
/*  48:    */       {
/*  49: 64 */         ColumnConverter columnConverter = (ColumnConverter)columnType.newInstance();
/*  50: 65 */         if (columnConverter != null) {
/*  51: 67 */           columnType_columnConverter_map.put(columnType.getName(), columnConverter);
/*  52:    */         }
/*  53: 69 */         return columnConverter == null;
/*  54:    */       }
/*  55:    */       catch (Throwable localThrowable) {}
/*  56:    */     }
/*  57: 74 */     return false;
/*  58:    */   }
/*  59:    */   
/*  60: 81 */   private static final ConcurrentHashMap<String, ColumnConverter> columnType_columnConverter_map = new ConcurrentHashMap();
/*  61:    */   
/*  62:    */   static
/*  63:    */   {
/*  64: 83 */     BooleanColumnConverter booleanColumnConverter = new BooleanColumnConverter();
/*  65: 84 */     columnType_columnConverter_map.put(Boolean.TYPE.getName(), booleanColumnConverter);
/*  66: 85 */     columnType_columnConverter_map.put(Boolean.class.getName(), booleanColumnConverter);
/*  67:    */     
/*  68: 87 */     ByteArrayColumnConverter byteArrayColumnConverter = new ByteArrayColumnConverter();
/*  69: 88 */     columnType_columnConverter_map.put([B.class.getName(), byteArrayColumnConverter);
/*  70:    */     
/*  71: 90 */     ByteColumnConverter byteColumnConverter = new ByteColumnConverter();
/*  72: 91 */     columnType_columnConverter_map.put(Byte.TYPE.getName(), byteColumnConverter);
/*  73: 92 */     columnType_columnConverter_map.put(Byte.class.getName(), byteColumnConverter);
/*  74:    */     
/*  75: 94 */     CharColumnConverter charColumnConverter = new CharColumnConverter();
/*  76: 95 */     columnType_columnConverter_map.put(Character.TYPE.getName(), charColumnConverter);
/*  77: 96 */     columnType_columnConverter_map.put(Character.class.getName(), charColumnConverter);
/*  78:    */     
/*  79: 98 */     DateColumnConverter dateColumnConverter = new DateColumnConverter();
/*  80: 99 */     columnType_columnConverter_map.put(java.util.Date.class.getName(), dateColumnConverter);
/*  81:    */     
/*  82:101 */     DoubleColumnConverter doubleColumnConverter = new DoubleColumnConverter();
/*  83:102 */     columnType_columnConverter_map.put(Double.TYPE.getName(), doubleColumnConverter);
/*  84:103 */     columnType_columnConverter_map.put(Double.class.getName(), doubleColumnConverter);
/*  85:    */     
/*  86:105 */     FloatColumnConverter floatColumnConverter = new FloatColumnConverter();
/*  87:106 */     columnType_columnConverter_map.put(Float.TYPE.getName(), floatColumnConverter);
/*  88:107 */     columnType_columnConverter_map.put(Float.class.getName(), floatColumnConverter);
/*  89:    */     
/*  90:109 */     IntegerColumnConverter integerColumnConverter = new IntegerColumnConverter();
/*  91:110 */     columnType_columnConverter_map.put(Integer.TYPE.getName(), integerColumnConverter);
/*  92:111 */     columnType_columnConverter_map.put(Integer.class.getName(), integerColumnConverter);
/*  93:    */     
/*  94:113 */     LongColumnConverter longColumnConverter = new LongColumnConverter();
/*  95:114 */     columnType_columnConverter_map.put(Long.TYPE.getName(), longColumnConverter);
/*  96:115 */     columnType_columnConverter_map.put(Long.class.getName(), longColumnConverter);
/*  97:    */     
/*  98:117 */     ShortColumnConverter shortColumnConverter = new ShortColumnConverter();
/*  99:118 */     columnType_columnConverter_map.put(Short.TYPE.getName(), shortColumnConverter);
/* 100:119 */     columnType_columnConverter_map.put(Short.class.getName(), shortColumnConverter);
/* 101:    */     
/* 102:121 */     SqlDateColumnConverter sqlDateColumnConverter = new SqlDateColumnConverter();
/* 103:122 */     columnType_columnConverter_map.put(java.sql.Date.class.getName(), sqlDateColumnConverter);
/* 104:    */     
/* 105:124 */     StringColumnConverter stringColumnConverter = new StringColumnConverter();
/* 106:125 */     columnType_columnConverter_map.put(String.class.getName(), stringColumnConverter);
/* 107:    */   }
/* 108:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.converter.ColumnConverterFactory
 * JD-Core Version:    0.7.0.1
 */