/*  1:   */ package com.lidroid.xutils.db.converter;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import android.text.TextUtils;
/*  5:   */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*  6:   */ 
/*  7:   */ public class CharColumnConverter
/*  8:   */   implements ColumnConverter<Character>
/*  9:   */ {
/* 10:   */   public Character getFieldValue(Cursor cursor, int index)
/* 11:   */   {
/* 12:15 */     return cursor.isNull(index) ? null : Character.valueOf((char)cursor.getInt(index));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public Character getFieldValue(String fieldStringValue)
/* 16:   */   {
/* 17:21 */     if (TextUtils.isEmpty(fieldStringValue)) {
/* 18:22 */       return null;
/* 19:   */     }
/* 20:23 */     return Character.valueOf(fieldStringValue.charAt(0));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Object fieldValue2ColumnValue(Character fieldValue)
/* 24:   */   {
/* 25:29 */     if (fieldValue == null) {
/* 26:30 */       return null;
/* 27:   */     }
/* 28:31 */     return Integer.valueOf(fieldValue.charValue());
/* 29:   */   }
/* 30:   */   
/* 31:   */   public ColumnDbType getColumnDbType()
/* 32:   */   {
/* 33:37 */     return ColumnDbType.INTEGER;
/* 34:   */   }
/* 35:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.converter.CharColumnConverter
 * JD-Core Version:    0.7.0.1
 */