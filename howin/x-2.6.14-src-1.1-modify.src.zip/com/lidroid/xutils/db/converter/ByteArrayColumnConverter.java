/*  1:   */ package com.lidroid.xutils.db.converter;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import com.lidroid.xutils.db.sqlite.ColumnDbType;
/*  5:   */ 
/*  6:   */ public class ByteArrayColumnConverter
/*  7:   */   implements ColumnConverter<byte[]>
/*  8:   */ {
/*  9:   */   public byte[] getFieldValue(Cursor cursor, int index)
/* 10:   */   {
/* 11:14 */     return cursor.isNull(index) ? null : cursor.getBlob(index);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public byte[] getFieldValue(String fieldStringValue)
/* 15:   */   {
/* 16:20 */     return null;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public Object fieldValue2ColumnValue(byte[] fieldValue)
/* 20:   */   {
/* 21:26 */     return fieldValue;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ColumnDbType getColumnDbType()
/* 25:   */   {
/* 26:32 */     return ColumnDbType.BLOB;
/* 27:   */   }
/* 28:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.converter.ByteArrayColumnConverter
 * JD-Core Version:    0.7.0.1
 */