/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import com.lidroid.xutils.DbUtils;
/*   5:    */ import com.lidroid.xutils.db.converter.ColumnConverter;
/*   6:    */ import com.lidroid.xutils.db.table.Column;
/*   7:    */ import com.lidroid.xutils.db.table.DbModel;
/*   8:    */ import com.lidroid.xutils.db.table.Finder;
/*   9:    */ import com.lidroid.xutils.db.table.Id;
/*  10:    */ import com.lidroid.xutils.db.table.Table;
/*  11:    */ import com.lidroid.xutils.util.LogUtils;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.concurrent.ConcurrentHashMap;
/*  14:    */ 
/*  15:    */ public class CursorUtils
/*  16:    */ {
/*  17:    */   public static <T> T getEntity(DbUtils db, Cursor cursor, Class<T> entityType, long findCacheSequence)
/*  18:    */   {
/*  19: 31 */     if ((db == null) || (cursor == null)) {
/*  20: 32 */       return null;
/*  21:    */     }
/*  22: 34 */     EntityTempCache.setSeq(findCacheSequence);
/*  23:    */     try
/*  24:    */     {
/*  25: 37 */       Table table = Table.get(db, entityType);
/*  26: 38 */       Id id = table.id;
/*  27: 39 */       String idColumnName = id.getColumnName();
/*  28: 40 */       int idIndex = id.getIndex();
/*  29: 41 */       if (idIndex < 0) {
/*  30: 43 */         idIndex = cursor.getColumnIndex(idColumnName);
/*  31:    */       }
/*  32: 45 */       Object idValue = id.getColumnConverter().getFieldValue(cursor, idIndex);
/*  33: 46 */       T entity = EntityTempCache.get(entityType, idValue);
/*  34: 47 */       if (entity == null)
/*  35:    */       {
/*  36: 49 */         entity = entityType.newInstance();
/*  37: 50 */         id.setValue2Entity(entity, cursor, idIndex);
/*  38: 51 */         EntityTempCache.put(entityType, idValue, entity);
/*  39:    */       }
/*  40:    */       else
/*  41:    */       {
/*  42: 54 */         return entity;
/*  43:    */       }
/*  44: 56 */       int columnCount = cursor.getColumnCount();
/*  45:    */       String columnName;
/*  46: 57 */       for (int i = 0; i < columnCount; i++)
/*  47:    */       {
/*  48: 59 */         columnName = cursor.getColumnName(i);
/*  49: 60 */         Column column = (Column)table.columnMap.get(columnName);
/*  50: 61 */         if (column != null) {
/*  51: 63 */           column.setValue2Entity(entity, cursor, i);
/*  52:    */         }
/*  53:    */       }
/*  54: 68 */       for (Finder finder : table.finderMap.values()) {
/*  55: 70 */         finder.setValue2Entity(entity, null, 0);
/*  56:    */       }
/*  57: 72 */       return entity;
/*  58:    */     }
/*  59:    */     catch (Throwable e)
/*  60:    */     {
/*  61: 75 */       LogUtils.e(e.getMessage(), e);
/*  62:    */     }
/*  63: 78 */     return null;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static DbModel getDbModel(Cursor cursor)
/*  67:    */   {
/*  68: 83 */     DbModel result = null;
/*  69: 84 */     if (cursor != null)
/*  70:    */     {
/*  71: 86 */       result = new DbModel();
/*  72: 87 */       int columnCount = cursor.getColumnCount();
/*  73: 88 */       for (int i = 0; i < columnCount; i++) {
/*  74: 90 */         result.add(cursor.getColumnName(i), cursor.getString(i));
/*  75:    */       }
/*  76:    */     }
/*  77: 93 */     return result;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static class FindCacheSequence
/*  81:    */   {
/*  82:102 */     private static long seq = 0L;
/*  83:103 */     private static final String FOREIGN_LAZY_LOADER_CLASS_NAME = ForeignLazyLoader.class.getName();
/*  84:104 */     private static final String FINDER_LAZY_LOADER_CLASS_NAME = FinderLazyLoader.class.getName();
/*  85:    */     
/*  86:    */     public static long getSeq()
/*  87:    */     {
/*  88:108 */       String findMethodCaller = java.lang.Thread.currentThread().getStackTrace()[4].getClassName();
/*  89:109 */       if ((!findMethodCaller.equals(FOREIGN_LAZY_LOADER_CLASS_NAME)) && (!findMethodCaller.equals(FINDER_LAZY_LOADER_CLASS_NAME))) {
/*  90:111 */         seq += 1L;
/*  91:    */       }
/*  92:113 */       return seq;
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   private static class EntityTempCache
/*  97:    */   {
/*  98:123 */     private static final ConcurrentHashMap<String, Object> cache = new ConcurrentHashMap();
/*  99:125 */     private static long seq = 0L;
/* 100:    */     
/* 101:    */     public static <T> void put(Class<T> entityType, Object idValue, Object entity)
/* 102:    */     {
/* 103:129 */       cache.put(entityType.getName() + "#" + idValue, entity);
/* 104:    */     }
/* 105:    */     
/* 106:    */     public static <T> T get(Class<T> entityType, Object idValue)
/* 107:    */     {
/* 108:135 */       return cache.get(entityType.getName() + "#" + idValue);
/* 109:    */     }
/* 110:    */     
/* 111:    */     public static void setSeq(long seq)
/* 112:    */     {
/* 113:140 */       if (seq != seq)
/* 114:    */       {
/* 115:142 */         cache.clear();
/* 116:143 */         seq = seq;
/* 117:    */       }
/* 118:    */     }
/* 119:    */   }
/* 120:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.CursorUtils
 * JD-Core Version:    0.7.0.1
 */