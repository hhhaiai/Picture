/*  1:   */ package com.lidroid.xutils.db.sqlite;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.DbUtils;
/*  4:   */ import com.lidroid.xutils.db.table.ColumnUtils;
/*  5:   */ import com.lidroid.xutils.db.table.Finder;
/*  6:   */ import com.lidroid.xutils.db.table.Table;
/*  7:   */ import com.lidroid.xutils.exception.DbException;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ public class FinderLazyLoader<T>
/* 11:   */ {
/* 12:   */   private final Finder finderColumn;
/* 13:   */   private final Object finderValue;
/* 14:   */   
/* 15:   */   public FinderLazyLoader(Finder finderColumn, Object value)
/* 16:   */   {
/* 17:20 */     this.finderColumn = finderColumn;
/* 18:21 */     this.finderValue = ColumnUtils.convert2DbColumnValueIfNeeded(value);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public List<T> getAllFromDb()
/* 22:   */     throws DbException
/* 23:   */   {
/* 24:26 */     List<T> entities = null;
/* 25:27 */     Table table = this.finderColumn.getTable();
/* 26:28 */     if (table != null) {
/* 27:30 */       entities = table.db.findAll(Selector.from(this.finderColumn.getTargetEntityType()).where(this.finderColumn.getTargetColumnName(), "=", this.finderValue));
/* 28:   */     }
/* 29:32 */     return entities;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public T getFirstFromDb()
/* 33:   */     throws DbException
/* 34:   */   {
/* 35:37 */     T entity = null;
/* 36:38 */     Table table = this.finderColumn.getTable();
/* 37:39 */     if (table != null) {
/* 38:41 */       entity = table.db.findFirst(Selector.from(this.finderColumn.getTargetEntityType()).where(this.finderColumn.getTargetColumnName(), "=", this.finderValue));
/* 39:   */     }
/* 40:43 */     return entity;
/* 41:   */   }
/* 42:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.FinderLazyLoader
 * JD-Core Version:    0.7.0.1
 */