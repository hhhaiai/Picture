/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.db.table.ColumnUtils;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ 
/*   6:    */ public class SqlInfo
/*   7:    */ {
/*   8:    */   private String sql;
/*   9:    */   private LinkedList<Object> bindArgs;
/*  10:    */   
/*  11:    */   public SqlInfo() {}
/*  12:    */   
/*  13:    */   public SqlInfo(String sql)
/*  14:    */   {
/*  15: 34 */     this.sql = sql;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public SqlInfo(String sql, Object... bindArgs)
/*  19:    */   {
/*  20: 39 */     this.sql = sql;
/*  21: 40 */     addBindArgs(bindArgs);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public String getSql()
/*  25:    */   {
/*  26: 45 */     return this.sql;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setSql(String sql)
/*  30:    */   {
/*  31: 50 */     this.sql = sql;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public LinkedList<Object> getBindArgs()
/*  35:    */   {
/*  36: 55 */     return this.bindArgs;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Object[] getBindArgsAsArray()
/*  40:    */   {
/*  41: 60 */     if (this.bindArgs != null) {
/*  42: 62 */       return this.bindArgs.toArray();
/*  43:    */     }
/*  44: 64 */     return null;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String[] getBindArgsAsStrArray()
/*  48:    */   {
/*  49: 69 */     if (this.bindArgs != null)
/*  50:    */     {
/*  51: 71 */       String[] strings = new String[this.bindArgs.size()];
/*  52: 72 */       for (int i = 0; i < this.bindArgs.size(); i++)
/*  53:    */       {
/*  54: 74 */         Object value = this.bindArgs.get(i);
/*  55: 75 */         strings[i] = (value == null ? null : value.toString());
/*  56:    */       }
/*  57: 77 */       return strings;
/*  58:    */     }
/*  59: 79 */     return null;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void addBindArg(Object arg)
/*  63:    */   {
/*  64: 84 */     if (this.bindArgs == null) {
/*  65: 86 */       this.bindArgs = new LinkedList();
/*  66:    */     }
/*  67: 89 */     this.bindArgs.add(ColumnUtils.convert2DbColumnValueIfNeeded(arg));
/*  68:    */   }
/*  69:    */   
/*  70:    */   void addBindArgWithoutConverter(Object arg)
/*  71:    */   {
/*  72: 94 */     if (this.bindArgs == null) {
/*  73: 96 */       this.bindArgs = new LinkedList();
/*  74:    */     }
/*  75: 99 */     this.bindArgs.add(arg);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void addBindArgs(Object... bindArgs)
/*  79:    */   {
/*  80:104 */     if (bindArgs != null) {
/*  81:106 */       for (Object arg : bindArgs) {
/*  82:108 */         addBindArg(arg);
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.SqlInfo
 * JD-Core Version:    0.7.0.1
 */