/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.db.table.TableUtils;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ public class Selector
/*   8:    */ {
/*   9:    */   protected Class<?> entityType;
/*  10:    */   protected String tableName;
/*  11:    */   protected WhereBuilder whereBuilder;
/*  12:    */   protected List<OrderBy> orderByList;
/*  13: 34 */   protected int limit = 0;
/*  14: 35 */   protected int offset = 0;
/*  15:    */   
/*  16:    */   private Selector(Class<?> entityType)
/*  17:    */   {
/*  18: 39 */     this.entityType = entityType;
/*  19: 40 */     this.tableName = TableUtils.getTableName(entityType);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static Selector from(Class<?> entityType)
/*  23:    */   {
/*  24: 45 */     return new Selector(entityType);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public Selector where(WhereBuilder whereBuilder)
/*  28:    */   {
/*  29: 50 */     this.whereBuilder = whereBuilder;
/*  30: 51 */     return this;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public Selector where(String columnName, String op, Object value)
/*  34:    */   {
/*  35: 56 */     this.whereBuilder = WhereBuilder.b(columnName, op, value);
/*  36: 57 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Selector and(String columnName, String op, Object value)
/*  40:    */   {
/*  41: 62 */     this.whereBuilder.and(columnName, op, value);
/*  42: 63 */     return this;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Selector and(WhereBuilder where)
/*  46:    */   {
/*  47: 68 */     this.whereBuilder.expr("AND (" + where.toString() + ")");
/*  48: 69 */     return this;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Selector or(String columnName, String op, Object value)
/*  52:    */   {
/*  53: 74 */     this.whereBuilder.or(columnName, op, value);
/*  54: 75 */     return this;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Selector or(WhereBuilder where)
/*  58:    */   {
/*  59: 80 */     this.whereBuilder.expr("OR (" + where.toString() + ")");
/*  60: 81 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Selector expr(String expr)
/*  64:    */   {
/*  65: 86 */     if (this.whereBuilder == null) {
/*  66: 88 */       this.whereBuilder = WhereBuilder.b();
/*  67:    */     }
/*  68: 90 */     this.whereBuilder.expr(expr);
/*  69: 91 */     return this;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Selector expr(String columnName, String op, Object value)
/*  73:    */   {
/*  74: 96 */     if (this.whereBuilder == null) {
/*  75: 98 */       this.whereBuilder = WhereBuilder.b();
/*  76:    */     }
/*  77:100 */     this.whereBuilder.expr(columnName, op, value);
/*  78:101 */     return this;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public DbModelSelector groupBy(String columnName)
/*  82:    */   {
/*  83:106 */     return new DbModelSelector(this, columnName);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public DbModelSelector select(String... columnExpressions)
/*  87:    */   {
/*  88:111 */     return new DbModelSelector(this, columnExpressions);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Selector orderBy(String columnName)
/*  92:    */   {
/*  93:116 */     if (this.orderByList == null) {
/*  94:118 */       this.orderByList = new ArrayList(2);
/*  95:    */     }
/*  96:120 */     this.orderByList.add(new OrderBy(columnName));
/*  97:121 */     return this;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Selector orderBy(String columnName, boolean desc)
/* 101:    */   {
/* 102:126 */     if (this.orderByList == null) {
/* 103:128 */       this.orderByList = new ArrayList(2);
/* 104:    */     }
/* 105:130 */     this.orderByList.add(new OrderBy(columnName, desc));
/* 106:131 */     return this;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Selector limit(int limit)
/* 110:    */   {
/* 111:136 */     this.limit = limit;
/* 112:137 */     return this;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Selector offset(int offset)
/* 116:    */   {
/* 117:142 */     this.offset = offset;
/* 118:143 */     return this;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public String toString()
/* 122:    */   {
/* 123:149 */     StringBuilder result = new StringBuilder();
/* 124:150 */     result.append("SELECT ");
/* 125:151 */     result.append("*");
/* 126:152 */     result.append(" FROM ").append(this.tableName);
/* 127:153 */     if ((this.whereBuilder != null) && (this.whereBuilder.getWhereItemSize() > 0)) {
/* 128:155 */       result.append(" WHERE ").append(this.whereBuilder.toString());
/* 129:    */     }
/* 130:157 */     if (this.orderByList != null) {
/* 131:159 */       for (int i = 0; i < this.orderByList.size(); i++) {
/* 132:161 */         result.append(" ORDER BY ").append(((OrderBy)this.orderByList.get(i)).toString());
/* 133:    */       }
/* 134:    */     }
/* 135:164 */     if (this.limit > 0)
/* 136:    */     {
/* 137:166 */       result.append(" LIMIT ").append(this.limit);
/* 138:167 */       result.append(" OFFSET ").append(this.offset);
/* 139:    */     }
/* 140:169 */     return result.toString();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public Class<?> getEntityType()
/* 144:    */   {
/* 145:174 */     return this.entityType;
/* 146:    */   }
/* 147:    */   
/* 148:    */   protected class OrderBy
/* 149:    */   {
/* 150:    */     private String columnName;
/* 151:    */     private boolean desc;
/* 152:    */     
/* 153:    */     public OrderBy(String columnName)
/* 154:    */     {
/* 155:184 */       this.columnName = columnName;
/* 156:    */     }
/* 157:    */     
/* 158:    */     public OrderBy(String columnName, boolean desc)
/* 159:    */     {
/* 160:189 */       this.columnName = columnName;
/* 161:190 */       this.desc = desc;
/* 162:    */     }
/* 163:    */     
/* 164:    */     public String toString()
/* 165:    */     {
/* 166:196 */       return this.columnName + (this.desc ? " DESC" : " ASC");
/* 167:    */     }
/* 168:    */   }
/* 169:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.Selector
 * JD-Core Version:    0.7.0.1
 */