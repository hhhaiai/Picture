/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public class DbModelSelector
/*   7:    */ {
/*   8:    */   private String[] columnExpressions;
/*   9:    */   private String groupByColumnName;
/*  10:    */   private WhereBuilder having;
/*  11:    */   private Selector selector;
/*  12:    */   
/*  13:    */   private DbModelSelector(Class<?> entityType)
/*  14:    */   {
/*  15: 34 */     this.selector = Selector.from(entityType);
/*  16:    */   }
/*  17:    */   
/*  18:    */   protected DbModelSelector(Selector selector, String groupByColumnName)
/*  19:    */   {
/*  20: 39 */     this.selector = selector;
/*  21: 40 */     this.groupByColumnName = groupByColumnName;
/*  22:    */   }
/*  23:    */   
/*  24:    */   protected DbModelSelector(Selector selector, String[] columnExpressions)
/*  25:    */   {
/*  26: 45 */     this.selector = selector;
/*  27: 46 */     this.columnExpressions = columnExpressions;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static DbModelSelector from(Class<?> entityType)
/*  31:    */   {
/*  32: 51 */     return new DbModelSelector(entityType);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public DbModelSelector where(WhereBuilder whereBuilder)
/*  36:    */   {
/*  37: 56 */     this.selector.where(whereBuilder);
/*  38: 57 */     return this;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public DbModelSelector where(String columnName, String op, Object value)
/*  42:    */   {
/*  43: 62 */     this.selector.where(columnName, op, value);
/*  44: 63 */     return this;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public DbModelSelector and(String columnName, String op, Object value)
/*  48:    */   {
/*  49: 68 */     this.selector.and(columnName, op, value);
/*  50: 69 */     return this;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public DbModelSelector and(WhereBuilder where)
/*  54:    */   {
/*  55: 74 */     this.selector.and(where);
/*  56: 75 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public DbModelSelector or(String columnName, String op, Object value)
/*  60:    */   {
/*  61: 80 */     this.selector.or(columnName, op, value);
/*  62: 81 */     return this;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public DbModelSelector or(WhereBuilder where)
/*  66:    */   {
/*  67: 86 */     this.selector.or(where);
/*  68: 87 */     return this;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public DbModelSelector expr(String expr)
/*  72:    */   {
/*  73: 92 */     this.selector.expr(expr);
/*  74: 93 */     return this;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public DbModelSelector expr(String columnName, String op, Object value)
/*  78:    */   {
/*  79: 98 */     this.selector.expr(columnName, op, value);
/*  80: 99 */     return this;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public DbModelSelector groupBy(String columnName)
/*  84:    */   {
/*  85:104 */     this.groupByColumnName = columnName;
/*  86:105 */     return this;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public DbModelSelector having(WhereBuilder whereBuilder)
/*  90:    */   {
/*  91:110 */     this.having = whereBuilder;
/*  92:111 */     return this;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public DbModelSelector select(String... columnExpressions)
/*  96:    */   {
/*  97:116 */     this.columnExpressions = columnExpressions;
/*  98:117 */     return this;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public DbModelSelector orderBy(String columnName)
/* 102:    */   {
/* 103:122 */     this.selector.orderBy(columnName);
/* 104:123 */     return this;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public DbModelSelector orderBy(String columnName, boolean desc)
/* 108:    */   {
/* 109:128 */     this.selector.orderBy(columnName, desc);
/* 110:129 */     return this;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public DbModelSelector limit(int limit)
/* 114:    */   {
/* 115:134 */     this.selector.limit(limit);
/* 116:135 */     return this;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public DbModelSelector offset(int offset)
/* 120:    */   {
/* 121:140 */     this.selector.offset(offset);
/* 122:141 */     return this;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Class<?> getEntityType()
/* 126:    */   {
/* 127:146 */     return this.selector.getEntityType();
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String toString()
/* 131:    */   {
/* 132:152 */     StringBuffer result = new StringBuffer();
/* 133:153 */     result.append("SELECT ");
/* 134:154 */     if ((this.columnExpressions != null) && (this.columnExpressions.length > 0))
/* 135:    */     {
/* 136:156 */       for (int i = 0; i < this.columnExpressions.length; i++)
/* 137:    */       {
/* 138:158 */         result.append(this.columnExpressions[i]);
/* 139:159 */         result.append(",");
/* 140:    */       }
/* 141:161 */       result.deleteCharAt(result.length() - 1);
/* 142:    */     }
/* 143:164 */     else if (!TextUtils.isEmpty(this.groupByColumnName))
/* 144:    */     {
/* 145:166 */       result.append(this.groupByColumnName);
/* 146:    */     }
/* 147:    */     else
/* 148:    */     {
/* 149:169 */       result.append("*");
/* 150:    */     }
/* 151:172 */     result.append(" FROM ").append(this.selector.tableName);
/* 152:173 */     if ((this.selector.whereBuilder != null) && (this.selector.whereBuilder.getWhereItemSize() > 0)) {
/* 153:175 */       result.append(" WHERE ").append(this.selector.whereBuilder.toString());
/* 154:    */     }
/* 155:177 */     if (!TextUtils.isEmpty(this.groupByColumnName))
/* 156:    */     {
/* 157:179 */       result.append(" GROUP BY ").append(this.groupByColumnName);
/* 158:180 */       if ((this.having != null) && (this.having.getWhereItemSize() > 0)) {
/* 159:182 */         result.append(" HAVING ").append(this.having.toString());
/* 160:    */       }
/* 161:    */     }
/* 162:185 */     if (this.selector.orderByList != null) {
/* 163:187 */       for (int i = 0; i < this.selector.orderByList.size(); i++) {
/* 164:189 */         result.append(" ORDER BY ").append(((Selector.OrderBy)this.selector.orderByList.get(i)).toString());
/* 165:    */       }
/* 166:    */     }
/* 167:192 */     if (this.selector.limit > 0)
/* 168:    */     {
/* 169:194 */       result.append(" LIMIT ").append(this.selector.limit);
/* 170:195 */       result.append(" OFFSET ").append(this.selector.offset);
/* 171:    */     }
/* 172:197 */     return result.toString();
/* 173:    */   }
/* 174:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.DbModelSelector
 * JD-Core Version:    0.7.0.1
 */