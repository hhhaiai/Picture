/*  1:   */ package com.lidroid.xutils.db.sqlite;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.DbUtils;
/*  4:   */ import com.lidroid.xutils.db.table.ColumnUtils;
/*  5:   */ import com.lidroid.xutils.db.table.Foreign;
/*  6:   */ import com.lidroid.xutils.db.table.Table;
/*  7:   */ import com.lidroid.xutils.exception.DbException;
/*  8:   */ import java.util.List;
/*  9:   */ 
/* 10:   */ public class ForeignLazyLoader<T>
/* 11:   */ {
/* 12:   */   private final Foreign foreignColumn;
/* 13:   */   private Object columnValue;
/* 14:   */   
/* 15:   */   public ForeignLazyLoader(Foreign foreignColumn, Object value)
/* 16:   */   {
/* 17:32 */     this.foreignColumn = foreignColumn;
/* 18:33 */     this.columnValue = ColumnUtils.convert2DbColumnValueIfNeeded(value);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public List<T> getAllFromDb()
/* 22:   */     throws DbException
/* 23:   */   {
/* 24:38 */     List<T> entities = null;
/* 25:39 */     Table table = this.foreignColumn.getTable();
/* 26:40 */     if (table != null) {
/* 27:42 */       entities = table.db.findAll(Selector.from(this.foreignColumn.getForeignEntityType()).where(this.foreignColumn.getForeignColumnName(), "=", this.columnValue));
/* 28:   */     }
/* 29:44 */     return entities;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public T getFirstFromDb()
/* 33:   */     throws DbException
/* 34:   */   {
/* 35:49 */     T entity = null;
/* 36:50 */     Table table = this.foreignColumn.getTable();
/* 37:51 */     if (table != null) {
/* 38:53 */       entity = table.db.findFirst(Selector.from(this.foreignColumn.getForeignEntityType()).where(this.foreignColumn.getForeignColumnName(), "=", this.columnValue));
/* 39:   */     }
/* 40:55 */     return entity;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setColumnValue(Object value)
/* 44:   */   {
/* 45:60 */     this.columnValue = ColumnUtils.convert2DbColumnValueIfNeeded(value);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public Object getColumnValue()
/* 49:   */   {
/* 50:65 */     return this.columnValue;
/* 51:   */   }
/* 52:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.ForeignLazyLoader
 * JD-Core Version:    0.7.0.1
 */