/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.DbUtils;
/*   4:    */ import com.lidroid.xutils.db.table.Column;
/*   5:    */ import com.lidroid.xutils.db.table.ColumnUtils;
/*   6:    */ import com.lidroid.xutils.db.table.Finder;
/*   7:    */ import com.lidroid.xutils.db.table.Id;
/*   8:    */ import com.lidroid.xutils.db.table.KeyValue;
/*   9:    */ import com.lidroid.xutils.db.table.Table;
/*  10:    */ import com.lidroid.xutils.db.table.TableUtils;
/*  11:    */ import com.lidroid.xutils.exception.DbException;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.Collection;
/*  14:    */ import java.util.Collections;
/*  15:    */ import java.util.HashMap;
/*  16:    */ import java.util.HashSet;
/*  17:    */ import java.util.List;
/*  18:    */ 
/*  19:    */ public class SqlInfoBuilder
/*  20:    */ {
/*  21:    */   public static SqlInfo buildInsertSqlInfo(DbUtils db, Object entity)
/*  22:    */     throws DbException
/*  23:    */   {
/*  24: 40 */     List<KeyValue> keyValueList = entity2KeyValueList(db, entity);
/*  25: 41 */     if (keyValueList.size() == 0) {
/*  26: 42 */       return null;
/*  27:    */     }
/*  28: 44 */     SqlInfo result = new SqlInfo();
/*  29: 45 */     StringBuffer sqlBuffer = new StringBuffer();
/*  30:    */     
/*  31: 47 */     sqlBuffer.append("INSERT INTO ");
/*  32: 48 */     sqlBuffer.append(TableUtils.getTableName(entity.getClass()));
/*  33: 49 */     sqlBuffer.append(" (");
/*  34: 50 */     for (KeyValue kv : keyValueList)
/*  35:    */     {
/*  36: 52 */       sqlBuffer.append(kv.key).append(",");
/*  37: 53 */       result.addBindArgWithoutConverter(kv.value);
/*  38:    */     }
/*  39: 55 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/*  40: 56 */     sqlBuffer.append(") VALUES (");
/*  41:    */     
/*  42: 58 */     int length = keyValueList.size();
/*  43: 59 */     for (int i = 0; i < length; i++) {
/*  44: 61 */       sqlBuffer.append("?,");
/*  45:    */     }
/*  46: 63 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/*  47: 64 */     sqlBuffer.append(")");
/*  48:    */     
/*  49: 66 */     result.setSql(sqlBuffer.toString());
/*  50:    */     
/*  51: 68 */     return result;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static SqlInfo buildReplaceSqlInfo(DbUtils db, Object entity)
/*  55:    */     throws DbException
/*  56:    */   {
/*  57: 77 */     List<KeyValue> keyValueList = entity2KeyValueList(db, entity);
/*  58: 78 */     if (keyValueList.size() == 0) {
/*  59: 79 */       return null;
/*  60:    */     }
/*  61: 81 */     SqlInfo result = new SqlInfo();
/*  62: 82 */     StringBuffer sqlBuffer = new StringBuffer();
/*  63:    */     
/*  64: 84 */     sqlBuffer.append("REPLACE INTO ");
/*  65: 85 */     sqlBuffer.append(TableUtils.getTableName(entity.getClass()));
/*  66: 86 */     sqlBuffer.append(" (");
/*  67: 87 */     for (KeyValue kv : keyValueList)
/*  68:    */     {
/*  69: 89 */       sqlBuffer.append(kv.key).append(",");
/*  70: 90 */       result.addBindArgWithoutConverter(kv.value);
/*  71:    */     }
/*  72: 92 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/*  73: 93 */     sqlBuffer.append(") VALUES (");
/*  74:    */     
/*  75: 95 */     int length = keyValueList.size();
/*  76: 96 */     for (int i = 0; i < length; i++) {
/*  77: 98 */       sqlBuffer.append("?,");
/*  78:    */     }
/*  79:100 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/*  80:101 */     sqlBuffer.append(")");
/*  81:    */     
/*  82:103 */     result.setSql(sqlBuffer.toString());
/*  83:    */     
/*  84:105 */     return result;
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static String buildDeleteSqlByTableName(String tableName)
/*  88:    */   {
/*  89:113 */     return "DELETE FROM " + tableName;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static SqlInfo buildDeleteSqlInfo(DbUtils db, Object entity)
/*  93:    */     throws DbException
/*  94:    */   {
/*  95:118 */     SqlInfo result = new SqlInfo();
/*  96:    */     
/*  97:120 */     Class<?> entityType = entity.getClass();
/*  98:121 */     Table table = Table.get(db, entityType);
/*  99:122 */     Id id = table.id;
/* 100:123 */     Object idValue = id.getColumnValue(entity);
/* 101:125 */     if (idValue == null) {
/* 102:127 */       throw new DbException("this entity[" + entity.getClass() + "]'s id value is null");
/* 103:    */     }
/* 104:129 */     StringBuilder sb = new StringBuilder(buildDeleteSqlByTableName(table.tableName));
/* 105:130 */     sb.append(" WHERE ").append(WhereBuilder.b(id.getColumnName(), "=", idValue));
/* 106:    */     
/* 107:132 */     result.setSql(sb.toString());
/* 108:    */     
/* 109:134 */     return result;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static SqlInfo buildDeleteSqlInfo(DbUtils db, Class<?> entityType, Object idValue)
/* 113:    */     throws DbException
/* 114:    */   {
/* 115:139 */     SqlInfo result = new SqlInfo();
/* 116:    */     
/* 117:141 */     Table table = Table.get(db, entityType);
/* 118:142 */     Id id = table.id;
/* 119:144 */     if (idValue == null) {
/* 120:146 */       throw new DbException("this entity[" + entityType + "]'s id value is null");
/* 121:    */     }
/* 122:148 */     StringBuilder sb = new StringBuilder(buildDeleteSqlByTableName(table.tableName));
/* 123:149 */     sb.append(" WHERE ").append(WhereBuilder.b(id.getColumnName(), "=", idValue));
/* 124:    */     
/* 125:151 */     result.setSql(sb.toString());
/* 126:    */     
/* 127:153 */     return result;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static SqlInfo buildDeleteSqlInfo(DbUtils db, Class<?> entityType, WhereBuilder whereBuilder)
/* 131:    */     throws DbException
/* 132:    */   {
/* 133:158 */     Table table = Table.get(db, entityType);
/* 134:159 */     StringBuilder sb = new StringBuilder(buildDeleteSqlByTableName(table.tableName));
/* 135:161 */     if ((whereBuilder != null) && (whereBuilder.getWhereItemSize() > 0)) {
/* 136:163 */       sb.append(" WHERE ").append(whereBuilder.toString());
/* 137:    */     }
/* 138:166 */     return new SqlInfo(sb.toString());
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static SqlInfo buildUpdateSqlInfo(DbUtils db, Object entity, String... updateColumnNames)
/* 142:    */     throws DbException
/* 143:    */   {
/* 144:175 */     List<KeyValue> keyValueList = entity2KeyValueList(db, entity);
/* 145:176 */     if (keyValueList.size() == 0) {
/* 146:177 */       return null;
/* 147:    */     }
/* 148:179 */     HashSet<String> updateColumnNameSet = null;
/* 149:180 */     if ((updateColumnNames != null) && (updateColumnNames.length > 0))
/* 150:    */     {
/* 151:182 */       updateColumnNameSet = new HashSet(updateColumnNames.length);
/* 152:183 */       Collections.addAll(updateColumnNameSet, updateColumnNames);
/* 153:    */     }
/* 154:186 */     Class<?> entityType = entity.getClass();
/* 155:187 */     Table table = Table.get(db, entityType);
/* 156:188 */     Id id = table.id;
/* 157:189 */     Object idValue = id.getColumnValue(entity);
/* 158:191 */     if (idValue == null) {
/* 159:193 */       throw new DbException("this entity[" + entity.getClass() + "]'s id value is null");
/* 160:    */     }
/* 161:196 */     SqlInfo result = new SqlInfo();
/* 162:197 */     StringBuffer sqlBuffer = new StringBuffer("UPDATE ");
/* 163:198 */     sqlBuffer.append(table.tableName);
/* 164:199 */     sqlBuffer.append(" SET ");
/* 165:200 */     for (KeyValue kv : keyValueList) {
/* 166:202 */       if ((updateColumnNameSet == null) || (updateColumnNameSet.contains(kv.key)))
/* 167:    */       {
/* 168:204 */         sqlBuffer.append(kv.key).append("=?,");
/* 169:205 */         result.addBindArgWithoutConverter(kv.value);
/* 170:    */       }
/* 171:    */     }
/* 172:208 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/* 173:209 */     sqlBuffer.append(" WHERE ").append(WhereBuilder.b(id.getColumnName(), "=", idValue));
/* 174:    */     
/* 175:211 */     result.setSql(sqlBuffer.toString());
/* 176:212 */     return result;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public static SqlInfo buildUpdateSqlInfo(DbUtils db, Object entity, WhereBuilder whereBuilder, String... updateColumnNames)
/* 180:    */     throws DbException
/* 181:    */   {
/* 182:218 */     List<KeyValue> keyValueList = entity2KeyValueList(db, entity);
/* 183:219 */     if (keyValueList.size() == 0) {
/* 184:220 */       return null;
/* 185:    */     }
/* 186:222 */     HashSet<String> updateColumnNameSet = null;
/* 187:223 */     if ((updateColumnNames != null) && (updateColumnNames.length > 0))
/* 188:    */     {
/* 189:225 */       updateColumnNameSet = new HashSet(updateColumnNames.length);
/* 190:226 */       Collections.addAll(updateColumnNameSet, updateColumnNames);
/* 191:    */     }
/* 192:229 */     Class<?> entityType = entity.getClass();
/* 193:230 */     String tableName = TableUtils.getTableName(entityType);
/* 194:    */     
/* 195:232 */     SqlInfo result = new SqlInfo();
/* 196:233 */     StringBuffer sqlBuffer = new StringBuffer("UPDATE ");
/* 197:234 */     sqlBuffer.append(tableName);
/* 198:235 */     sqlBuffer.append(" SET ");
/* 199:236 */     for (KeyValue kv : keyValueList) {
/* 200:238 */       if ((updateColumnNameSet == null) || (updateColumnNameSet.contains(kv.key)))
/* 201:    */       {
/* 202:240 */         sqlBuffer.append(kv.key).append("=?,");
/* 203:241 */         result.addBindArgWithoutConverter(kv.value);
/* 204:    */       }
/* 205:    */     }
/* 206:244 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/* 207:245 */     if ((whereBuilder != null) && (whereBuilder.getWhereItemSize() > 0)) {
/* 208:247 */       sqlBuffer.append(" WHERE ").append(whereBuilder.toString());
/* 209:    */     }
/* 210:250 */     result.setSql(sqlBuffer.toString());
/* 211:251 */     return result;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static SqlInfo buildCreateTableSqlInfo(DbUtils db, Class<?> entityType)
/* 215:    */     throws DbException
/* 216:    */   {
/* 217:259 */     Table table = Table.get(db, entityType);
/* 218:260 */     Id id = table.id;
/* 219:    */     
/* 220:262 */     StringBuffer sqlBuffer = new StringBuffer();
/* 221:263 */     sqlBuffer.append("CREATE TABLE IF NOT EXISTS ");
/* 222:264 */     sqlBuffer.append(table.tableName);
/* 223:265 */     sqlBuffer.append(" ( ");
/* 224:267 */     if (id.isAutoIncrement()) {
/* 225:269 */       sqlBuffer.append("\"").append(id.getColumnName()).append("\"  ").append("INTEGER PRIMARY KEY AUTOINCREMENT,");
/* 226:    */     } else {
/* 227:272 */       sqlBuffer.append("\"").append(id.getColumnName()).append("\"  ").append(id.getColumnDbType()).append(" PRIMARY KEY,");
/* 228:    */     }
/* 229:275 */     Collection<Column> columns = table.columnMap.values();
/* 230:276 */     for (Column column : columns) {
/* 231:278 */       if (!(column instanceof Finder))
/* 232:    */       {
/* 233:282 */         sqlBuffer.append("\"").append(column.getColumnName()).append("\"  ");
/* 234:283 */         sqlBuffer.append(column.getColumnDbType());
/* 235:284 */         if (ColumnUtils.isUnique(column.getColumnField())) {
/* 236:286 */           sqlBuffer.append(" UNIQUE");
/* 237:    */         }
/* 238:288 */         if (ColumnUtils.isNotNull(column.getColumnField())) {
/* 239:290 */           sqlBuffer.append(" NOT NULL");
/* 240:    */         }
/* 241:292 */         String check = ColumnUtils.getCheck(column.getColumnField());
/* 242:293 */         if (check != null) {
/* 243:295 */           sqlBuffer.append(" CHECK(").append(check).append(")");
/* 244:    */         }
/* 245:297 */         sqlBuffer.append(",");
/* 246:    */       }
/* 247:    */     }
/* 248:300 */     sqlBuffer.deleteCharAt(sqlBuffer.length() - 1);
/* 249:301 */     sqlBuffer.append(" )");
/* 250:302 */     return new SqlInfo(sqlBuffer.toString());
/* 251:    */   }
/* 252:    */   
/* 253:    */   private static KeyValue column2KeyValue(Object entity, Column column)
/* 254:    */   {
/* 255:307 */     KeyValue kv = null;
/* 256:308 */     String key = column.getColumnName();
/* 257:309 */     if (key != null)
/* 258:    */     {
/* 259:311 */       Object value = column.getColumnValue(entity);
/* 260:312 */       value = value == null ? column.getDefaultValue() : value;
/* 261:313 */       kv = new KeyValue(key, value);
/* 262:    */     }
/* 263:315 */     return kv;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static List<KeyValue> entity2KeyValueList(DbUtils db, Object entity)
/* 267:    */   {
/* 268:321 */     List<KeyValue> keyValueList = new ArrayList();
/* 269:    */     
/* 270:323 */     Class<?> entityType = entity.getClass();
/* 271:324 */     Table table = Table.get(db, entityType);
/* 272:325 */     Id id = table.id;
/* 273:327 */     if (!id.isAutoIncrement())
/* 274:    */     {
/* 275:329 */       Object idValue = id.getColumnValue(entity);
/* 276:330 */       KeyValue kv = new KeyValue(id.getColumnName(), idValue);
/* 277:331 */       keyValueList.add(kv);
/* 278:    */     }
/* 279:334 */     Collection<Column> columns = table.columnMap.values();
/* 280:335 */     for (Column column : columns) {
/* 281:337 */       if (!(column instanceof Finder))
/* 282:    */       {
/* 283:341 */         KeyValue kv = column2KeyValue(entity, column);
/* 284:342 */         if (kv != null) {
/* 285:344 */           keyValueList.add(kv);
/* 286:    */         }
/* 287:    */       }
/* 288:    */     }
/* 289:348 */     return keyValueList;
/* 290:    */   }
/* 291:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.SqlInfoBuilder
 * JD-Core Version:    0.7.0.1
 */