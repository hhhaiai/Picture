/*   1:    */ package com.lidroid.xutils.db.sqlite;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.db.converter.ColumnConverterFactory;
/*   5:    */ import com.lidroid.xutils.db.table.ColumnUtils;
/*   6:    */ import java.lang.reflect.Array;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ 
/*  11:    */ public class WhereBuilder
/*  12:    */ {
/*  13:    */   private final List<String> whereItems;
/*  14:    */   
/*  15:    */   private WhereBuilder()
/*  16:    */   {
/*  17: 37 */     this.whereItems = new ArrayList();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static WhereBuilder b()
/*  21:    */   {
/*  22: 47 */     return new WhereBuilder();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static WhereBuilder b(String columnName, String op, Object value)
/*  26:    */   {
/*  27: 61 */     WhereBuilder result = new WhereBuilder();
/*  28: 62 */     result.appendCondition(null, columnName, op, value);
/*  29: 63 */     return result;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public WhereBuilder and(String columnName, String op, Object value)
/*  33:    */   {
/*  34: 77 */     appendCondition(this.whereItems.size() == 0 ? null : "AND", columnName, op, value);
/*  35: 78 */     return this;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public WhereBuilder or(String columnName, String op, Object value)
/*  39:    */   {
/*  40: 92 */     appendCondition(this.whereItems.size() == 0 ? null : "OR", columnName, op, value);
/*  41: 93 */     return this;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public WhereBuilder expr(String expr)
/*  45:    */   {
/*  46: 98 */     this.whereItems.add(" " + expr);
/*  47: 99 */     return this;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public WhereBuilder expr(String columnName, String op, Object value)
/*  51:    */   {
/*  52:104 */     appendCondition(null, columnName, op, value);
/*  53:105 */     return this;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int getWhereItemSize()
/*  57:    */   {
/*  58:110 */     return this.whereItems.size();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public String toString()
/*  62:    */   {
/*  63:116 */     if (this.whereItems.size() == 0) {
/*  64:118 */       return "";
/*  65:    */     }
/*  66:120 */     StringBuilder sb = new StringBuilder();
/*  67:121 */     for (String item : this.whereItems) {
/*  68:123 */       sb.append(item);
/*  69:    */     }
/*  70:125 */     return sb.toString();
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void appendCondition(String conj, String columnName, String op, Object value)
/*  74:    */   {
/*  75:130 */     StringBuilder sqlSb = new StringBuilder();
/*  76:132 */     if (this.whereItems.size() > 0) {
/*  77:134 */       sqlSb.append(" ");
/*  78:    */     }
/*  79:138 */     if (!TextUtils.isEmpty(conj)) {
/*  80:140 */       sqlSb.append(conj + " ");
/*  81:    */     }
/*  82:144 */     sqlSb.append(columnName);
/*  83:147 */     if ("!=".equals(op)) {
/*  84:149 */       op = "<>";
/*  85:150 */     } else if ("==".equals(op)) {
/*  86:152 */       op = "=";
/*  87:    */     }
/*  88:156 */     if (value == null)
/*  89:    */     {
/*  90:158 */       if ("=".equals(op)) {
/*  91:160 */         sqlSb.append(" IS NULL");
/*  92:161 */       } else if ("<>".equals(op)) {
/*  93:163 */         sqlSb.append(" IS NOT NULL");
/*  94:    */       } else {
/*  95:166 */         sqlSb.append(" " + op + " NULL");
/*  96:    */       }
/*  97:    */     }
/*  98:    */     else
/*  99:    */     {
/* 100:170 */       sqlSb.append(" " + op + " ");
/* 101:172 */       if ("IN".equalsIgnoreCase(op))
/* 102:    */       {
/* 103:174 */         Iterable<?> items = null;
/* 104:    */         int i;
/* 105:175 */         if ((value instanceof Iterable))
/* 106:    */         {
/* 107:177 */           items = (Iterable)value;
/* 108:    */         }
/* 109:178 */         else if (value.getClass().isArray())
/* 110:    */         {
/* 111:180 */           ArrayList<Object> arrayList = new ArrayList();
/* 112:181 */           int len = Array.getLength(value);
/* 113:182 */           for (i = 0; i < len; i++) {
/* 114:184 */             arrayList.add(Array.get(value, i));
/* 115:    */           }
/* 116:186 */           items = arrayList;
/* 117:    */         }
/* 118:188 */         if (items != null)
/* 119:    */         {
/* 120:190 */           StringBuffer stringBuffer = new StringBuffer("(");
/* 121:191 */           for (Object item : items)
/* 122:    */           {
/* 123:193 */             Object itemColValue = ColumnUtils.convert2DbColumnValueIfNeeded(item);
/* 124:194 */             if (ColumnDbType.TEXT.equals(ColumnConverterFactory.getDbColumnType(itemColValue.getClass())))
/* 125:    */             {
/* 126:196 */               String valueStr = itemColValue.toString();
/* 127:197 */               if (valueStr.indexOf('\'') != -1) {
/* 128:199 */                 valueStr = valueStr.replace("'", "''");
/* 129:    */               }
/* 130:201 */               stringBuffer.append("'" + valueStr + "'");
/* 131:    */             }
/* 132:    */             else
/* 133:    */             {
/* 134:204 */               stringBuffer.append(itemColValue);
/* 135:    */             }
/* 136:206 */             stringBuffer.append(",");
/* 137:    */           }
/* 138:208 */           stringBuffer.deleteCharAt(stringBuffer.length() - 1);
/* 139:209 */           stringBuffer.append(")");
/* 140:210 */           sqlSb.append(stringBuffer.toString());
/* 141:    */         }
/* 142:    */         else
/* 143:    */         {
/* 144:213 */           throw new IllegalArgumentException("value must be an Array or an Iterable.");
/* 145:    */         }
/* 146:    */       }
/* 147:215 */       else if ("BETWEEN".equalsIgnoreCase(op))
/* 148:    */       {
/* 149:217 */         Iterable<?> items = null;
/* 150:218 */         if ((value instanceof Iterable))
/* 151:    */         {
/* 152:220 */           items = (Iterable)value;
/* 153:    */         }
/* 154:221 */         else if (value.getClass().isArray())
/* 155:    */         {
/* 156:223 */           ArrayList<Object> arrayList = new ArrayList();
/* 157:224 */           int len = Array.getLength(value);
/* 158:225 */           for (int i = 0; i < len; i++) {
/* 159:227 */             arrayList.add(Array.get(value, i));
/* 160:    */           }
/* 161:229 */           items = arrayList;
/* 162:    */         }
/* 163:231 */         if (items != null)
/* 164:    */         {
/* 165:233 */           Iterator<?> iterator = items.iterator();
/* 166:234 */           if (!iterator.hasNext()) {
/* 167:235 */             throw new IllegalArgumentException("value must have tow items.");
/* 168:    */           }
/* 169:236 */           Object start = iterator.next();
/* 170:237 */           if (!iterator.hasNext()) {
/* 171:238 */             throw new IllegalArgumentException("value must have tow items.");
/* 172:    */           }
/* 173:239 */           Object end = iterator.next();
/* 174:    */           
/* 175:241 */           Object startColValue = ColumnUtils.convert2DbColumnValueIfNeeded(start);
/* 176:242 */           Object endColValue = ColumnUtils.convert2DbColumnValueIfNeeded(end);
/* 177:244 */           if (ColumnDbType.TEXT.equals(ColumnConverterFactory.getDbColumnType(startColValue.getClass())))
/* 178:    */           {
/* 179:246 */             String startStr = startColValue.toString();
/* 180:247 */             if (startStr.indexOf('\'') != -1) {
/* 181:249 */               startStr = startStr.replace("'", "''");
/* 182:    */             }
/* 183:251 */             String endStr = endColValue.toString();
/* 184:252 */             if (endStr.indexOf('\'') != -1) {
/* 185:254 */               endStr = endStr.replace("'", "''");
/* 186:    */             }
/* 187:256 */             sqlSb.append("'" + startStr + "'");
/* 188:257 */             sqlSb.append(" AND ");
/* 189:258 */             sqlSb.append("'" + endStr + "'");
/* 190:    */           }
/* 191:    */           else
/* 192:    */           {
/* 193:261 */             sqlSb.append(startColValue);
/* 194:262 */             sqlSb.append(" AND ");
/* 195:263 */             sqlSb.append(endColValue);
/* 196:    */           }
/* 197:    */         }
/* 198:    */         else
/* 199:    */         {
/* 200:267 */           throw new IllegalArgumentException("value must be an Array or an Iterable.");
/* 201:    */         }
/* 202:    */       }
/* 203:    */       else
/* 204:    */       {
/* 205:271 */         value = ColumnUtils.convert2DbColumnValueIfNeeded(value);
/* 206:272 */         if (ColumnDbType.TEXT.equals(ColumnConverterFactory.getDbColumnType(value.getClass())))
/* 207:    */         {
/* 208:274 */           String valueStr = value.toString();
/* 209:275 */           if (valueStr.indexOf('\'') != -1) {
/* 210:277 */             valueStr = valueStr.replace("'", "''");
/* 211:    */           }
/* 212:279 */           sqlSb.append("'" + valueStr + "'");
/* 213:    */         }
/* 214:    */         else
/* 215:    */         {
/* 216:282 */           sqlSb.append(value);
/* 217:    */         }
/* 218:    */       }
/* 219:    */     }
/* 220:286 */     this.whereItems.add(sqlSb.toString());
/* 221:    */   }
/* 222:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.WhereBuilder
 * JD-Core Version:    0.7.0.1
 */