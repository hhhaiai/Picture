/*  1:   */ package com.lidroid.xutils.db.sqlite;
/*  2:   */ 
/*  3:   */ public enum ColumnDbType
/*  4:   */ {
/*  5: 9 */   INTEGER("INTEGER"),  REAL("REAL"),  TEXT("TEXT"),  BLOB("BLOB");
/*  6:   */   
/*  7:   */   private String value;
/*  8:   */   
/*  9:   */   private ColumnDbType(String value)
/* 10:   */   {
/* 11:15 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String toString()
/* 15:   */   {
/* 16:21 */     return this.value;
/* 17:   */   }
/* 18:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.db.sqlite.ColumnDbType
 * JD-Core Version:    0.7.0.1
 */