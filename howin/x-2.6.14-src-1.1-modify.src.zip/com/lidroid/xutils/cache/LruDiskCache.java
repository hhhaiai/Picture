/*    1:     */ package com.lidroid.xutils.cache;
/*    2:     */ 
/*    3:     */ import com.lidroid.xutils.util.IOUtils;
/*    4:     */ import com.lidroid.xutils.util.LogUtils;
/*    5:     */ import java.io.BufferedWriter;
/*    6:     */ import java.io.ByteArrayOutputStream;
/*    7:     */ import java.io.Closeable;
/*    8:     */ import java.io.EOFException;
/*    9:     */ import java.io.File;
/*   10:     */ import java.io.FileInputStream;
/*   11:     */ import java.io.FileNotFoundException;
/*   12:     */ import java.io.FileOutputStream;
/*   13:     */ import java.io.FilterOutputStream;
/*   14:     */ import java.io.IOException;
/*   15:     */ import java.io.InputStream;
/*   16:     */ import java.io.InputStreamReader;
/*   17:     */ import java.io.OutputStream;
/*   18:     */ import java.io.OutputStreamWriter;
/*   19:     */ import java.io.Reader;
/*   20:     */ import java.io.StringWriter;
/*   21:     */ import java.io.UnsupportedEncodingException;
/*   22:     */ import java.io.Writer;
/*   23:     */ import java.nio.charset.Charset;
/*   24:     */ import java.util.ArrayList;
/*   25:     */ import java.util.Arrays;
/*   26:     */ import java.util.Collection;
/*   27:     */ import java.util.Iterator;
/*   28:     */ import java.util.LinkedHashMap;
/*   29:     */ import java.util.Map.Entry;
/*   30:     */ import java.util.Set;
/*   31:     */ import java.util.concurrent.Callable;
/*   32:     */ import java.util.concurrent.LinkedBlockingQueue;
/*   33:     */ import java.util.concurrent.ThreadPoolExecutor;
/*   34:     */ import java.util.concurrent.TimeUnit;
/*   35:     */ 
/*   36:     */ public final class LruDiskCache
/*   37:     */   implements Closeable
/*   38:     */ {
/*   39:     */   static final String JOURNAL_FILE = "journal";
/*   40:     */   static final String JOURNAL_FILE_TEMP = "journal.tmp";
/*   41:     */   static final String JOURNAL_FILE_BACKUP = "journal.bkp";
/*   42:     */   static final String MAGIC = "libcore.io.DiskLruCache";
/*   43:     */   static final String VERSION = "1";
/*   44:     */   static final long ANY_SEQUENCE_NUMBER = -1L;
/*   45:     */   private static final char CLEAN = 'C';
/*   46:     */   private static final char UPDATE = 'U';
/*   47:     */   private static final char DELETE = 'D';
/*   48:     */   private static final char READ = 'R';
/*   49:     */   private static final char EXPIRY_PREFIX = 't';
/*   50:     */   private final File directory;
/*   51:     */   private final File journalFile;
/*   52:     */   private final File journalFileTmp;
/*   53:     */   private final File journalFileBackup;
/*   54:     */   private final int appVersion;
/*   55:     */   private long maxSize;
/*   56:     */   private final int valueCount;
/*   57: 133 */   private long size = 0L;
/*   58:     */   private Writer journalWriter;
/*   59: 135 */   private final LinkedHashMap<String, Entry> lruEntries = new LinkedHashMap(0, 0.75F, true);
/*   60:     */   private int redundantOpCount;
/*   61: 143 */   private long nextSequenceNumber = 0L;
/*   62: 148 */   final ThreadPoolExecutor executorService = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue());
/*   63: 149 */   private final Callable<Void> cleanupCallable = new Callable()
/*   64:     */   {
/*   65:     */     public Void call()
/*   66:     */       throws Exception
/*   67:     */     {
/*   68: 153 */       synchronized (LruDiskCache.this)
/*   69:     */       {
/*   70: 155 */         if (LruDiskCache.this.journalWriter == null) {
/*   71: 157 */           return null;
/*   72:     */         }
/*   73: 159 */         LruDiskCache.this.trimToSize();
/*   74: 160 */         if (LruDiskCache.this.journalRebuildRequired())
/*   75:     */         {
/*   76: 162 */           LruDiskCache.this.rebuildJournal();
/*   77: 163 */           LruDiskCache.this.redundantOpCount = 0;
/*   78:     */         }
/*   79:     */       }
/*   80: 166 */       return null;
/*   81:     */     }
/*   82:     */   };
/*   83:     */   
/*   84:     */   private LruDiskCache(File directory, int appVersion, int valueCount, long maxSize)
/*   85:     */   {
/*   86: 172 */     this.directory = directory;
/*   87: 173 */     this.appVersion = appVersion;
/*   88: 174 */     this.journalFile = new File(directory, "journal");
/*   89: 175 */     this.journalFileTmp = new File(directory, "journal.tmp");
/*   90: 176 */     this.journalFileBackup = new File(directory, "journal.bkp");
/*   91: 177 */     this.valueCount = valueCount;
/*   92: 178 */     this.maxSize = maxSize;
/*   93:     */   }
/*   94:     */   
/*   95:     */   public static LruDiskCache open(File directory, int appVersion, int valueCount, long maxSize)
/*   96:     */     throws IOException
/*   97:     */   {
/*   98: 196 */     if (maxSize <= 0L) {
/*   99: 198 */       throw new IllegalArgumentException("maxSize <= 0");
/*  100:     */     }
/*  101: 200 */     if (valueCount <= 0) {
/*  102: 202 */       throw new IllegalArgumentException("valueCount <= 0");
/*  103:     */     }
/*  104: 206 */     File backupFile = new File(directory, "journal.bkp");
/*  105: 207 */     if (backupFile.exists())
/*  106:     */     {
/*  107: 209 */       File journalFile = new File(directory, "journal");
/*  108: 211 */       if (journalFile.exists()) {
/*  109: 213 */         backupFile.delete();
/*  110:     */       } else {
/*  111: 216 */         renameTo(backupFile, journalFile, false);
/*  112:     */       }
/*  113:     */     }
/*  114: 221 */     LruDiskCache cache = new LruDiskCache(directory, appVersion, valueCount, maxSize);
/*  115: 222 */     if (cache.journalFile.exists()) {
/*  116:     */       try
/*  117:     */       {
/*  118: 226 */         cache.readJournal();
/*  119: 227 */         cache.processJournal();
/*  120: 228 */         cache.journalWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(cache.journalFile, true), "US-ASCII"));
/*  121: 229 */         return cache;
/*  122:     */       }
/*  123:     */       catch (Throwable journalIsCorrupt)
/*  124:     */       {
/*  125: 232 */         LogUtils.e("DiskLruCache " + directory + " is corrupt: " + journalIsCorrupt.getMessage() + ", removing", journalIsCorrupt);
/*  126: 233 */         cache.delete();
/*  127:     */       }
/*  128:     */     }
/*  129: 238 */     if ((directory.exists()) || (directory.mkdirs()))
/*  130:     */     {
/*  131: 240 */       cache = new LruDiskCache(directory, appVersion, valueCount, maxSize);
/*  132: 241 */       cache.rebuildJournal();
/*  133:     */     }
/*  134: 243 */     return cache;
/*  135:     */   }
/*  136:     */   
/*  137:     */   private void readJournal()
/*  138:     */     throws IOException
/*  139:     */   {
/*  140: 248 */     StrictLineReader reader = null;
/*  141:     */     try
/*  142:     */     {
/*  143: 251 */       reader = new StrictLineReader(new FileInputStream(this.journalFile));
/*  144: 252 */       String magic = reader.readLine();
/*  145: 253 */       String version = reader.readLine();
/*  146: 254 */       String appVersionString = reader.readLine();
/*  147: 255 */       String valueCountString = reader.readLine();
/*  148: 256 */       String blank = reader.readLine();
/*  149: 257 */       if ((!"libcore.io.DiskLruCache".equals(magic)) || (!"1".equals(version)) || (!Integer.toString(this.appVersion).equals(appVersionString)) || 
/*  150: 258 */         (!Integer.toString(this.valueCount).equals(valueCountString)) || (!"".equals(blank))) {
/*  151: 260 */         throw new IOException("unexpected journal header: [" + magic + ", " + version + ", " + valueCountString + ", " + blank + "]");
/*  152:     */       }
/*  153: 263 */       int lineCount = 0;
/*  154:     */       try
/*  155:     */       {
/*  156:     */         for (;;)
/*  157:     */         {
/*  158: 268 */           readJournalLine(reader.readLine());
/*  159: 269 */           lineCount++;
/*  160:     */         }
/*  161: 277 */         localObject = finally;
/*  162:     */       }
/*  163:     */       catch (EOFException localEOFException)
/*  164:     */       {
/*  165: 275 */         this.redundantOpCount = (lineCount - this.lruEntries.size());
/*  166:     */       }
/*  167:     */       return;
/*  168:     */     }
/*  169:     */     finally
/*  170:     */     {
/*  171: 278 */       IOUtils.closeQuietly(reader);
/*  172: 279 */       throw localObject;IOUtils.closeQuietly(reader);
/*  173:     */     }
/*  174:     */   }
/*  175:     */   
/*  176:     */   private void readJournalLine(String line)
/*  177:     */     throws IOException
/*  178:     */   {
/*  179: 284 */     int firstSpace = line.indexOf(' ');
/*  180: 285 */     char lineTag = '\000';
/*  181: 286 */     if (firstSpace == 1) {
/*  182: 288 */       lineTag = line.charAt(0);
/*  183:     */     } else {
/*  184: 291 */       throw new IOException("unexpected journal line: " + line);
/*  185:     */     }
/*  186: 294 */     int keyBegin = firstSpace + 1;
/*  187: 295 */     int secondSpace = line.indexOf(' ', keyBegin);
/*  188:     */     String diskKey;
/*  189: 297 */     if (secondSpace == -1)
/*  190:     */     {
/*  191: 299 */       String diskKey = line.substring(keyBegin);
/*  192: 300 */       if (lineTag == 'D') {
/*  193: 302 */         this.lruEntries.remove(diskKey);
/*  194:     */       }
/*  195:     */     }
/*  196:     */     else
/*  197:     */     {
/*  198: 307 */       diskKey = line.substring(keyBegin, secondSpace);
/*  199:     */     }
/*  200: 310 */     Entry entry = (Entry)this.lruEntries.get(diskKey);
/*  201: 311 */     if (entry == null)
/*  202:     */     {
/*  203: 313 */       entry = new Entry(diskKey, null);
/*  204: 314 */       this.lruEntries.put(diskKey, entry);
/*  205:     */     }
/*  206: 317 */     switch (lineTag)
/*  207:     */     {
/*  208:     */     case 'C': 
/*  209: 321 */       entry.readable = true;
/*  210: 322 */       entry.currentEditor = null;
/*  211: 323 */       String[] parts = line.substring(secondSpace + 1).split(" ");
/*  212: 324 */       if (parts.length > 0) {
/*  213:     */         try
/*  214:     */         {
/*  215: 328 */           if (parts[0].charAt(0) == 't')
/*  216:     */           {
/*  217: 330 */             entry.expiryTimestamp = Long.valueOf(parts[0].substring(1)).longValue();
/*  218: 331 */             entry.setLengths(parts, 1);
/*  219:     */           }
/*  220:     */           else
/*  221:     */           {
/*  222: 334 */             entry.expiryTimestamp = 9223372036854775807L;
/*  223: 335 */             entry.setLengths(parts, 0);
/*  224:     */           }
/*  225:     */         }
/*  226:     */         catch (Throwable e)
/*  227:     */         {
/*  228: 339 */           throw new IOException("unexpected journal line: " + line);
/*  229:     */         }
/*  230:     */       }
/*  231:     */       break;
/*  232:     */     case 'U': 
/*  233: 346 */       entry.currentEditor = new Editor(entry, null);
/*  234: 347 */       break;
/*  235:     */     case 'R': 
/*  236:     */       break;
/*  237:     */     default: 
/*  238: 356 */       throw new IOException("unexpected journal line: " + line);
/*  239:     */     }
/*  240:     */   }
/*  241:     */   
/*  242:     */   private void processJournal()
/*  243:     */     throws IOException
/*  244:     */   {
/*  245: 367 */     deleteIfExists(this.journalFileTmp);
/*  246: 368 */     for (Iterator<Entry> i = this.lruEntries.values().iterator(); i.hasNext();)
/*  247:     */     {
/*  248: 370 */       Entry entry = (Entry)i.next();
/*  249: 371 */       if (entry.currentEditor == null)
/*  250:     */       {
/*  251: 373 */         for (int t = 0; t < this.valueCount; t++) {
/*  252: 375 */           this.size += entry.lengths[t];
/*  253:     */         }
/*  254:     */       }
/*  255:     */       else
/*  256:     */       {
/*  257: 379 */         entry.currentEditor = null;
/*  258: 380 */         for (int t = 0; t < this.valueCount; t++)
/*  259:     */         {
/*  260: 382 */           deleteIfExists(entry.getCleanFile(t));
/*  261: 383 */           deleteIfExists(entry.getDirtyFile(t));
/*  262:     */         }
/*  263: 385 */         i.remove();
/*  264:     */       }
/*  265:     */     }
/*  266:     */   }
/*  267:     */   
/*  268:     */   private synchronized void rebuildJournal()
/*  269:     */     throws IOException
/*  270:     */   {
/*  271: 396 */     if (this.journalWriter != null) {
/*  272: 398 */       IOUtils.closeQuietly(this.journalWriter);
/*  273:     */     }
/*  274: 401 */     Writer writer = null;
/*  275:     */     try
/*  276:     */     {
/*  277: 404 */       writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.journalFileTmp), "US-ASCII"));
/*  278: 405 */       writer.write("libcore.io.DiskLruCache");
/*  279: 406 */       writer.write("\n");
/*  280: 407 */       writer.write("1");
/*  281: 408 */       writer.write("\n");
/*  282: 409 */       writer.write(Integer.toString(this.appVersion));
/*  283: 410 */       writer.write("\n");
/*  284: 411 */       writer.write(Integer.toString(this.valueCount));
/*  285: 412 */       writer.write("\n");
/*  286: 413 */       writer.write("\n");
/*  287: 415 */       for (Entry entry : this.lruEntries.values()) {
/*  288: 417 */         if (entry.currentEditor != null) {
/*  289: 419 */           writer.write("U " + entry.diskKey + '\n');
/*  290:     */         } else {
/*  291: 422 */           writer.write("C " + entry.diskKey + " " + 't' + entry.expiryTimestamp + entry.getLengths() + '\n');
/*  292:     */         }
/*  293:     */       }
/*  294:     */     }
/*  295:     */     finally
/*  296:     */     {
/*  297: 427 */       IOUtils.closeQuietly(writer);
/*  298:     */     }
/*  299: 430 */     if (this.journalFile.exists()) {
/*  300: 432 */       renameTo(this.journalFile, this.journalFileBackup, true);
/*  301:     */     }
/*  302: 434 */     renameTo(this.journalFileTmp, this.journalFile, false);
/*  303: 435 */     this.journalFileBackup.delete();
/*  304:     */     
/*  305: 437 */     this.journalWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.journalFile, true), "US-ASCII"));
/*  306:     */   }
/*  307:     */   
/*  308:     */   private static void deleteIfExists(File file)
/*  309:     */     throws IOException
/*  310:     */   {
/*  311: 442 */     if ((file.exists()) && (!file.delete())) {
/*  312: 444 */       throw new IOException();
/*  313:     */     }
/*  314:     */   }
/*  315:     */   
/*  316:     */   private static void renameTo(File from, File to, boolean deleteDestination)
/*  317:     */     throws IOException
/*  318:     */   {
/*  319: 450 */     if (deleteDestination) {
/*  320: 452 */       deleteIfExists(to);
/*  321:     */     }
/*  322: 454 */     if (!from.renameTo(to)) {
/*  323: 456 */       throw new IOException();
/*  324:     */     }
/*  325:     */   }
/*  326:     */   
/*  327:     */   public synchronized long getExpiryTimestamp(String key)
/*  328:     */     throws IOException
/*  329:     */   {
/*  330: 462 */     String diskKey = this.fileNameGenerator.generate(key);
/*  331: 463 */     checkNotClosed();
/*  332: 464 */     Entry entry = (Entry)this.lruEntries.get(diskKey);
/*  333: 465 */     if (entry == null) {
/*  334: 467 */       return 0L;
/*  335:     */     }
/*  336: 470 */     return entry.expiryTimestamp;
/*  337:     */   }
/*  338:     */   
/*  339:     */   public File getCacheFile(String key, int index)
/*  340:     */   {
/*  341: 476 */     String diskKey = this.fileNameGenerator.generate(key);
/*  342: 477 */     File result = new File(this.directory, diskKey + "." + index);
/*  343: 478 */     if (result.exists()) {
/*  344: 480 */       return result;
/*  345:     */     }
/*  346:     */     try
/*  347:     */     {
/*  348: 485 */       remove(key);
/*  349:     */     }
/*  350:     */     catch (IOException localIOException) {}
/*  351: 489 */     return null;
/*  352:     */   }
/*  353:     */   
/*  354:     */   public Snapshot get(String key)
/*  355:     */     throws IOException
/*  356:     */   {
/*  357: 495 */     String diskKey = this.fileNameGenerator.generate(key);
/*  358: 496 */     return getByDiskKey(diskKey);
/*  359:     */   }
/*  360:     */   
/*  361:     */   private synchronized Snapshot getByDiskKey(String diskKey)
/*  362:     */     throws IOException
/*  363:     */   {
/*  364: 506 */     checkNotClosed();
/*  365: 507 */     Entry entry = (Entry)this.lruEntries.get(diskKey);
/*  366: 508 */     if (entry == null) {
/*  367: 510 */       return null;
/*  368:     */     }
/*  369: 513 */     if (!entry.readable) {
/*  370: 515 */       return null;
/*  371:     */     }
/*  372: 519 */     if (entry.expiryTimestamp < System.currentTimeMillis())
/*  373:     */     {
/*  374: 521 */       for (int i = 0; i < this.valueCount; i++)
/*  375:     */       {
/*  376: 523 */         File file = entry.getCleanFile(i);
/*  377: 524 */         if ((file.exists()) && (!file.delete())) {
/*  378: 526 */           throw new IOException("failed to delete " + file);
/*  379:     */         }
/*  380: 528 */         this.size -= entry.lengths[i];
/*  381: 529 */         entry.lengths[i] = 0L;
/*  382:     */       }
/*  383: 531 */       this.redundantOpCount += 1;
/*  384: 532 */       this.journalWriter.append("D " + diskKey + '\n');
/*  385: 533 */       this.lruEntries.remove(diskKey);
/*  386: 534 */       if (journalRebuildRequired()) {
/*  387: 536 */         this.executorService.submit(this.cleanupCallable);
/*  388:     */       }
/*  389: 538 */       return null;
/*  390:     */     }
/*  391: 544 */     FileInputStream[] ins = new FileInputStream[this.valueCount];
/*  392:     */     try
/*  393:     */     {
/*  394: 547 */       for (int i = 0; i < this.valueCount; i++) {
/*  395: 549 */         ins[i] = new FileInputStream(entry.getCleanFile(i));
/*  396:     */       }
/*  397:     */     }
/*  398:     */     catch (FileNotFoundException e)
/*  399:     */     {
/*  400: 554 */       for (int i = 0; i < this.valueCount; i++)
/*  401:     */       {
/*  402: 556 */         if (ins[i] == null) {
/*  403:     */           break;
/*  404:     */         }
/*  405: 558 */         IOUtils.closeQuietly(ins[i]);
/*  406:     */       }
/*  407: 564 */       return null;
/*  408:     */     }
/*  409: 567 */     this.redundantOpCount += 1;
/*  410: 568 */     this.journalWriter.append("R " + diskKey + '\n');
/*  411: 569 */     if (journalRebuildRequired()) {
/*  412: 571 */       this.executorService.submit(this.cleanupCallable);
/*  413:     */     }
/*  414: 574 */     return new Snapshot(diskKey, entry.sequenceNumber, ins, entry.lengths, null);
/*  415:     */   }
/*  416:     */   
/*  417:     */   public Editor edit(String key)
/*  418:     */     throws IOException
/*  419:     */   {
/*  420: 583 */     String diskKey = this.fileNameGenerator.generate(key);
/*  421: 584 */     return editByDiskKey(diskKey, -1L);
/*  422:     */   }
/*  423:     */   
/*  424:     */   private synchronized Editor editByDiskKey(String diskKey, long expectedSequenceNumber)
/*  425:     */     throws IOException
/*  426:     */   {
/*  427: 589 */     checkNotClosed();
/*  428: 590 */     Entry entry = (Entry)this.lruEntries.get(diskKey);
/*  429: 591 */     if ((expectedSequenceNumber != -1L) && ((entry == null) || (entry.sequenceNumber != expectedSequenceNumber))) {
/*  430: 593 */       return null;
/*  431:     */     }
/*  432: 595 */     if (entry == null)
/*  433:     */     {
/*  434: 597 */       entry = new Entry(diskKey, null);
/*  435: 598 */       this.lruEntries.put(diskKey, entry);
/*  436:     */     }
/*  437: 599 */     else if (entry.currentEditor != null)
/*  438:     */     {
/*  439: 601 */       return null;
/*  440:     */     }
/*  441: 604 */     Editor editor = new Editor(entry, null);
/*  442: 605 */     entry.currentEditor = editor;
/*  443:     */     
/*  444:     */ 
/*  445: 608 */     this.journalWriter.write("U " + diskKey + '\n');
/*  446: 609 */     this.journalWriter.flush();
/*  447: 610 */     return editor;
/*  448:     */   }
/*  449:     */   
/*  450:     */   public File getDirectory()
/*  451:     */   {
/*  452: 618 */     return this.directory;
/*  453:     */   }
/*  454:     */   
/*  455:     */   public synchronized long getMaxSize()
/*  456:     */   {
/*  457: 627 */     return this.maxSize;
/*  458:     */   }
/*  459:     */   
/*  460:     */   public synchronized void setMaxSize(long maxSize)
/*  461:     */   {
/*  462: 636 */     this.maxSize = maxSize;
/*  463: 637 */     this.executorService.submit(this.cleanupCallable);
/*  464:     */   }
/*  465:     */   
/*  466:     */   public synchronized long size()
/*  467:     */   {
/*  468: 647 */     return this.size;
/*  469:     */   }
/*  470:     */   
/*  471:     */   private synchronized void completeEdit(Editor editor, boolean success)
/*  472:     */     throws IOException
/*  473:     */   {
/*  474: 652 */     Entry entry = editor.entry;
/*  475: 653 */     if (entry.currentEditor != editor) {
/*  476: 655 */       throw new IllegalStateException();
/*  477:     */     }
/*  478: 660 */     if ((success) && (!entry.readable)) {
/*  479: 662 */       for (int i = 0; i < this.valueCount; i++)
/*  480:     */       {
/*  481: 664 */         if (editor.written[i] == 0)
/*  482:     */         {
/*  483: 666 */           editor.abort();
/*  484: 667 */           throw new IllegalStateException("Newly created entry didn't create value for index " + i);
/*  485:     */         }
/*  486: 669 */         if (!entry.getDirtyFile(i).exists())
/*  487:     */         {
/*  488: 671 */           editor.abort();
/*  489: 672 */           return;
/*  490:     */         }
/*  491:     */       }
/*  492:     */     }
/*  493: 677 */     for (int i = 0; i < this.valueCount; i++)
/*  494:     */     {
/*  495: 679 */       File dirty = entry.getDirtyFile(i);
/*  496: 680 */       if (success)
/*  497:     */       {
/*  498: 682 */         if (dirty.exists())
/*  499:     */         {
/*  500: 684 */           File clean = entry.getCleanFile(i);
/*  501: 685 */           dirty.renameTo(clean);
/*  502: 686 */           long oldLength = entry.lengths[i];
/*  503: 687 */           long newLength = clean.length();
/*  504: 688 */           entry.lengths[i] = newLength;
/*  505: 689 */           this.size = (this.size - oldLength + newLength);
/*  506:     */         }
/*  507:     */       }
/*  508:     */       else {
/*  509: 693 */         deleteIfExists(dirty);
/*  510:     */       }
/*  511:     */     }
/*  512: 697 */     this.redundantOpCount += 1;
/*  513: 698 */     entry.currentEditor = null;
/*  514: 699 */     if ((entry.readable | success))
/*  515:     */     {
/*  516: 701 */       entry.readable = true;
/*  517: 702 */       this.journalWriter.write("C " + entry.diskKey + " " + 't' + entry.expiryTimestamp + entry.getLengths() + '\n');
/*  518: 703 */       if (success) {
/*  519: 705 */         entry.sequenceNumber = (this.nextSequenceNumber++);
/*  520:     */       }
/*  521:     */     }
/*  522:     */     else
/*  523:     */     {
/*  524: 709 */       this.lruEntries.remove(entry.diskKey);
/*  525: 710 */       this.journalWriter.write("D " + entry.diskKey + '\n');
/*  526:     */     }
/*  527: 712 */     this.journalWriter.flush();
/*  528: 714 */     if ((this.size > this.maxSize) || (journalRebuildRequired())) {
/*  529: 716 */       this.executorService.submit(this.cleanupCallable);
/*  530:     */     }
/*  531:     */   }
/*  532:     */   
/*  533:     */   private boolean journalRebuildRequired()
/*  534:     */   {
/*  535: 726 */     int redundantOpCompactThreshold = 2000;
/*  536: 727 */     return (this.redundantOpCount >= 2000) && (
/*  537: 728 */       this.redundantOpCount >= this.lruEntries.size());
/*  538:     */   }
/*  539:     */   
/*  540:     */   public boolean remove(String key)
/*  541:     */     throws IOException
/*  542:     */   {
/*  543: 733 */     String diskKey = this.fileNameGenerator.generate(key);
/*  544: 734 */     return removeByDiskKey(diskKey);
/*  545:     */   }
/*  546:     */   
/*  547:     */   private synchronized boolean removeByDiskKey(String diskKey)
/*  548:     */     throws IOException
/*  549:     */   {
/*  550: 745 */     checkNotClosed();
/*  551: 746 */     Entry entry = (Entry)this.lruEntries.get(diskKey);
/*  552: 747 */     if ((entry == null) || (entry.currentEditor != null)) {
/*  553: 749 */       return false;
/*  554:     */     }
/*  555: 752 */     for (int i = 0; i < this.valueCount; i++)
/*  556:     */     {
/*  557: 754 */       File file = entry.getCleanFile(i);
/*  558: 755 */       if ((file.exists()) && (!file.delete())) {
/*  559: 757 */         throw new IOException("failed to delete " + file);
/*  560:     */       }
/*  561: 759 */       this.size -= entry.lengths[i];
/*  562: 760 */       entry.lengths[i] = 0L;
/*  563:     */     }
/*  564: 763 */     this.redundantOpCount += 1;
/*  565: 764 */     this.journalWriter.append("D " + diskKey + '\n');
/*  566: 765 */     this.lruEntries.remove(diskKey);
/*  567: 767 */     if (journalRebuildRequired()) {
/*  568: 769 */       this.executorService.submit(this.cleanupCallable);
/*  569:     */     }
/*  570: 772 */     return true;
/*  571:     */   }
/*  572:     */   
/*  573:     */   public synchronized boolean isClosed()
/*  574:     */   {
/*  575: 780 */     return this.journalWriter == null;
/*  576:     */   }
/*  577:     */   
/*  578:     */   private void checkNotClosed()
/*  579:     */   {
/*  580: 785 */     if (this.journalWriter == null) {
/*  581: 787 */       throw new IllegalStateException("cache is closed");
/*  582:     */     }
/*  583:     */   }
/*  584:     */   
/*  585:     */   public synchronized void flush()
/*  586:     */     throws IOException
/*  587:     */   {
/*  588: 796 */     checkNotClosed();
/*  589: 797 */     trimToSize();
/*  590: 798 */     this.journalWriter.flush();
/*  591:     */   }
/*  592:     */   
/*  593:     */   public synchronized void close()
/*  594:     */     throws IOException
/*  595:     */   {
/*  596: 807 */     if (this.journalWriter == null) {
/*  597: 809 */       return;
/*  598:     */     }
/*  599: 811 */     for (Entry entry : new ArrayList(this.lruEntries.values())) {
/*  600: 813 */       if (entry.currentEditor != null) {
/*  601: 815 */         entry.currentEditor.abort();
/*  602:     */       }
/*  603:     */     }
/*  604: 818 */     trimToSize();
/*  605: 819 */     this.journalWriter.close();
/*  606: 820 */     this.journalWriter = null;
/*  607:     */   }
/*  608:     */   
/*  609:     */   private void trimToSize()
/*  610:     */     throws IOException
/*  611:     */   {
/*  612: 825 */     while (this.size > this.maxSize)
/*  613:     */     {
/*  614: 827 */       Map.Entry<String, Entry> toEvict = (Map.Entry)this.lruEntries.entrySet().iterator().next();
/*  615: 828 */       removeByDiskKey((String)toEvict.getKey());
/*  616:     */     }
/*  617:     */   }
/*  618:     */   
/*  619:     */   public void delete()
/*  620:     */     throws IOException
/*  621:     */   {
/*  622: 839 */     IOUtils.closeQuietly(this);
/*  623: 840 */     deleteContents(this.directory);
/*  624:     */   }
/*  625:     */   
/*  626:     */   private static String inputStreamToString(InputStream in)
/*  627:     */     throws IOException
/*  628:     */   {
/*  629: 845 */     return readFully(new InputStreamReader(in, "UTF-8"));
/*  630:     */   }
/*  631:     */   
/*  632:     */   public final class Snapshot
/*  633:     */     implements Closeable
/*  634:     */   {
/*  635:     */     private final String diskKey;
/*  636:     */     private final long sequenceNumber;
/*  637:     */     private final FileInputStream[] ins;
/*  638:     */     private final long[] lengths;
/*  639:     */     
/*  640:     */     private Snapshot(String diskKey, long sequenceNumber, FileInputStream[] ins, long[] lengths)
/*  641:     */     {
/*  642: 860 */       this.diskKey = diskKey;
/*  643: 861 */       this.sequenceNumber = sequenceNumber;
/*  644: 862 */       this.ins = ins;
/*  645: 863 */       this.lengths = lengths;
/*  646:     */     }
/*  647:     */     
/*  648:     */     public LruDiskCache.Editor edit()
/*  649:     */       throws IOException
/*  650:     */     {
/*  651: 873 */       return LruDiskCache.this.editByDiskKey(this.diskKey, this.sequenceNumber);
/*  652:     */     }
/*  653:     */     
/*  654:     */     public FileInputStream getInputStream(int index)
/*  655:     */     {
/*  656: 881 */       return this.ins[index];
/*  657:     */     }
/*  658:     */     
/*  659:     */     public String getString(int index)
/*  660:     */       throws IOException
/*  661:     */     {
/*  662: 889 */       return LruDiskCache.inputStreamToString(getInputStream(index));
/*  663:     */     }
/*  664:     */     
/*  665:     */     public long getLength(int index)
/*  666:     */     {
/*  667: 897 */       return this.lengths[index];
/*  668:     */     }
/*  669:     */     
/*  670:     */     public void close()
/*  671:     */     {
/*  672: 903 */       for (InputStream in : this.ins) {
/*  673: 905 */         IOUtils.closeQuietly(in);
/*  674:     */       }
/*  675:     */     }
/*  676:     */   }
/*  677:     */   
/*  678: 910 */   private static final OutputStream NULL_OUTPUT_STREAM = new OutputStream()
/*  679:     */   {
/*  680:     */     public void write(int b)
/*  681:     */       throws IOException
/*  682:     */     {}
/*  683:     */   };
/*  684:     */   
/*  685:     */   public final class Editor
/*  686:     */   {
/*  687:     */     private final LruDiskCache.Entry entry;
/*  688:     */     private final boolean[] written;
/*  689:     */     private boolean hasErrors;
/*  690:     */     private boolean committed;
/*  691:     */     
/*  692:     */     private Editor(LruDiskCache.Entry entry)
/*  693:     */     {
/*  694: 931 */       this.entry = entry;
/*  695: 932 */       this.written = (LruDiskCache.Entry.access$0(entry) ? null : new boolean[LruDiskCache.this.valueCount]);
/*  696:     */     }
/*  697:     */     
/*  698:     */     public void setEntryExpiryTimestamp(long timestamp)
/*  699:     */     {
/*  700: 937 */       LruDiskCache.Entry.access$1(this.entry, timestamp);
/*  701:     */     }
/*  702:     */     
/*  703:     */     public InputStream newInputStream(int index)
/*  704:     */       throws IOException
/*  705:     */     {
/*  706: 946 */       synchronized (LruDiskCache.this)
/*  707:     */       {
/*  708: 948 */         if (LruDiskCache.Entry.access$2(this.entry) != this) {
/*  709: 950 */           throw new IllegalStateException();
/*  710:     */         }
/*  711: 952 */         if (!LruDiskCache.Entry.access$0(this.entry)) {
/*  712: 954 */           return null;
/*  713:     */         }
/*  714:     */         try
/*  715:     */         {
/*  716: 958 */           return new FileInputStream(this.entry.getCleanFile(index));
/*  717:     */         }
/*  718:     */         catch (FileNotFoundException e)
/*  719:     */         {
/*  720: 961 */           return null;
/*  721:     */         }
/*  722:     */       }
/*  723:     */     }
/*  724:     */     
/*  725:     */     public String getString(int index)
/*  726:     */       throws IOException
/*  727:     */     {
/*  728: 972 */       InputStream in = newInputStream(index);
/*  729: 973 */       return in != null ? LruDiskCache.inputStreamToString(in) : null;
/*  730:     */     }
/*  731:     */     
/*  732:     */     public OutputStream newOutputStream(int index)
/*  733:     */       throws IOException
/*  734:     */     {
/*  735: 985 */       synchronized (LruDiskCache.this)
/*  736:     */       {
/*  737: 987 */         if (LruDiskCache.Entry.access$2(this.entry) != this) {
/*  738: 989 */           throw new IllegalStateException();
/*  739:     */         }
/*  740: 991 */         if (!LruDiskCache.Entry.access$0(this.entry)) {
/*  741: 993 */           this.written[index] = true;
/*  742:     */         }
/*  743: 995 */         File dirtyFile = this.entry.getDirtyFile(index);
/*  744:     */         try
/*  745:     */         {
/*  746: 999 */           outputStream = new FileOutputStream(dirtyFile);
/*  747:     */         }
/*  748:     */         catch (FileNotFoundException e)
/*  749:     */         {
/*  750:     */           FileOutputStream outputStream;
/*  751:1003 */           LruDiskCache.this.directory.mkdirs();
/*  752:     */           try
/*  753:     */           {
/*  754:1006 */             outputStream = new FileOutputStream(dirtyFile);
/*  755:     */           }
/*  756:     */           catch (FileNotFoundException e2)
/*  757:     */           {
/*  758:     */             FileOutputStream outputStream;
/*  759:1010 */             return LruDiskCache.NULL_OUTPUT_STREAM;
/*  760:     */           }
/*  761:     */         }
/*  762:     */         FileOutputStream outputStream;
/*  763:1013 */         return new FaultHidingOutputStream(outputStream, null);
/*  764:     */       }
/*  765:     */     }
/*  766:     */     
/*  767:     */     public void set(int index, String value)
/*  768:     */       throws IOException
/*  769:     */     {
/*  770:1022 */       Writer writer = null;
/*  771:     */       try
/*  772:     */       {
/*  773:1025 */         writer = new OutputStreamWriter(newOutputStream(index), "UTF-8");
/*  774:1026 */         writer.write(value);
/*  775:     */       }
/*  776:     */       finally
/*  777:     */       {
/*  778:1029 */         IOUtils.closeQuietly(writer);
/*  779:     */       }
/*  780:     */     }
/*  781:     */     
/*  782:     */     public void commit()
/*  783:     */       throws IOException
/*  784:     */     {
/*  785:1039 */       if (this.hasErrors)
/*  786:     */       {
/*  787:1041 */         LruDiskCache.this.completeEdit(this, false);
/*  788:1042 */         LruDiskCache.this.removeByDiskKey(LruDiskCache.Entry.access$3(this.entry));
/*  789:     */       }
/*  790:     */       else
/*  791:     */       {
/*  792:1045 */         LruDiskCache.this.completeEdit(this, true);
/*  793:     */       }
/*  794:1047 */       this.committed = true;
/*  795:     */     }
/*  796:     */     
/*  797:     */     public void abort()
/*  798:     */       throws IOException
/*  799:     */     {
/*  800:1056 */       LruDiskCache.this.completeEdit(this, false);
/*  801:     */     }
/*  802:     */     
/*  803:     */     public void abortUnlessCommitted()
/*  804:     */     {
/*  805:1061 */       if (!this.committed) {
/*  806:     */         try
/*  807:     */         {
/*  808:1065 */           abort();
/*  809:     */         }
/*  810:     */         catch (Throwable localThrowable) {}
/*  811:     */       }
/*  812:     */     }
/*  813:     */     
/*  814:     */     private class FaultHidingOutputStream
/*  815:     */       extends FilterOutputStream
/*  816:     */     {
/*  817:     */       private FaultHidingOutputStream(OutputStream out)
/*  818:     */       {
/*  819:1076 */         super();
/*  820:     */       }
/*  821:     */       
/*  822:     */       public void write(int oneByte)
/*  823:     */       {
/*  824:     */         try
/*  825:     */         {
/*  826:1084 */           this.out.write(oneByte);
/*  827:     */         }
/*  828:     */         catch (Throwable e)
/*  829:     */         {
/*  830:1087 */           LruDiskCache.Editor.this.hasErrors = true;
/*  831:     */         }
/*  832:     */       }
/*  833:     */       
/*  834:     */       public void write(byte[] buffer, int offset, int length)
/*  835:     */       {
/*  836:     */         try
/*  837:     */         {
/*  838:1096 */           this.out.write(buffer, offset, length);
/*  839:1097 */           this.out.flush();
/*  840:     */         }
/*  841:     */         catch (Throwable e)
/*  842:     */         {
/*  843:1100 */           LruDiskCache.Editor.this.hasErrors = true;
/*  844:     */         }
/*  845:     */       }
/*  846:     */       
/*  847:     */       public void close()
/*  848:     */       {
/*  849:     */         try
/*  850:     */         {
/*  851:1109 */           this.out.close();
/*  852:     */         }
/*  853:     */         catch (Throwable e)
/*  854:     */         {
/*  855:1112 */           LruDiskCache.Editor.this.hasErrors = true;
/*  856:     */         }
/*  857:     */       }
/*  858:     */       
/*  859:     */       public void flush()
/*  860:     */       {
/*  861:     */         try
/*  862:     */         {
/*  863:1121 */           this.out.flush();
/*  864:     */         }
/*  865:     */         catch (Throwable e)
/*  866:     */         {
/*  867:1124 */           LruDiskCache.Editor.this.hasErrors = true;
/*  868:     */         }
/*  869:     */       }
/*  870:     */     }
/*  871:     */   }
/*  872:     */   
/*  873:     */   private final class Entry
/*  874:     */   {
/*  875:     */     private final String diskKey;
/*  876:1134 */     private long expiryTimestamp = 9223372036854775807L;
/*  877:     */     private final long[] lengths;
/*  878:     */     private boolean readable;
/*  879:     */     private LruDiskCache.Editor currentEditor;
/*  880:     */     private long sequenceNumber;
/*  881:     */     
/*  882:     */     private Entry(String diskKey)
/*  883:     */     {
/*  884:1159 */       this.diskKey = diskKey;
/*  885:1160 */       this.lengths = new long[LruDiskCache.this.valueCount];
/*  886:     */     }
/*  887:     */     
/*  888:     */     public String getLengths()
/*  889:     */       throws IOException
/*  890:     */     {
/*  891:1165 */       StringBuilder result = new StringBuilder();
/*  892:1166 */       for (long size : this.lengths) {
/*  893:1168 */         result.append(" ").append(size);
/*  894:     */       }
/*  895:1170 */       return result.toString();
/*  896:     */     }
/*  897:     */     
/*  898:     */     private void setLengths(String[] strings, int startIndex)
/*  899:     */       throws IOException
/*  900:     */     {
/*  901:1178 */       if (strings.length - startIndex != LruDiskCache.this.valueCount) {
/*  902:1180 */         throw invalidLengths(strings);
/*  903:     */       }
/*  904:     */       try
/*  905:     */       {
/*  906:1185 */         for (int i = 0; i < LruDiskCache.this.valueCount; i++) {
/*  907:1187 */           this.lengths[i] = Long.parseLong(strings[(i + startIndex)]);
/*  908:     */         }
/*  909:     */       }
/*  910:     */       catch (NumberFormatException e)
/*  911:     */       {
/*  912:1191 */         throw invalidLengths(strings);
/*  913:     */       }
/*  914:     */     }
/*  915:     */     
/*  916:     */     private IOException invalidLengths(String[] strings)
/*  917:     */       throws IOException
/*  918:     */     {
/*  919:1197 */       throw new IOException("unexpected journal line: " + Arrays.toString(strings));
/*  920:     */     }
/*  921:     */     
/*  922:     */     public File getCleanFile(int i)
/*  923:     */     {
/*  924:1202 */       return new File(LruDiskCache.this.directory, this.diskKey + "." + i);
/*  925:     */     }
/*  926:     */     
/*  927:     */     public File getDirtyFile(int i)
/*  928:     */     {
/*  929:1207 */       return new File(LruDiskCache.this.directory, this.diskKey + "." + i + ".tmp");
/*  930:     */     }
/*  931:     */   }
/*  932:     */   
/*  933:     */   private static String readFully(Reader reader)
/*  934:     */     throws IOException
/*  935:     */   {
/*  936:1215 */     StringWriter writer = null;
/*  937:     */     try
/*  938:     */     {
/*  939:1218 */       writer = new StringWriter();
/*  940:1219 */       char[] buffer = new char[1024];
/*  941:     */       int count;
/*  942:1221 */       while ((count = reader.read(buffer)) != -1)
/*  943:     */       {
/*  944:     */         int count;
/*  945:1223 */         writer.write(buffer, 0, count);
/*  946:     */       }
/*  947:1225 */       return writer.toString();
/*  948:     */     }
/*  949:     */     finally
/*  950:     */     {
/*  951:1228 */       IOUtils.closeQuietly(reader);
/*  952:1229 */       IOUtils.closeQuietly(writer);
/*  953:     */     }
/*  954:     */   }
/*  955:     */   
/*  956:     */   private static void deleteContents(File dir)
/*  957:     */     throws IOException
/*  958:     */   {
/*  959:1239 */     File[] files = dir.listFiles();
/*  960:1240 */     if (files == null) {
/*  961:1242 */       throw new IOException("not a readable directory: " + dir);
/*  962:     */     }
/*  963:1244 */     for (File file : files)
/*  964:     */     {
/*  965:1246 */       if (file.isDirectory()) {
/*  966:1248 */         deleteContents(file);
/*  967:     */       }
/*  968:1250 */       if ((file.exists()) && (!file.delete())) {
/*  969:1252 */         throw new IOException("failed to delete file: " + file);
/*  970:     */       }
/*  971:     */     }
/*  972:     */   }
/*  973:     */   
/*  974:     */   private class StrictLineReader
/*  975:     */     implements Closeable
/*  976:     */   {
/*  977:     */     private static final byte CR = 13;
/*  978:     */     private static final byte LF = 10;
/*  979:     */     private final InputStream in;
/*  980:1265 */     private final Charset charset = Charset.forName("US-ASCII");
/*  981:     */     private byte[] buf;
/*  982:     */     private int pos;
/*  983:     */     private int end;
/*  984:     */     
/*  985:     */     public StrictLineReader(InputStream in)
/*  986:     */     {
/*  987:1292 */       this(in, 8192);
/*  988:     */     }
/*  989:     */     
/*  990:     */     public StrictLineReader(InputStream in, int capacity)
/*  991:     */     {
/*  992:1311 */       if (in == null) {
/*  993:1313 */         throw new NullPointerException();
/*  994:     */       }
/*  995:1315 */       if (capacity < 0) {
/*  996:1317 */         throw new IllegalArgumentException("capacity <= 0");
/*  997:     */       }
/*  998:1320 */       this.in = in;
/*  999:1321 */       this.buf = new byte[capacity];
/* 1000:     */     }
/* 1001:     */     
/* 1002:     */     public void close()
/* 1003:     */       throws IOException
/* 1004:     */     {
/* 1005:1335 */       synchronized (this.in)
/* 1006:     */       {
/* 1007:1337 */         if (this.buf != null)
/* 1008:     */         {
/* 1009:1339 */           this.buf = null;
/* 1010:1340 */           this.in.close();
/* 1011:     */         }
/* 1012:     */       }
/* 1013:     */     }
/* 1014:     */     
/* 1015:     */     public String readLine()
/* 1016:     */       throws IOException
/* 1017:     */     {
/* 1018:1357 */       synchronized (this.in)
/* 1019:     */       {
/* 1020:1359 */         if (this.buf == null) {
/* 1021:1361 */           throw new IOException("LineReader is closed");
/* 1022:     */         }
/* 1023:1369 */         if (this.pos >= this.end) {
/* 1024:1371 */           fillBuf();
/* 1025:     */         }
/* 1026:1375 */         for (int i = this.pos; i != this.end; i++) {
/* 1027:1377 */           if (this.buf[i] == 10)
/* 1028:     */           {
/* 1029:1379 */             int lineEnd = (i != this.pos) && (this.buf[(i - 1)] == 13) ? i - 1 : i;
/* 1030:1380 */             String res = new String(this.buf, this.pos, lineEnd - this.pos, this.charset.name());
/* 1031:1381 */             this.pos = (i + 1);
/* 1032:1382 */             return res;
/* 1033:     */           }
/* 1034:     */         }
/* 1035:1388 */         ByteArrayOutputStream out = new ByteArrayOutputStream(this.end - this.pos + 80)
/* 1036:     */         {
/* 1037:     */           public String toString()
/* 1038:     */           {
/* 1039:1393 */             int length = (this.count > 0) && (this.buf[(this.count - 1)] == 13) ? this.count - 1 : this.count;
/* 1040:     */             try
/* 1041:     */             {
/* 1042:1396 */               return new String(this.buf, 0, length, LruDiskCache.StrictLineReader.this.charset.name());
/* 1043:     */             }
/* 1044:     */             catch (UnsupportedEncodingException e)
/* 1045:     */             {
/* 1046:1399 */               throw new AssertionError(e);
/* 1047:     */             }
/* 1048:     */           }
/* 1049:1407 */         };
/* 1050:1408 */         out.write(this.buf, this.pos, this.end - this.pos);
/* 1051:     */         
/* 1052:     */ 
/* 1053:1411 */         this.end = -1;
/* 1054:1412 */         fillBuf();
/* 1055:1415 */         for (int i = this.pos; i != this.end; i++) {
/* 1056:1417 */           if (this.buf[i] == 10)
/* 1057:     */           {
/* 1058:1419 */             if (i != this.pos) {
/* 1059:1421 */               out.write(this.buf, this.pos, i - this.pos);
/* 1060:     */             }
/* 1061:1423 */             out.flush();
/* 1062:1424 */             this.pos = (i + 1);
/* 1063:1425 */             return out.toString();
/* 1064:     */           }
/* 1065:     */         }
/* 1066:     */       }
/* 1067:     */     }
/* 1068:     */     
/* 1069:     */     private void fillBuf()
/* 1070:     */       throws IOException
/* 1071:     */     {
/* 1072:1438 */       int result = this.in.read(this.buf, 0, this.buf.length);
/* 1073:1439 */       if (result == -1) {
/* 1074:1441 */         throw new EOFException();
/* 1075:     */       }
/* 1076:1443 */       this.pos = 0;
/* 1077:1444 */       this.end = result;
/* 1078:     */     }
/* 1079:     */   }
/* 1080:     */   
/* 1081:1448 */   private FileNameGenerator fileNameGenerator = new MD5FileNameGenerator();
/* 1082:     */   
/* 1083:     */   public FileNameGenerator getFileNameGenerator()
/* 1084:     */   {
/* 1085:1452 */     return this.fileNameGenerator;
/* 1086:     */   }
/* 1087:     */   
/* 1088:     */   public void setFileNameGenerator(FileNameGenerator fileNameGenerator)
/* 1089:     */   {
/* 1090:1457 */     if (fileNameGenerator != null) {
/* 1091:1459 */       this.fileNameGenerator = fileNameGenerator;
/* 1092:     */     }
/* 1093:     */   }
/* 1094:     */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.cache.LruDiskCache
 * JD-Core Version:    0.7.0.1
 */