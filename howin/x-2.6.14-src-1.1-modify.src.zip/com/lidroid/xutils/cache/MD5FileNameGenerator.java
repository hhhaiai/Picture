/*  1:   */ package com.lidroid.xutils.cache;
/*  2:   */ 
/*  3:   */ import java.security.MessageDigest;
/*  4:   */ import java.security.NoSuchAlgorithmException;
/*  5:   */ 
/*  6:   */ public class MD5FileNameGenerator
/*  7:   */   implements FileNameGenerator
/*  8:   */ {
/*  9:   */   public String generate(String key)
/* 10:   */   {
/* 11:   */     String cacheKey;
/* 12:   */     try
/* 13:   */     {
/* 14:20 */       MessageDigest mDigest = MessageDigest.getInstance("MD5");
/* 15:21 */       mDigest.update(key.getBytes());
/* 16:22 */       cacheKey = bytesToHexString(mDigest.digest());
/* 17:   */     }
/* 18:   */     catch (NoSuchAlgorithmException e)
/* 19:   */     {
/* 20:   */       String cacheKey;
/* 21:25 */       cacheKey = String.valueOf(key.hashCode());
/* 22:   */     }
/* 23:27 */     return cacheKey;
/* 24:   */   }
/* 25:   */   
/* 26:   */   private String bytesToHexString(byte[] bytes)
/* 27:   */   {
/* 28:32 */     StringBuilder sb = new StringBuilder();
/* 29:33 */     for (int i = 0; i < bytes.length; i++)
/* 30:   */     {
/* 31:35 */       String hex = Integer.toHexString(0xFF & bytes[i]);
/* 32:36 */       if (hex.length() == 1) {
/* 33:38 */         sb.append('0');
/* 34:   */       }
/* 35:40 */       sb.append(hex);
/* 36:   */     }
/* 37:42 */     return sb.toString();
/* 38:   */   }
/* 39:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.cache.MD5FileNameGenerator
 * JD-Core Version:    0.7.0.1
 */