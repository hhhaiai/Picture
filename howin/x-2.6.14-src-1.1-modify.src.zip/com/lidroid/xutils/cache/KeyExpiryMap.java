/*  1:   */ package com.lidroid.xutils.cache;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.ConcurrentHashMap;
/*  4:   */ 
/*  5:   */ public class KeyExpiryMap<K, V>
/*  6:   */   extends ConcurrentHashMap<K, Long>
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 1L;
/*  9:   */   private static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/* 10:   */   
/* 11:   */   public KeyExpiryMap(int initialCapacity, float loadFactor, int concurrencyLevel)
/* 12:   */   {
/* 13:35 */     super(initialCapacity, loadFactor, concurrencyLevel);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public KeyExpiryMap(int initialCapacity, float loadFactor)
/* 17:   */   {
/* 18:40 */     super(initialCapacity, loadFactor, 16);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public KeyExpiryMap(int initialCapacity)
/* 22:   */   {
/* 23:45 */     super(initialCapacity);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public KeyExpiryMap() {}
/* 27:   */   
/* 28:   */   public synchronized Long get(Object key)
/* 29:   */   {
/* 30:56 */     if (containsKey(key)) {
/* 31:58 */       return (Long)super.get(key);
/* 32:   */     }
/* 33:61 */     return null;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public synchronized Long put(K key, Long expiryTimestamp)
/* 37:   */   {
/* 38:68 */     if (containsKey(key)) {
/* 39:70 */       remove(key);
/* 40:   */     }
/* 41:72 */     return (Long)super.put(key, expiryTimestamp);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public synchronized boolean containsKey(Object key)
/* 45:   */   {
/* 46:78 */     boolean result = false;
/* 47:79 */     Long expiryTimestamp = (Long)super.get(key);
/* 48:80 */     if ((expiryTimestamp != null) && (System.currentTimeMillis() < expiryTimestamp.longValue())) {
/* 49:82 */       result = true;
/* 50:   */     } else {
/* 51:85 */       remove(key);
/* 52:   */     }
/* 53:87 */     return result;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public synchronized Long remove(Object key)
/* 57:   */   {
/* 58:93 */     return (Long)super.remove(key);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public synchronized void clear()
/* 62:   */   {
/* 63:99 */     super.clear();
/* 64:   */   }
/* 65:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.cache.KeyExpiryMap
 * JD-Core Version:    0.7.0.1
 */