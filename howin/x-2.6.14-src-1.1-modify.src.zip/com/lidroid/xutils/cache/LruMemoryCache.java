/*   1:    */ package com.lidroid.xutils.cache;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import java.util.Set;
/*   8:    */ 
/*   9:    */ public class LruMemoryCache<K, V>
/*  10:    */ {
/*  11:    */   private final LinkedHashMap<K, V> map;
/*  12:    */   private int size;
/*  13:    */   private int maxSize;
/*  14:    */   private int putCount;
/*  15:    */   private int createCount;
/*  16:    */   private int evictionCount;
/*  17:    */   private int hitCount;
/*  18:    */   private int missCount;
/*  19:    */   private KeyExpiryMap<K, Long> keyExpiryMap;
/*  20:    */   
/*  21:    */   public LruMemoryCache(int maxSize)
/*  22:    */   {
/*  23: 51 */     if (maxSize <= 0) {
/*  24: 53 */       throw new IllegalArgumentException("maxSize <= 0");
/*  25:    */     }
/*  26: 55 */     this.maxSize = maxSize;
/*  27: 56 */     this.map = new LinkedHashMap(0, 0.75F, true);
/*  28: 57 */     this.keyExpiryMap = new KeyExpiryMap(0, 0.75F);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setMaxSize(int maxSize)
/*  32:    */   {
/*  33: 62 */     this.maxSize = maxSize;
/*  34: 63 */     trimToSize(maxSize);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public final V get(K key)
/*  38:    */   {
/*  39: 74 */     if (key == null) {
/*  40: 76 */       throw new NullPointerException("key == null");
/*  41:    */     }
/*  42: 80 */     synchronized (this)
/*  43:    */     {
/*  44: 83 */       if (!this.keyExpiryMap.containsKey(key))
/*  45:    */       {
/*  46: 85 */         remove(key);
/*  47: 86 */         return null;
/*  48:    */       }
/*  49: 88 */       V mapValue = this.map.get(key);
/*  50: 89 */       if (mapValue != null)
/*  51:    */       {
/*  52: 91 */         this.hitCount += 1;
/*  53: 92 */         return mapValue;
/*  54:    */       }
/*  55: 94 */       this.missCount += 1;
/*  56:    */     }
/*  57:    */     V mapValue;
/*  58:104 */     V createdValue = create(key);
/*  59:105 */     if (createdValue == null) {
/*  60:107 */       return null;
/*  61:    */     }
/*  62:110 */     synchronized (this)
/*  63:    */     {
/*  64:112 */       this.createCount += 1;
/*  65:113 */       mapValue = this.map.put(key, createdValue);
/*  66:115 */       if (mapValue != null) {
/*  67:118 */         this.map.put(key, mapValue);
/*  68:    */       } else {
/*  69:121 */         this.size += safeSizeOf(key, createdValue);
/*  70:    */       }
/*  71:    */     }
/*  72:125 */     if (mapValue != null)
/*  73:    */     {
/*  74:127 */       entryRemoved(false, key, createdValue, mapValue);
/*  75:128 */       return mapValue;
/*  76:    */     }
/*  77:131 */     trimToSize(this.maxSize);
/*  78:132 */     return createdValue;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public final V put(K key, V value)
/*  82:    */   {
/*  83:144 */     return put(key, value, 9223372036854775807L);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public final V put(K key, V value, long expiryTimestamp)
/*  87:    */   {
/*  88:155 */     if ((key == null) || (value == null)) {
/*  89:157 */       throw new NullPointerException("key == null || value == null");
/*  90:    */     }
/*  91:161 */     synchronized (this)
/*  92:    */     {
/*  93:163 */       this.putCount += 1;
/*  94:164 */       this.size += safeSizeOf(key, value);
/*  95:165 */       V previous = this.map.put(key, value);
/*  96:166 */       this.keyExpiryMap.put(key, Long.valueOf(expiryTimestamp));
/*  97:167 */       if (previous != null) {
/*  98:169 */         this.size -= safeSizeOf(key, previous);
/*  99:    */       }
/* 100:    */     }
/* 101:    */     V previous;
/* 102:173 */     if (previous != null) {
/* 103:175 */       entryRemoved(false, key, previous, value);
/* 104:    */     }
/* 105:178 */     trimToSize(this.maxSize);
/* 106:179 */     return previous;
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void trimToSize(int maxSize)
/* 110:    */   {
/* 111:    */     for (;;)
/* 112:    */     {
/* 113:193 */       synchronized (this)
/* 114:    */       {
/* 115:195 */         if ((this.size > maxSize) && (this.map.isEmpty())) {
/* 116:    */           break;
/* 117:    */         }
/* 118:200 */         Map.Entry<K, V> toEvict = (Map.Entry)this.map.entrySet().iterator().next();
/* 119:201 */         K key = toEvict.getKey();
/* 120:202 */         V value = toEvict.getValue();
/* 121:203 */         this.map.remove(key);
/* 122:204 */         this.keyExpiryMap.remove(key);
/* 123:205 */         this.size -= safeSizeOf(key, value);
/* 124:206 */         this.evictionCount += 1;
/* 125:    */       }
/* 126:    */       V value;
/* 127:    */       K key;
/* 128:209 */       entryRemoved(true, key, value, null);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public final V remove(K key)
/* 133:    */   {
/* 134:220 */     if (key == null) {
/* 135:222 */       throw new NullPointerException("key == null");
/* 136:    */     }
/* 137:226 */     synchronized (this)
/* 138:    */     {
/* 139:228 */       V previous = this.map.remove(key);
/* 140:229 */       this.keyExpiryMap.remove(key);
/* 141:230 */       if (previous != null) {
/* 142:232 */         this.size -= safeSizeOf(key, previous);
/* 143:    */       }
/* 144:    */     }
/* 145:    */     V previous;
/* 146:236 */     if (previous != null) {
/* 147:238 */       entryRemoved(false, key, previous, null);
/* 148:    */     }
/* 149:241 */     return previous;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public final boolean containsKey(K key)
/* 153:    */   {
/* 154:246 */     return this.map.containsKey(key);
/* 155:    */   }
/* 156:    */   
/* 157:    */   protected void entryRemoved(boolean evicted, K key, V oldValue, V newValue) {}
/* 158:    */   
/* 159:    */   protected V create(K key)
/* 160:    */   {
/* 161:289 */     return null;
/* 162:    */   }
/* 163:    */   
/* 164:    */   private int safeSizeOf(K key, V value)
/* 165:    */   {
/* 166:294 */     int result = sizeOf(key, value);
/* 167:295 */     if (result <= 0)
/* 168:    */     {
/* 169:297 */       this.size = 0;
/* 170:298 */       for (Map.Entry<K, V> entry : this.map.entrySet()) {
/* 171:300 */         this.size += sizeOf(entry.getKey(), entry.getValue());
/* 172:    */       }
/* 173:    */     }
/* 174:303 */     return result;
/* 175:    */   }
/* 176:    */   
/* 177:    */   protected int sizeOf(K key, V value)
/* 178:    */   {
/* 179:316 */     return 1;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public final void evictAll()
/* 183:    */   {
/* 184:324 */     trimToSize(-1);
/* 185:325 */     this.keyExpiryMap.clear();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public final synchronized int size()
/* 189:    */   {
/* 190:335 */     return this.size;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public final synchronized int maxSize()
/* 194:    */   {
/* 195:345 */     return this.maxSize;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public final synchronized int hitCount()
/* 199:    */   {
/* 200:353 */     return this.hitCount;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public final synchronized int missCount()
/* 204:    */   {
/* 205:362 */     return this.missCount;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public final synchronized int createCount()
/* 209:    */   {
/* 210:370 */     return this.createCount;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public final synchronized int putCount()
/* 214:    */   {
/* 215:378 */     return this.putCount;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public final synchronized int evictionCount()
/* 219:    */   {
/* 220:386 */     return this.evictionCount;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public final synchronized Map<K, V> snapshot()
/* 224:    */   {
/* 225:395 */     return new LinkedHashMap(this.map);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public final synchronized String toString()
/* 229:    */   {
/* 230:400 */     int accesses = this.hitCount + this.missCount;
/* 231:401 */     int hitPercent = accesses != 0 ? 100 * this.hitCount / accesses : 0;
/* 232:402 */     return String.format("LruMemoryCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[] { Integer.valueOf(this.maxSize), Integer.valueOf(this.hitCount), Integer.valueOf(this.missCount), Integer.valueOf(hitPercent) });
/* 233:    */   }
/* 234:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.cache.LruMemoryCache
 * JD-Core Version:    0.7.0.1
 */