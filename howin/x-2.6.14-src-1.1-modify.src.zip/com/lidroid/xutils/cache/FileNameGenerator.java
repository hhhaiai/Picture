package com.lidroid.xutils.cache;

public abstract interface FileNameGenerator
{
  public abstract String generate(String paramString);
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.cache.FileNameGenerator
 * JD-Core Version:    0.7.0.1
 */