/*   1:    */ package com.lidroid.xutils;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.preference.Preference;
/*   5:    */ import android.preference.PreferenceActivity;
/*   6:    */ import android.preference.PreferenceGroup;
/*   7:    */ import android.view.View;
/*   8:    */ import com.lidroid.xutils.util.LogUtils;
/*   9:    */ import com.lidroid.xutils.view.EventListenerManager;
/*  10:    */ import com.lidroid.xutils.view.ResLoader;
/*  11:    */ import com.lidroid.xutils.view.ViewFinder;
/*  12:    */ import com.lidroid.xutils.view.ViewInjectInfo;
/*  13:    */ import com.lidroid.xutils.view.annotation.ContentView;
/*  14:    */ import com.lidroid.xutils.view.annotation.PreferenceInject;
/*  15:    */ import com.lidroid.xutils.view.annotation.ResInject;
/*  16:    */ import com.lidroid.xutils.view.annotation.ViewInject;
/*  17:    */ import com.lidroid.xutils.view.annotation.event.EventBase;
/*  18:    */ import java.lang.annotation.Annotation;
/*  19:    */ import java.lang.reflect.Array;
/*  20:    */ import java.lang.reflect.Field;
/*  21:    */ import java.lang.reflect.Method;
/*  22:    */ 
/*  23:    */ public class ViewUtils
/*  24:    */ {
/*  25:    */   public static void inject(View view)
/*  26:    */   {
/*  27: 48 */     injectObject(view, new ViewFinder(view));
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void inject(Activity activity)
/*  31:    */   {
/*  32: 53 */     injectObject(activity, new ViewFinder(activity));
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void inject(PreferenceActivity preferenceActivity)
/*  36:    */   {
/*  37: 58 */     injectObject(preferenceActivity, new ViewFinder(preferenceActivity));
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void inject(Object handler, View view)
/*  41:    */   {
/*  42: 63 */     injectObject(handler, new ViewFinder(view));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static void inject(Object handler, Activity activity)
/*  46:    */   {
/*  47: 68 */     injectObject(handler, new ViewFinder(activity));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void inject(Object handler, PreferenceGroup preferenceGroup)
/*  51:    */   {
/*  52: 73 */     injectObject(handler, new ViewFinder(preferenceGroup));
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void inject(Object handler, PreferenceActivity preferenceActivity)
/*  56:    */   {
/*  57: 78 */     injectObject(handler, new ViewFinder(preferenceActivity));
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static void injectObject(Object handler, ViewFinder finder)
/*  61:    */   {
/*  62: 85 */     Class<?> handlerType = handler.getClass();
/*  63:    */     
/*  64:    */ 
/*  65: 88 */     ContentView contentView = (ContentView)handlerType.getAnnotation(ContentView.class);
/*  66: 89 */     if (contentView != null) {
/*  67:    */       try
/*  68:    */       {
/*  69: 93 */         Method setContentViewMethod = handlerType.getMethod("setContentView", new Class[] { Integer.TYPE });
/*  70: 94 */         setContentViewMethod.invoke(handler, new Object[] { Integer.valueOf(contentView.value()) });
/*  71:    */       }
/*  72:    */       catch (Throwable e)
/*  73:    */       {
/*  74: 97 */         LogUtils.e(e.getMessage(), e);
/*  75:    */       }
/*  76:    */     }
/*  77:102 */     Field[] fields = handlerType.getDeclaredFields();
/*  78:    */     ViewInject viewInject;
/*  79:103 */     if ((fields != null) && (fields.length > 0)) {
/*  80:105 */       for (Field field : fields)
/*  81:    */       {
/*  82:107 */         viewInject = (ViewInject)field.getAnnotation(ViewInject.class);
/*  83:108 */         if (viewInject != null)
/*  84:    */         {
/*  85:    */           try
/*  86:    */           {
/*  87:112 */             View view = finder.findViewById(viewInject.value(), viewInject.parentId());
/*  88:113 */             if (view == null) {
/*  89:    */               continue;
/*  90:    */             }
/*  91:115 */             field.setAccessible(true);
/*  92:116 */             field.set(handler, view);
/*  93:    */           }
/*  94:    */           catch (Throwable e)
/*  95:    */           {
/*  96:120 */             LogUtils.e(e.getMessage(), e);
/*  97:    */           }
/*  98:    */         }
/*  99:    */         else
/* 100:    */         {
/* 101:124 */           ResInject resInject = (ResInject)field.getAnnotation(ResInject.class);
/* 102:125 */           if (resInject != null)
/* 103:    */           {
/* 104:    */             try
/* 105:    */             {
/* 106:129 */               Object res = ResLoader.loadRes(resInject.type(), finder.getContext(), resInject.id());
/* 107:130 */               if (res == null) {
/* 108:    */                 continue;
/* 109:    */               }
/* 110:132 */               field.setAccessible(true);
/* 111:133 */               field.set(handler, res);
/* 112:    */             }
/* 113:    */             catch (Throwable e)
/* 114:    */             {
/* 115:137 */               LogUtils.e(e.getMessage(), e);
/* 116:    */             }
/* 117:    */           }
/* 118:    */           else
/* 119:    */           {
/* 120:141 */             PreferenceInject preferenceInject = (PreferenceInject)field.getAnnotation(PreferenceInject.class);
/* 121:142 */             if (preferenceInject != null) {
/* 122:    */               try
/* 123:    */               {
/* 124:146 */                 Preference preference = finder.findPreference(preferenceInject.value());
/* 125:147 */                 if (preference != null)
/* 126:    */                 {
/* 127:149 */                   field.setAccessible(true);
/* 128:150 */                   field.set(handler, preference);
/* 129:    */                 }
/* 130:    */               }
/* 131:    */               catch (Throwable e)
/* 132:    */               {
/* 133:154 */                 LogUtils.e(e.getMessage(), e);
/* 134:    */               }
/* 135:    */             }
/* 136:    */           }
/* 137:    */         }
/* 138:    */       }
/* 139:    */     }
/* 140:163 */     Method[] methods = handlerType.getDeclaredMethods();
/* 141:164 */     if ((methods != null) && (methods.length > 0)) {
/* 142:166 */       for (Method method : methods)
/* 143:    */       {
/* 144:168 */         Annotation[] annotations = method.getDeclaredAnnotations();
/* 145:169 */         if ((annotations != null) && (annotations.length > 0))
/* 146:    */         {
/* 147:    */           Annotation[] arrayOfAnnotation1;
/* 148:171 */           Throwable localThrowable2 = (arrayOfAnnotation1 = annotations).length;
/* 149:171 */           for (e = 0; e < localThrowable2; e++)
/* 150:    */           {
/* 151:171 */             Annotation annotation = arrayOfAnnotation1[e];
/* 152:    */             
/* 153:173 */             Class<?> annType = annotation.annotationType();
/* 154:174 */             if (annType.getAnnotation(EventBase.class) != null)
/* 155:    */             {
/* 156:176 */               method.setAccessible(true);
/* 157:    */               try
/* 158:    */               {
/* 159:181 */                 Method valueMethod = annType.getDeclaredMethod("value", new Class[0]);
/* 160:182 */                 Method parentIdMethod = null;
/* 161:    */                 try
/* 162:    */                 {
/* 163:185 */                   parentIdMethod = annType.getDeclaredMethod("parentId", new Class[0]);
/* 164:    */                 }
/* 165:    */                 catch (Throwable localThrowable1) {}
/* 166:189 */                 Object values = valueMethod.invoke(annotation, new Object[0]);
/* 167:190 */                 Object parentIds = parentIdMethod == null ? null : parentIdMethod.invoke(annotation, new Object[0]);
/* 168:191 */                 int parentIdsLen = parentIds == null ? 0 : Array.getLength(parentIds);
/* 169:192 */                 int len = Array.getLength(values);
/* 170:193 */                 for (int i = 0; i < len; i++)
/* 171:    */                 {
/* 172:195 */                   ViewInjectInfo info = new ViewInjectInfo();
/* 173:196 */                   info.value = Array.get(values, i);
/* 174:197 */                   info.parentId = (parentIdsLen > i ? ((Integer)Array.get(parentIds, i)).intValue() : 0);
/* 175:198 */                   EventListenerManager.addEventMethod(finder, info, annotation, handler, method);
/* 176:    */                 }
/* 177:    */               }
/* 178:    */               catch (Throwable e)
/* 179:    */               {
/* 180:202 */                 LogUtils.e(e.getMessage(), e);
/* 181:    */               }
/* 182:    */             }
/* 183:    */           }
/* 184:    */         }
/* 185:    */       }
/* 186:    */     }
/* 187:    */   }
/* 188:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.ViewUtils
 * JD-Core Version:    0.7.0.1
 */