/*   1:    */ package com.lidroid.xutils.bitmap.download;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.res.AssetManager;
/*   5:    */ import com.lidroid.xutils.BitmapUtils.BitmapLoadTask;
/*   6:    */ import com.lidroid.xutils.util.IOUtils;
/*   7:    */ import com.lidroid.xutils.util.LogUtils;
/*   8:    */ import com.lidroid.xutils.util.OtherUtils;
/*   9:    */ import java.io.BufferedInputStream;
/*  10:    */ import java.io.BufferedOutputStream;
/*  11:    */ import java.io.FileInputStream;
/*  12:    */ import java.io.InputStream;
/*  13:    */ import java.io.OutputStream;
/*  14:    */ import java.net.URL;
/*  15:    */ import java.net.URLConnection;
/*  16:    */ 
/*  17:    */ public class DefaultDownloader
/*  18:    */   extends Downloader
/*  19:    */ {
/*  20:    */   public long downloadToStream(String uri, OutputStream outputStream, BitmapUtils.BitmapLoadTask<?> task)
/*  21:    */   {
/*  22: 43 */     if ((task == null) || (task.isCancelled()) || (task.getTargetContainer() == null)) {
/*  23: 44 */       return -1L;
/*  24:    */     }
/*  25: 46 */     URLConnection urlConnection = null;
/*  26: 47 */     BufferedInputStream bis = null;
/*  27:    */     
/*  28: 49 */     OtherUtils.trustAllHttpsURLConnection();
/*  29:    */     
/*  30: 51 */     long result = -1L;
/*  31: 52 */     long fileLen = 0L;
/*  32: 53 */     long currCount = 0L;
/*  33:    */     try
/*  34:    */     {
/*  35: 56 */       if (uri.startsWith("/"))
/*  36:    */       {
/*  37: 58 */         FileInputStream fileInputStream = new FileInputStream(uri);
/*  38: 59 */         fileLen = fileInputStream.available();
/*  39: 60 */         bis = new BufferedInputStream(fileInputStream);
/*  40: 61 */         result = System.currentTimeMillis() + getDefaultExpiry();
/*  41:    */       }
/*  42: 62 */       else if (uri.startsWith("assets/"))
/*  43:    */       {
/*  44: 64 */         InputStream inputStream = getContext().getAssets().open(uri.substring(7, uri.length()));
/*  45: 65 */         fileLen = inputStream.available();
/*  46: 66 */         bis = new BufferedInputStream(inputStream);
/*  47: 67 */         result = 9223372036854775807L;
/*  48:    */       }
/*  49:    */       else
/*  50:    */       {
/*  51: 70 */         URL url = new URL(uri);
/*  52: 71 */         urlConnection = url.openConnection();
/*  53: 72 */         urlConnection.setConnectTimeout(getDefaultConnectTimeout());
/*  54: 73 */         urlConnection.setReadTimeout(getDefaultReadTimeout());
/*  55: 74 */         bis = new BufferedInputStream(urlConnection.getInputStream());
/*  56: 75 */         result = urlConnection.getExpiration();
/*  57: 76 */         result = result < System.currentTimeMillis() ? System.currentTimeMillis() + getDefaultExpiry() : result;
/*  58: 77 */         fileLen = urlConnection.getContentLength();
/*  59:    */       }
/*  60: 80 */       if ((task.isCancelled()) || (task.getTargetContainer() == null)) {
/*  61: 81 */         return -1L;
/*  62:    */       }
/*  63: 83 */       byte[] buffer = new byte[4096];
/*  64: 84 */       int len = 0;
/*  65: 85 */       BufferedOutputStream out = new BufferedOutputStream(outputStream);
/*  66: 86 */       while ((len = bis.read(buffer)) != -1)
/*  67:    */       {
/*  68: 88 */         out.write(buffer, 0, len);
/*  69: 89 */         currCount += len;
/*  70: 90 */         if ((task.isCancelled()) || (task.getTargetContainer() == null)) {
/*  71: 91 */           return -1L;
/*  72:    */         }
/*  73: 92 */         task.updateProgress(fileLen, currCount);
/*  74:    */       }
/*  75: 94 */       out.flush();
/*  76:    */     }
/*  77:    */     catch (Throwable e)
/*  78:    */     {
/*  79: 97 */       result = -1L;
/*  80: 98 */       LogUtils.e(e.getMessage(), e);
/*  81:    */     }
/*  82:    */     finally
/*  83:    */     {
/*  84:101 */       IOUtils.closeQuietly(bis);
/*  85:    */     }
/*  86:103 */     return result;
/*  87:    */   }
/*  88:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.download.DefaultDownloader
 * JD-Core Version:    0.7.0.1
 */