/*  1:   */ package com.lidroid.xutils.bitmap.download;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import com.lidroid.xutils.BitmapUtils.BitmapLoadTask;
/*  5:   */ import java.io.OutputStream;
/*  6:   */ 
/*  7:   */ public abstract class Downloader
/*  8:   */ {
/*  9:   */   private Context context;
/* 10:   */   private long defaultExpiry;
/* 11:   */   private int defaultConnectTimeout;
/* 12:   */   private int defaultReadTimeout;
/* 13:   */   
/* 14:   */   public abstract long downloadToStream(String paramString, OutputStream paramOutputStream, BitmapUtils.BitmapLoadTask<?> paramBitmapLoadTask);
/* 15:   */   
/* 16:   */   public Context getContext()
/* 17:   */   {
/* 18:42 */     return this.context;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setContext(Context context)
/* 22:   */   {
/* 23:47 */     this.context = context;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setDefaultExpiry(long expiry)
/* 27:   */   {
/* 28:52 */     this.defaultExpiry = expiry;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public long getDefaultExpiry()
/* 32:   */   {
/* 33:57 */     return this.defaultExpiry;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public int getDefaultConnectTimeout()
/* 37:   */   {
/* 38:62 */     return this.defaultConnectTimeout;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setDefaultConnectTimeout(int defaultConnectTimeout)
/* 42:   */   {
/* 43:67 */     this.defaultConnectTimeout = defaultConnectTimeout;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int getDefaultReadTimeout()
/* 47:   */   {
/* 48:72 */     return this.defaultReadTimeout;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setDefaultReadTimeout(int defaultReadTimeout)
/* 52:   */   {
/* 53:77 */     this.defaultReadTimeout = defaultReadTimeout;
/* 54:   */   }
/* 55:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.download.Downloader
 * JD-Core Version:    0.7.0.1
 */