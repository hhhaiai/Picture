package com.lidroid.xutils.bitmap.callback;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.View;

public abstract interface BitmapSetter<T extends View>
{
  public abstract void setBitmap(T paramT, Bitmap paramBitmap);
  
  public abstract void setDrawable(T paramT, Drawable paramDrawable);
  
  public abstract Drawable getDrawable(T paramT);
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.callback.BitmapSetter
 * JD-Core Version:    0.7.0.1
 */