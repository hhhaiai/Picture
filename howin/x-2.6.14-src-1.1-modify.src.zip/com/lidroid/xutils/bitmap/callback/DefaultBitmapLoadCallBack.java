/*  1:   */ package com.lidroid.xutils.bitmap.callback;
/*  2:   */ 
/*  3:   */ import android.graphics.Bitmap;
/*  4:   */ import android.graphics.drawable.Drawable;
/*  5:   */ import android.view.View;
/*  6:   */ import android.view.animation.Animation;
/*  7:   */ import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
/*  8:   */ import java.lang.reflect.Method;
/*  9:   */ 
/* 10:   */ public class DefaultBitmapLoadCallBack<T extends View>
/* 11:   */   extends BitmapLoadCallBack<T>
/* 12:   */ {
/* 13:   */   public void onLoadCompleted(T container, String uri, Bitmap bitmap, BitmapDisplayConfig config, BitmapLoadFrom from)
/* 14:   */   {
/* 15:32 */     setBitmap(container, bitmap);
/* 16:33 */     Animation animation = config.getAnimation();
/* 17:34 */     if (animation != null) {
/* 18:36 */       animationDisplay(container, animation);
/* 19:   */     }
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void onLoadFailed(T container, String uri, Drawable drawable)
/* 23:   */   {
/* 24:43 */     setDrawable(container, drawable);
/* 25:   */   }
/* 26:   */   
/* 27:   */   private void animationDisplay(T container, Animation animation)
/* 28:   */   {
/* 29:   */     try
/* 30:   */     {
/* 31:50 */       Method cloneMethod = Animation.class.getDeclaredMethod("clone", new Class[0]);
/* 32:51 */       cloneMethod.setAccessible(true);
/* 33:52 */       container.startAnimation((Animation)cloneMethod.invoke(animation, new Object[0]));
/* 34:   */     }
/* 35:   */     catch (Throwable e)
/* 36:   */     {
/* 37:55 */       container.startAnimation(animation);
/* 38:   */     }
/* 39:   */   }
/* 40:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.callback.DefaultBitmapLoadCallBack
 * JD-Core Version:    0.7.0.1
 */