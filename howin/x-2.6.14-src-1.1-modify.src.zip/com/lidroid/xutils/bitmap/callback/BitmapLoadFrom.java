package com.lidroid.xutils.bitmap.callback;

public enum BitmapLoadFrom
{
  MEMORY_CACHE,  DISK_CACHE,  URI;
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.callback.BitmapLoadFrom
 * JD-Core Version:    0.7.0.1
 */