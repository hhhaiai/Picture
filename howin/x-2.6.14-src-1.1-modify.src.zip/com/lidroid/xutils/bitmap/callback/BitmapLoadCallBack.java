/*   1:    */ package com.lidroid.xutils.bitmap.callback;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.graphics.drawable.BitmapDrawable;
/*   5:    */ import android.graphics.drawable.Drawable;
/*   6:    */ import android.view.View;
/*   7:    */ import android.widget.ImageView;
/*   8:    */ import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
/*   9:    */ 
/*  10:    */ public abstract class BitmapLoadCallBack<T extends View>
/*  11:    */ {
/*  12:    */   private BitmapSetter<T> bitmapSetter;
/*  13:    */   
/*  14:    */   public void onPreLoad(T container, String uri, BitmapDisplayConfig config) {}
/*  15:    */   
/*  16:    */   public void onLoadStarted(T container, String uri, BitmapDisplayConfig config) {}
/*  17:    */   
/*  18:    */   public void onLoading(T container, String uri, BitmapDisplayConfig config, long total, long current) {}
/*  19:    */   
/*  20:    */   public abstract void onLoadCompleted(T paramT, String paramString, Bitmap paramBitmap, BitmapDisplayConfig paramBitmapDisplayConfig, BitmapLoadFrom paramBitmapLoadFrom);
/*  21:    */   
/*  22:    */   public abstract void onLoadFailed(T paramT, String paramString, Drawable paramDrawable);
/*  23:    */   
/*  24:    */   public void setBitmapSetter(BitmapSetter<T> bitmapSetter)
/*  25:    */   {
/*  26: 86 */     this.bitmapSetter = bitmapSetter;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setBitmap(T container, Bitmap bitmap)
/*  30:    */   {
/*  31: 91 */     if (this.bitmapSetter != null) {
/*  32: 93 */       this.bitmapSetter.setBitmap(container, bitmap);
/*  33: 94 */     } else if ((container instanceof ImageView)) {
/*  34: 96 */       ((ImageView)container).setImageBitmap(bitmap);
/*  35:    */     } else {
/*  36: 99 */       container.setBackgroundDrawable(new BitmapDrawable(container.getResources(), bitmap));
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setDrawable(T container, Drawable drawable)
/*  41:    */   {
/*  42:105 */     if (this.bitmapSetter != null) {
/*  43:107 */       this.bitmapSetter.setDrawable(container, drawable);
/*  44:108 */     } else if ((container instanceof ImageView)) {
/*  45:110 */       ((ImageView)container).setImageDrawable(drawable);
/*  46:    */     } else {
/*  47:113 */       container.setBackgroundDrawable(drawable);
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Drawable getDrawable(T container)
/*  52:    */   {
/*  53:119 */     if (this.bitmapSetter != null) {
/*  54:121 */       return this.bitmapSetter.getDrawable(container);
/*  55:    */     }
/*  56:122 */     if ((container instanceof ImageView)) {
/*  57:124 */       return ((ImageView)container).getDrawable();
/*  58:    */     }
/*  59:127 */     return container.getBackground();
/*  60:    */   }
/*  61:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack
 * JD-Core Version:    0.7.0.1
 */