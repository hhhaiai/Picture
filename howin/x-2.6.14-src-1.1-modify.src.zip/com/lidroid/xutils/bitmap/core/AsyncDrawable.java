/*   1:    */ package com.lidroid.xutils.bitmap.core;
/*   2:    */ 
/*   3:    */ import android.graphics.Canvas;
/*   4:    */ import android.graphics.ColorFilter;
/*   5:    */ import android.graphics.PorterDuff.Mode;
/*   6:    */ import android.graphics.Rect;
/*   7:    */ import android.graphics.Region;
/*   8:    */ import android.graphics.drawable.Drawable;
/*   9:    */ import android.graphics.drawable.Drawable.ConstantState;
/*  10:    */ import android.view.View;
/*  11:    */ import com.lidroid.xutils.BitmapUtils.BitmapLoadTask;
/*  12:    */ import java.lang.ref.WeakReference;
/*  13:    */ 
/*  14:    */ public class AsyncDrawable<T extends View>
/*  15:    */   extends Drawable
/*  16:    */ {
/*  17:    */   private final WeakReference<BitmapUtils.BitmapLoadTask<T>> bitmapLoadTaskReference;
/*  18:    */   private final Drawable baseDrawable;
/*  19:    */   
/*  20:    */   public AsyncDrawable(Drawable drawable, BitmapUtils.BitmapLoadTask<T> bitmapWorkerTask)
/*  21:    */   {
/*  22: 22 */     if (bitmapWorkerTask == null) {
/*  23: 24 */       throw new IllegalArgumentException("bitmapWorkerTask may not be null");
/*  24:    */     }
/*  25: 26 */     this.baseDrawable = drawable;
/*  26: 27 */     this.bitmapLoadTaskReference = new WeakReference(bitmapWorkerTask);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public BitmapUtils.BitmapLoadTask<T> getBitmapWorkerTask()
/*  30:    */   {
/*  31: 32 */     return (BitmapUtils.BitmapLoadTask)this.bitmapLoadTaskReference.get();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void draw(Canvas canvas)
/*  35:    */   {
/*  36: 38 */     if (this.baseDrawable != null) {
/*  37: 40 */       this.baseDrawable.draw(canvas);
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setAlpha(int i)
/*  42:    */   {
/*  43: 47 */     if (this.baseDrawable != null) {
/*  44: 49 */       this.baseDrawable.setAlpha(i);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setColorFilter(ColorFilter colorFilter)
/*  49:    */   {
/*  50: 56 */     if (this.baseDrawable != null) {
/*  51: 58 */       this.baseDrawable.setColorFilter(colorFilter);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public int getOpacity()
/*  56:    */   {
/*  57: 65 */     return this.baseDrawable == null ? 127 : this.baseDrawable.getOpacity();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void setBounds(int left, int top, int right, int bottom)
/*  61:    */   {
/*  62: 71 */     if (this.baseDrawable != null) {
/*  63: 73 */       this.baseDrawable.setBounds(left, top, right, bottom);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setBounds(Rect bounds)
/*  68:    */   {
/*  69: 80 */     if (this.baseDrawable != null) {
/*  70: 82 */       this.baseDrawable.setBounds(bounds);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setChangingConfigurations(int configs)
/*  75:    */   {
/*  76: 89 */     if (this.baseDrawable != null) {
/*  77: 91 */       this.baseDrawable.setChangingConfigurations(configs);
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int getChangingConfigurations()
/*  82:    */   {
/*  83: 98 */     return this.baseDrawable == null ? 0 : this.baseDrawable.getChangingConfigurations();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setDither(boolean dither)
/*  87:    */   {
/*  88:104 */     if (this.baseDrawable != null) {
/*  89:106 */       this.baseDrawable.setDither(dither);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setFilterBitmap(boolean filter)
/*  94:    */   {
/*  95:113 */     if (this.baseDrawable != null) {
/*  96:115 */       this.baseDrawable.setFilterBitmap(filter);
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void invalidateSelf()
/* 101:    */   {
/* 102:122 */     if (this.baseDrawable != null) {
/* 103:124 */       this.baseDrawable.invalidateSelf();
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void scheduleSelf(Runnable what, long when)
/* 108:    */   {
/* 109:131 */     if (this.baseDrawable != null) {
/* 110:133 */       this.baseDrawable.scheduleSelf(what, when);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void unscheduleSelf(Runnable what)
/* 115:    */   {
/* 116:140 */     if (this.baseDrawable != null) {
/* 117:142 */       this.baseDrawable.unscheduleSelf(what);
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setColorFilter(int color, PorterDuff.Mode mode)
/* 122:    */   {
/* 123:149 */     if (this.baseDrawable != null) {
/* 124:151 */       this.baseDrawable.setColorFilter(color, mode);
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void clearColorFilter()
/* 129:    */   {
/* 130:158 */     if (this.baseDrawable != null) {
/* 131:160 */       this.baseDrawable.clearColorFilter();
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public boolean isStateful()
/* 136:    */   {
/* 137:167 */     return (this.baseDrawable != null) && (this.baseDrawable.isStateful());
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean setState(int[] stateSet)
/* 141:    */   {
/* 142:173 */     return (this.baseDrawable != null) && (this.baseDrawable.setState(stateSet));
/* 143:    */   }
/* 144:    */   
/* 145:    */   public int[] getState()
/* 146:    */   {
/* 147:179 */     return this.baseDrawable == null ? null : this.baseDrawable.getState();
/* 148:    */   }
/* 149:    */   
/* 150:    */   public Drawable getCurrent()
/* 151:    */   {
/* 152:185 */     return this.baseDrawable == null ? null : this.baseDrawable.getCurrent();
/* 153:    */   }
/* 154:    */   
/* 155:    */   public boolean setVisible(boolean visible, boolean restart)
/* 156:    */   {
/* 157:191 */     return (this.baseDrawable != null) && (this.baseDrawable.setVisible(visible, restart));
/* 158:    */   }
/* 159:    */   
/* 160:    */   public Region getTransparentRegion()
/* 161:    */   {
/* 162:197 */     return this.baseDrawable == null ? null : this.baseDrawable.getTransparentRegion();
/* 163:    */   }
/* 164:    */   
/* 165:    */   public int getIntrinsicWidth()
/* 166:    */   {
/* 167:203 */     return this.baseDrawable == null ? 0 : this.baseDrawable.getIntrinsicWidth();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public int getIntrinsicHeight()
/* 171:    */   {
/* 172:209 */     return this.baseDrawable == null ? 0 : this.baseDrawable.getIntrinsicHeight();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public int getMinimumWidth()
/* 176:    */   {
/* 177:215 */     return this.baseDrawable == null ? 0 : this.baseDrawable.getMinimumWidth();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public int getMinimumHeight()
/* 181:    */   {
/* 182:221 */     return this.baseDrawable == null ? 0 : this.baseDrawable.getMinimumHeight();
/* 183:    */   }
/* 184:    */   
/* 185:    */   public boolean getPadding(Rect padding)
/* 186:    */   {
/* 187:227 */     return (this.baseDrawable != null) && (this.baseDrawable.getPadding(padding));
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Drawable mutate()
/* 191:    */   {
/* 192:233 */     return this.baseDrawable == null ? null : this.baseDrawable.mutate();
/* 193:    */   }
/* 194:    */   
/* 195:    */   public Drawable.ConstantState getConstantState()
/* 196:    */   {
/* 197:239 */     return this.baseDrawable == null ? null : this.baseDrawable.getConstantState();
/* 198:    */   }
/* 199:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.core.AsyncDrawable
 * JD-Core Version:    0.7.0.1
 */