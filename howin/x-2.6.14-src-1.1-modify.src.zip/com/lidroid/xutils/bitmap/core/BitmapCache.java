/*   1:    */ package com.lidroid.xutils.bitmap.core;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.graphics.Matrix;
/*   5:    */ import android.media.ExifInterface;
/*   6:    */ import com.lidroid.xutils.BitmapUtils.BitmapLoadTask;
/*   7:    */ import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
/*   8:    */ import com.lidroid.xutils.bitmap.BitmapGlobalConfig;
/*   9:    */ import com.lidroid.xutils.bitmap.download.Downloader;
/*  10:    */ import com.lidroid.xutils.bitmap.factory.BitmapFactory;
/*  11:    */ import com.lidroid.xutils.cache.FileNameGenerator;
/*  12:    */ import com.lidroid.xutils.cache.LruDiskCache;
/*  13:    */ import com.lidroid.xutils.cache.LruDiskCache.Editor;
/*  14:    */ import com.lidroid.xutils.cache.LruDiskCache.Snapshot;
/*  15:    */ import com.lidroid.xutils.cache.LruMemoryCache;
/*  16:    */ import com.lidroid.xutils.util.IOUtils;
/*  17:    */ import com.lidroid.xutils.util.LogUtils;
/*  18:    */ import com.lidroid.xutils.util.OtherUtils;
/*  19:    */ import java.io.ByteArrayOutputStream;
/*  20:    */ import java.io.File;
/*  21:    */ import java.io.FileInputStream;
/*  22:    */ import java.io.IOException;
/*  23:    */ import java.io.OutputStream;
/*  24:    */ 
/*  25:    */ public class BitmapCache
/*  26:    */ {
/*  27: 37 */   private final int DISK_CACHE_INDEX = 0;
/*  28:    */   private LruDiskCache mDiskLruCache;
/*  29:    */   private LruMemoryCache<MemoryCacheKey, Bitmap> mMemoryCache;
/*  30: 42 */   private final Object mDiskCacheLock = new Object();
/*  31:    */   private BitmapGlobalConfig globalConfig;
/*  32:    */   
/*  33:    */   public BitmapCache(BitmapGlobalConfig globalConfig)
/*  34:    */   {
/*  35: 54 */     if (globalConfig == null) {
/*  36: 55 */       throw new IllegalArgumentException("globalConfig may not be null");
/*  37:    */     }
/*  38: 56 */     this.globalConfig = globalConfig;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void initMemoryCache()
/*  42:    */   {
/*  43: 64 */     if (!this.globalConfig.isMemoryCacheEnabled()) {
/*  44: 65 */       return;
/*  45:    */     }
/*  46: 68 */     if (this.mMemoryCache != null) {
/*  47:    */       try
/*  48:    */       {
/*  49: 72 */         clearMemoryCache();
/*  50:    */       }
/*  51:    */       catch (Throwable localThrowable) {}
/*  52:    */     }
/*  53: 77 */     this.mMemoryCache = new LruMemoryCache(this.globalConfig.getMemoryCacheSize())
/*  54:    */     {
/*  55:    */       protected int sizeOf(BitmapCache.MemoryCacheKey key, Bitmap bitmap)
/*  56:    */       {
/*  57: 86 */         if (bitmap == null) {
/*  58: 87 */           return 0;
/*  59:    */         }
/*  60: 88 */         return bitmap.getRowBytes() * bitmap.getHeight();
/*  61:    */       }
/*  62:    */     };
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void initDiskCache()
/*  66:    */   {
/*  67:102 */     synchronized (this.mDiskCacheLock)
/*  68:    */     {
/*  69:104 */       if ((this.globalConfig.isDiskCacheEnabled()) && ((this.mDiskLruCache == null) || (this.mDiskLruCache.isClosed())))
/*  70:    */       {
/*  71:106 */         File diskCacheDir = new File(this.globalConfig.getDiskCachePath());
/*  72:107 */         if ((diskCacheDir.exists()) || (diskCacheDir.mkdirs()))
/*  73:    */         {
/*  74:109 */           long availableSpace = OtherUtils.getAvailableSpace(diskCacheDir);
/*  75:110 */           long diskCacheSize = this.globalConfig.getDiskCacheSize();
/*  76:111 */           diskCacheSize = availableSpace > diskCacheSize ? diskCacheSize : availableSpace;
/*  77:    */           try
/*  78:    */           {
/*  79:114 */             this.mDiskLruCache = LruDiskCache.open(diskCacheDir, 1, 1, diskCacheSize);
/*  80:115 */             this.mDiskLruCache.setFileNameGenerator(this.globalConfig.getFileNameGenerator());
/*  81:116 */             LogUtils.d("create disk cache success");
/*  82:    */           }
/*  83:    */           catch (Throwable e)
/*  84:    */           {
/*  85:119 */             this.mDiskLruCache = null;
/*  86:120 */             LogUtils.e("create disk cache error", e);
/*  87:    */           }
/*  88:    */         }
/*  89:    */       }
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setMemoryCacheSize(int maxSize)
/*  94:    */   {
/*  95:129 */     if (this.mMemoryCache != null) {
/*  96:131 */       this.mMemoryCache.setMaxSize(maxSize);
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void setDiskCacheSize(int maxSize)
/* 101:    */   {
/* 102:137 */     synchronized (this.mDiskCacheLock)
/* 103:    */     {
/* 104:139 */       if (this.mDiskLruCache != null) {
/* 105:141 */         this.mDiskLruCache.setMaxSize(maxSize);
/* 106:    */       }
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void setDiskCacheFileNameGenerator(FileNameGenerator fileNameGenerator)
/* 111:    */   {
/* 112:148 */     synchronized (this.mDiskCacheLock)
/* 113:    */     {
/* 114:150 */       if ((this.mDiskLruCache != null) && (fileNameGenerator != null)) {
/* 115:152 */         this.mDiskLruCache.setFileNameGenerator(fileNameGenerator);
/* 116:    */       }
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Bitmap downloadBitmap(String uri, BitmapDisplayConfig config, BitmapUtils.BitmapLoadTask<?> task)
/* 121:    */   {
/* 122:160 */     BitmapMeta bitmapMeta = new BitmapMeta(null);
/* 123:    */     
/* 124:162 */     OutputStream outputStream = null;
/* 125:163 */     LruDiskCache.Snapshot snapshot = null;
/* 126:    */     try
/* 127:    */     {
/* 128:167 */       Bitmap bitmap = null;
/* 129:170 */       if (this.globalConfig.isDiskCacheEnabled())
/* 130:    */       {
/* 131:172 */         if (this.mDiskLruCache == null) {
/* 132:174 */           initDiskCache();
/* 133:    */         }
/* 134:177 */         if (this.mDiskLruCache != null) {
/* 135:    */           try
/* 136:    */           {
/* 137:181 */             snapshot = this.mDiskLruCache.get(uri);
/* 138:182 */             if (snapshot == null)
/* 139:    */             {
/* 140:184 */               LruDiskCache.Editor editor = this.mDiskLruCache.edit(uri);
/* 141:185 */               if (editor != null)
/* 142:    */               {
/* 143:187 */                 outputStream = editor.newOutputStream(0);
/* 144:188 */                 bitmapMeta.expiryTimestamp = this.globalConfig.getDownloader().downloadToStream(uri, outputStream, task);
/* 145:189 */                 if (bitmapMeta.expiryTimestamp < 0L)
/* 146:    */                 {
/* 147:191 */                   editor.abort();
/* 148:192 */                   return null;
/* 149:    */                 }
/* 150:195 */                 editor.setEntryExpiryTimestamp(bitmapMeta.expiryTimestamp);
/* 151:196 */                 editor.commit();
/* 152:    */                 
/* 153:198 */                 snapshot = this.mDiskLruCache.get(uri);
/* 154:    */               }
/* 155:    */             }
/* 156:201 */             if (snapshot != null)
/* 157:    */             {
/* 158:203 */               bitmapMeta.inputStream = snapshot.getInputStream(0);
/* 159:204 */               bitmap = decodeBitmapMeta(bitmapMeta, config);
/* 160:205 */               if (bitmap == null)
/* 161:    */               {
/* 162:207 */                 bitmapMeta.inputStream = null;
/* 163:208 */                 this.mDiskLruCache.remove(uri);
/* 164:    */               }
/* 165:    */             }
/* 166:    */           }
/* 167:    */           catch (Throwable e)
/* 168:    */           {
/* 169:213 */             LogUtils.e(e.getMessage(), e);
/* 170:    */           }
/* 171:    */         }
/* 172:    */       }
/* 173:219 */       if (bitmap == null)
/* 174:    */       {
/* 175:221 */         outputStream = new ByteArrayOutputStream();
/* 176:222 */         bitmapMeta.expiryTimestamp = this.globalConfig.getDownloader().downloadToStream(uri, outputStream, task);
/* 177:223 */         if (bitmapMeta.expiryTimestamp < 0L) {
/* 178:225 */           return null;
/* 179:    */         }
/* 180:228 */         bitmapMeta.data = ((ByteArrayOutputStream)outputStream).toByteArray();
/* 181:229 */         bitmap = decodeBitmapMeta(bitmapMeta, config);
/* 182:    */       }
/* 183:233 */       if (bitmap != null)
/* 184:    */       {
/* 185:235 */         bitmap = rotateBitmapIfNeeded(uri, config, bitmap);
/* 186:236 */         bitmap = addBitmapToMemoryCache(uri, config, bitmap, bitmapMeta.expiryTimestamp);
/* 187:    */       }
/* 188:238 */       return bitmap;
/* 189:    */     }
/* 190:    */     catch (Throwable e)
/* 191:    */     {
/* 192:241 */       LogUtils.e(e.getMessage(), e);
/* 193:    */     }
/* 194:    */     finally
/* 195:    */     {
/* 196:244 */       IOUtils.closeQuietly(outputStream);
/* 197:245 */       IOUtils.closeQuietly(snapshot);
/* 198:    */     }
/* 199:248 */     return null;
/* 200:    */   }
/* 201:    */   
/* 202:    */   private Bitmap addBitmapToMemoryCache(String uri, BitmapDisplayConfig config, Bitmap bitmap, long expiryTimestamp)
/* 203:    */     throws IOException
/* 204:    */   {
/* 205:253 */     if (config != null)
/* 206:    */     {
/* 207:255 */       BitmapFactory bitmapFactory = config.getBitmapFactory();
/* 208:256 */       if (bitmapFactory != null) {
/* 209:258 */         bitmap = bitmapFactory.cloneNew().createBitmap(bitmap);
/* 210:    */       }
/* 211:    */     }
/* 212:261 */     if ((uri != null) && (bitmap != null) && (this.globalConfig.isMemoryCacheEnabled()) && (this.mMemoryCache != null))
/* 213:    */     {
/* 214:263 */       MemoryCacheKey key = new MemoryCacheKey(uri, config, null);
/* 215:264 */       this.mMemoryCache.put(key, bitmap, expiryTimestamp);
/* 216:    */     }
/* 217:266 */     return bitmap;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public Bitmap getBitmapFromMemCache(String uri, BitmapDisplayConfig config)
/* 221:    */   {
/* 222:279 */     if ((this.mMemoryCache != null) && (this.globalConfig.isMemoryCacheEnabled()))
/* 223:    */     {
/* 224:281 */       MemoryCacheKey key = new MemoryCacheKey(uri, config, null);
/* 225:282 */       return (Bitmap)this.mMemoryCache.get(key);
/* 226:    */     }
/* 227:284 */     return null;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public File getBitmapFileFromDiskCache(String uri)
/* 231:    */   {
/* 232:296 */     synchronized (this.mDiskCacheLock)
/* 233:    */     {
/* 234:298 */       if (this.mDiskLruCache != null) {
/* 235:300 */         return this.mDiskLruCache.getCacheFile(uri, 0);
/* 236:    */       }
/* 237:303 */       return null;
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   public Bitmap getBitmapFromDiskCache(String uri, BitmapDisplayConfig config)
/* 242:    */   {
/* 243:317 */     if ((uri == null) || (!this.globalConfig.isDiskCacheEnabled())) {
/* 244:318 */       return null;
/* 245:    */     }
/* 246:319 */     if (this.mDiskLruCache == null) {
/* 247:321 */       initDiskCache();
/* 248:    */     }
/* 249:323 */     if (this.mDiskLruCache != null)
/* 250:    */     {
/* 251:325 */       LruDiskCache.Snapshot snapshot = null;
/* 252:    */       try
/* 253:    */       {
/* 254:328 */         snapshot = this.mDiskLruCache.get(uri);
/* 255:329 */         if (snapshot != null)
/* 256:    */         {
/* 257:331 */           Bitmap bitmap = null;
/* 258:332 */           if ((config == null) || (config.isShowOriginal())) {
/* 259:334 */             bitmap = BitmapDecoder.decodeFileDescriptor(snapshot.getInputStream(0).getFD());
/* 260:    */           } else {
/* 261:337 */             bitmap = BitmapDecoder.decodeSampledBitmapFromDescriptor(snapshot.getInputStream(0).getFD(), config.getBitmapMaxSize(), 
/* 262:338 */               config.getBitmapConfig());
/* 263:    */           }
/* 264:341 */           bitmap = rotateBitmapIfNeeded(uri, config, bitmap);
/* 265:342 */           bitmap = addBitmapToMemoryCache(uri, config, bitmap, this.mDiskLruCache.getExpiryTimestamp(uri));
/* 266:343 */           return bitmap;
/* 267:    */         }
/* 268:    */       }
/* 269:    */       catch (Throwable e)
/* 270:    */       {
/* 271:347 */         LogUtils.e(e.getMessage(), e);
/* 272:    */       }
/* 273:    */       finally
/* 274:    */       {
/* 275:350 */         IOUtils.closeQuietly(snapshot);
/* 276:    */       }
/* 277:350 */       IOUtils.closeQuietly(snapshot);
/* 278:    */     }
/* 279:353 */     return null;
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void clearCache()
/* 283:    */   {
/* 284:363 */     clearMemoryCache();
/* 285:364 */     clearDiskCache();
/* 286:    */   }
/* 287:    */   
/* 288:    */   public void clearMemoryCache()
/* 289:    */   {
/* 290:369 */     if (this.mMemoryCache != null) {
/* 291:371 */       this.mMemoryCache.evictAll();
/* 292:    */     }
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void clearDiskCache()
/* 296:    */   {
/* 297:377 */     synchronized (this.mDiskCacheLock)
/* 298:    */     {
/* 299:379 */       if ((this.mDiskLruCache != null) && (!this.mDiskLruCache.isClosed()))
/* 300:    */       {
/* 301:    */         try
/* 302:    */         {
/* 303:383 */           this.mDiskLruCache.delete();
/* 304:384 */           this.mDiskLruCache.close();
/* 305:    */         }
/* 306:    */         catch (Throwable e)
/* 307:    */         {
/* 308:387 */           LogUtils.e(e.getMessage(), e);
/* 309:    */         }
/* 310:389 */         this.mDiskLruCache = null;
/* 311:    */       }
/* 312:    */     }
/* 313:392 */     initDiskCache();
/* 314:    */   }
/* 315:    */   
/* 316:    */   public void clearCache(String uri)
/* 317:    */   {
/* 318:397 */     clearMemoryCache(uri);
/* 319:398 */     clearDiskCache(uri);
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void clearMemoryCache(String uri)
/* 323:    */   {
/* 324:403 */     MemoryCacheKey key = new MemoryCacheKey(uri, null, null);
/* 325:404 */     if (this.mMemoryCache != null) {
/* 326:406 */       while (this.mMemoryCache.containsKey(key)) {
/* 327:408 */         this.mMemoryCache.remove(key);
/* 328:    */       }
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   public void clearDiskCache(String uri)
/* 333:    */   {
/* 334:415 */     synchronized (this.mDiskCacheLock)
/* 335:    */     {
/* 336:417 */       if ((this.mDiskLruCache != null) && (!this.mDiskLruCache.isClosed())) {
/* 337:    */         try
/* 338:    */         {
/* 339:421 */           this.mDiskLruCache.remove(uri);
/* 340:    */         }
/* 341:    */         catch (Throwable e)
/* 342:    */         {
/* 343:424 */           LogUtils.e(e.getMessage(), e);
/* 344:    */         }
/* 345:    */       }
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void flush()
/* 350:    */   {
/* 351:437 */     synchronized (this.mDiskCacheLock)
/* 352:    */     {
/* 353:439 */       if (this.mDiskLruCache != null) {
/* 354:    */         try
/* 355:    */         {
/* 356:443 */           this.mDiskLruCache.flush();
/* 357:    */         }
/* 358:    */         catch (Throwable e)
/* 359:    */         {
/* 360:446 */           LogUtils.e(e.getMessage(), e);
/* 361:    */         }
/* 362:    */       }
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void close()
/* 367:    */   {
/* 368:459 */     synchronized (this.mDiskCacheLock)
/* 369:    */     {
/* 370:461 */       if (this.mDiskLruCache != null)
/* 371:    */       {
/* 372:    */         try
/* 373:    */         {
/* 374:465 */           if (!this.mDiskLruCache.isClosed()) {
/* 375:467 */             this.mDiskLruCache.close();
/* 376:    */           }
/* 377:    */         }
/* 378:    */         catch (Throwable e)
/* 379:    */         {
/* 380:471 */           LogUtils.e(e.getMessage(), e);
/* 381:    */         }
/* 382:473 */         this.mDiskLruCache = null;
/* 383:    */       }
/* 384:    */     }
/* 385:    */   }
/* 386:    */   
/* 387:    */   private Bitmap decodeBitmapMeta(BitmapMeta bitmapMeta, BitmapDisplayConfig config)
/* 388:    */     throws IOException
/* 389:    */   {
/* 390:487 */     if (bitmapMeta == null) {
/* 391:488 */       return null;
/* 392:    */     }
/* 393:489 */     Bitmap bitmap = null;
/* 394:490 */     if (bitmapMeta.inputStream != null)
/* 395:    */     {
/* 396:492 */       if ((config == null) || (config.isShowOriginal())) {
/* 397:494 */         bitmap = BitmapDecoder.decodeFileDescriptor(bitmapMeta.inputStream.getFD());
/* 398:    */       } else {
/* 399:497 */         bitmap = BitmapDecoder.decodeSampledBitmapFromDescriptor(bitmapMeta.inputStream.getFD(), config.getBitmapMaxSize(), config.getBitmapConfig());
/* 400:    */       }
/* 401:    */     }
/* 402:499 */     else if (bitmapMeta.data != null) {
/* 403:501 */       if ((config == null) || (config.isShowOriginal())) {
/* 404:503 */         bitmap = BitmapDecoder.decodeByteArray(bitmapMeta.data);
/* 405:    */       } else {
/* 406:506 */         bitmap = BitmapDecoder.decodeSampledBitmapFromByteArray(bitmapMeta.data, config.getBitmapMaxSize(), config.getBitmapConfig());
/* 407:    */       }
/* 408:    */     }
/* 409:509 */     return bitmap;
/* 410:    */   }
/* 411:    */   
/* 412:    */   private synchronized Bitmap rotateBitmapIfNeeded(String uri, BitmapDisplayConfig config, Bitmap bitmap)
/* 413:    */   {
/* 414:514 */     Bitmap result = bitmap;
/* 415:515 */     if ((config != null) && (config.isAutoRotation()))
/* 416:    */     {
/* 417:517 */       File bitmapFile = getBitmapFileFromDiskCache(uri);
/* 418:518 */       if ((bitmapFile != null) && (bitmapFile.exists()))
/* 419:    */       {
/* 420:520 */         ExifInterface exif = null;
/* 421:    */         try
/* 422:    */         {
/* 423:523 */           exif = new ExifInterface(bitmapFile.getPath());
/* 424:    */         }
/* 425:    */         catch (Throwable e)
/* 426:    */         {
/* 427:526 */           return result;
/* 428:    */         }
/* 429:528 */         int orientation = exif.getAttributeInt("Orientation", 0);
/* 430:529 */         int angle = 0;
/* 431:530 */         switch (orientation)
/* 432:    */         {
/* 433:    */         case 6: 
/* 434:533 */           angle = 90;
/* 435:534 */           break;
/* 436:    */         case 3: 
/* 437:536 */           angle = 180;
/* 438:537 */           break;
/* 439:    */         case 8: 
/* 440:539 */           angle = 270;
/* 441:540 */           break;
/* 442:    */         case 4: 
/* 443:    */         case 5: 
/* 444:    */         case 7: 
/* 445:    */         default: 
/* 446:542 */           angle = 0;
/* 447:    */         }
/* 448:545 */         if (angle != 0)
/* 449:    */         {
/* 450:547 */           Matrix m = new Matrix();
/* 451:548 */           m.postRotate(angle);
/* 452:549 */           result = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
/* 453:550 */           bitmap.recycle();
/* 454:551 */           bitmap = null;
/* 455:    */         }
/* 456:    */       }
/* 457:    */     }
/* 458:555 */     return result;
/* 459:    */   }
/* 460:    */   
/* 461:    */   private class BitmapMeta
/* 462:    */   {
/* 463:    */     public FileInputStream inputStream;
/* 464:    */     public byte[] data;
/* 465:    */     public long expiryTimestamp;
/* 466:    */     
/* 467:    */     private BitmapMeta() {}
/* 468:    */   }
/* 469:    */   
/* 470:    */   public class MemoryCacheKey
/* 471:    */   {
/* 472:    */     private String uri;
/* 473:    */     private String subKey;
/* 474:    */     
/* 475:    */     private MemoryCacheKey(String uri, BitmapDisplayConfig config)
/* 476:    */     {
/* 477:565 */       this.uri = uri;
/* 478:566 */       this.subKey = (config == null ? null : config.toString());
/* 479:    */     }
/* 480:    */     
/* 481:    */     public boolean equals(Object o)
/* 482:    */     {
/* 483:572 */       if (this == o) {
/* 484:573 */         return true;
/* 485:    */       }
/* 486:574 */       if (!(o instanceof MemoryCacheKey)) {
/* 487:575 */         return false;
/* 488:    */       }
/* 489:577 */       MemoryCacheKey that = (MemoryCacheKey)o;
/* 490:579 */       if (!this.uri.equals(that.uri)) {
/* 491:580 */         return false;
/* 492:    */       }
/* 493:582 */       if ((this.subKey != null) && (that.subKey != null)) {
/* 494:584 */         return this.subKey.equals(that.subKey);
/* 495:    */       }
/* 496:587 */       return true;
/* 497:    */     }
/* 498:    */     
/* 499:    */     public int hashCode()
/* 500:    */     {
/* 501:593 */       return this.uri.hashCode();
/* 502:    */     }
/* 503:    */   }
/* 504:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.core.BitmapCache
 * JD-Core Version:    0.7.0.1
 */