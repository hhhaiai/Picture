/*   1:    */ package com.lidroid.xutils.bitmap.core;
/*   2:    */ 
/*   3:    */ import android.content.res.Resources;
/*   4:    */ import android.graphics.Bitmap;
/*   5:    */ import android.graphics.Bitmap.Config;
/*   6:    */ import android.graphics.BitmapFactory;
/*   7:    */ import android.graphics.BitmapFactory.Options;
/*   8:    */ import com.lidroid.xutils.util.LogUtils;
/*   9:    */ import java.io.FileDescriptor;
/*  10:    */ 
/*  11:    */ public class BitmapDecoder
/*  12:    */ {
/*  13: 28 */   private static final Object lock = new Object();
/*  14:    */   
/*  15:    */   public static Bitmap decodeSampledBitmapFromResource(Resources res, int resId, BitmapSize maxSize, Bitmap.Config config)
/*  16:    */   {
/*  17: 36 */     synchronized (lock)
/*  18:    */     {
/*  19: 38 */       BitmapFactory.Options options = new BitmapFactory.Options();
/*  20: 39 */       options.inJustDecodeBounds = true;
/*  21: 40 */       options.inPurgeable = true;
/*  22: 41 */       options.inInputShareable = true;
/*  23: 42 */       BitmapFactory.decodeResource(res, resId, options);
/*  24: 43 */       options.inSampleSize = calculateInSampleSize(options, maxSize.getWidth(), maxSize.getHeight());
/*  25: 44 */       options.inJustDecodeBounds = false;
/*  26: 45 */       if (config != null) {
/*  27: 47 */         options.inPreferredConfig = config;
/*  28:    */       }
/*  29:    */       try
/*  30:    */       {
/*  31: 51 */         return BitmapFactory.decodeResource(res, resId, options);
/*  32:    */       }
/*  33:    */       catch (Throwable e)
/*  34:    */       {
/*  35: 54 */         LogUtils.e(e.getMessage(), e);
/*  36: 55 */         return null;
/*  37:    */       }
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static Bitmap decodeSampledBitmapFromFile(String filename, BitmapSize maxSize, Bitmap.Config config)
/*  42:    */   {
/*  43: 62 */     synchronized (lock)
/*  44:    */     {
/*  45: 64 */       BitmapFactory.Options options = new BitmapFactory.Options();
/*  46: 65 */       options.inJustDecodeBounds = true;
/*  47: 66 */       options.inPurgeable = true;
/*  48: 67 */       options.inInputShareable = true;
/*  49: 68 */       BitmapFactory.decodeFile(filename, options);
/*  50: 69 */       options.inSampleSize = calculateInSampleSize(options, maxSize.getWidth(), maxSize.getHeight());
/*  51: 70 */       options.inJustDecodeBounds = false;
/*  52: 71 */       if (config != null) {
/*  53: 73 */         options.inPreferredConfig = config;
/*  54:    */       }
/*  55:    */       try
/*  56:    */       {
/*  57: 77 */         return BitmapFactory.decodeFile(filename, options);
/*  58:    */       }
/*  59:    */       catch (Throwable e)
/*  60:    */       {
/*  61: 80 */         LogUtils.e(e.getMessage(), e);
/*  62: 81 */         return null;
/*  63:    */       }
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static Bitmap decodeSampledBitmapFromDescriptor(FileDescriptor fileDescriptor, BitmapSize maxSize, Bitmap.Config config)
/*  68:    */   {
/*  69: 88 */     synchronized (lock)
/*  70:    */     {
/*  71: 90 */       BitmapFactory.Options options = new BitmapFactory.Options();
/*  72: 91 */       options.inJustDecodeBounds = true;
/*  73: 92 */       options.inPurgeable = true;
/*  74: 93 */       options.inInputShareable = true;
/*  75: 94 */       BitmapFactory.decodeFileDescriptor(fileDescriptor, null, options);
/*  76: 95 */       options.inSampleSize = calculateInSampleSize(options, maxSize.getWidth(), maxSize.getHeight());
/*  77: 96 */       options.inJustDecodeBounds = false;
/*  78: 97 */       if (config != null) {
/*  79: 99 */         options.inPreferredConfig = config;
/*  80:    */       }
/*  81:    */       try
/*  82:    */       {
/*  83:103 */         return BitmapFactory.decodeFileDescriptor(fileDescriptor, null, options);
/*  84:    */       }
/*  85:    */       catch (Throwable e)
/*  86:    */       {
/*  87:106 */         LogUtils.e(e.getMessage(), e);
/*  88:107 */         return null;
/*  89:    */       }
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static Bitmap decodeSampledBitmapFromByteArray(byte[] data, BitmapSize maxSize, Bitmap.Config config)
/*  94:    */   {
/*  95:114 */     synchronized (lock)
/*  96:    */     {
/*  97:116 */       BitmapFactory.Options options = new BitmapFactory.Options();
/*  98:117 */       options.inJustDecodeBounds = true;
/*  99:118 */       options.inPurgeable = true;
/* 100:119 */       options.inInputShareable = true;
/* 101:120 */       BitmapFactory.decodeByteArray(data, 0, data.length, options);
/* 102:121 */       options.inSampleSize = calculateInSampleSize(options, maxSize.getWidth(), maxSize.getHeight());
/* 103:122 */       options.inJustDecodeBounds = false;
/* 104:123 */       if (config != null) {
/* 105:125 */         options.inPreferredConfig = config;
/* 106:    */       }
/* 107:    */       try
/* 108:    */       {
/* 109:129 */         return BitmapFactory.decodeByteArray(data, 0, data.length, options);
/* 110:    */       }
/* 111:    */       catch (Throwable e)
/* 112:    */       {
/* 113:132 */         LogUtils.e(e.getMessage(), e);
/* 114:133 */         return null;
/* 115:    */       }
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static Bitmap decodeResource(Resources res, int resId)
/* 120:    */   {
/* 121:140 */     synchronized (lock)
/* 122:    */     {
/* 123:142 */       BitmapFactory.Options options = new BitmapFactory.Options();
/* 124:143 */       options.inPurgeable = true;
/* 125:144 */       options.inInputShareable = true;
/* 126:    */       try
/* 127:    */       {
/* 128:147 */         return BitmapFactory.decodeResource(res, resId, options);
/* 129:    */       }
/* 130:    */       catch (Throwable e)
/* 131:    */       {
/* 132:150 */         LogUtils.e(e.getMessage(), e);
/* 133:151 */         return null;
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static Bitmap decodeFile(String filename)
/* 139:    */   {
/* 140:158 */     synchronized (lock)
/* 141:    */     {
/* 142:160 */       BitmapFactory.Options options = new BitmapFactory.Options();
/* 143:161 */       options.inPurgeable = true;
/* 144:162 */       options.inInputShareable = true;
/* 145:    */       try
/* 146:    */       {
/* 147:165 */         return BitmapFactory.decodeFile(filename, options);
/* 148:    */       }
/* 149:    */       catch (Throwable e)
/* 150:    */       {
/* 151:168 */         LogUtils.e(e.getMessage(), e);
/* 152:169 */         return null;
/* 153:    */       }
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static Bitmap decodeFileDescriptor(FileDescriptor fileDescriptor)
/* 158:    */   {
/* 159:176 */     synchronized (lock)
/* 160:    */     {
/* 161:178 */       BitmapFactory.Options options = new BitmapFactory.Options();
/* 162:179 */       options.inPurgeable = true;
/* 163:180 */       options.inInputShareable = true;
/* 164:    */       try
/* 165:    */       {
/* 166:183 */         return BitmapFactory.decodeFileDescriptor(fileDescriptor, null, options);
/* 167:    */       }
/* 168:    */       catch (Throwable e)
/* 169:    */       {
/* 170:186 */         LogUtils.e(e.getMessage(), e);
/* 171:187 */         return null;
/* 172:    */       }
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static Bitmap decodeByteArray(byte[] data)
/* 177:    */   {
/* 178:194 */     synchronized (lock)
/* 179:    */     {
/* 180:196 */       BitmapFactory.Options options = new BitmapFactory.Options();
/* 181:197 */       options.inPurgeable = true;
/* 182:198 */       options.inInputShareable = true;
/* 183:    */       try
/* 184:    */       {
/* 185:201 */         return BitmapFactory.decodeByteArray(data, 0, data.length, options);
/* 186:    */       }
/* 187:    */       catch (Throwable e)
/* 188:    */       {
/* 189:204 */         LogUtils.e(e.getMessage(), e);
/* 190:205 */         return null;
/* 191:    */       }
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static int calculateInSampleSize(BitmapFactory.Options options, int maxWidth, int maxHeight)
/* 196:    */   {
/* 197:212 */     int height = options.outHeight;
/* 198:213 */     int width = options.outWidth;
/* 199:214 */     int inSampleSize = 1;
/* 200:216 */     if ((width > maxWidth) || (height > maxHeight))
/* 201:    */     {
/* 202:218 */       if (width > height) {
/* 203:220 */         inSampleSize = Math.round(height / maxHeight);
/* 204:    */       } else {
/* 205:223 */         inSampleSize = Math.round(width / maxWidth);
/* 206:    */       }
/* 207:226 */       float totalPixels = width * height;
/* 208:    */       
/* 209:228 */       float maxTotalPixels = maxWidth * maxHeight * 2;
/* 210:230 */       while (totalPixels / (inSampleSize * inSampleSize) > maxTotalPixels) {
/* 211:232 */         inSampleSize++;
/* 212:    */       }
/* 213:    */     }
/* 214:235 */     return inSampleSize;
/* 215:    */   }
/* 216:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.core.BitmapDecoder
 * JD-Core Version:    0.7.0.1
 */