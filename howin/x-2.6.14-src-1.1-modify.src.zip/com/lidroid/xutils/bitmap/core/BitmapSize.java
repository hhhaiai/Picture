/*  1:   */ package com.lidroid.xutils.bitmap.core;
/*  2:   */ 
/*  3:   */ public class BitmapSize
/*  4:   */ {
/*  5: 9 */   public static final BitmapSize ZERO = new BitmapSize(0, 0);
/*  6:   */   private final int width;
/*  7:   */   private final int height;
/*  8:   */   
/*  9:   */   public BitmapSize(int width, int height)
/* 10:   */   {
/* 11:16 */     this.width = width;
/* 12:17 */     this.height = height;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public BitmapSize scaleDown(int sampleSize)
/* 16:   */   {
/* 17:25 */     return new BitmapSize(this.width / sampleSize, this.height / sampleSize);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public BitmapSize scale(float scale)
/* 21:   */   {
/* 22:33 */     return new BitmapSize((int)(this.width * scale), (int)(this.height * scale));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int getWidth()
/* 26:   */   {
/* 27:38 */     return this.width;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getHeight()
/* 31:   */   {
/* 32:43 */     return this.height;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String toString()
/* 36:   */   {
/* 37:49 */     return "_" + this.width + "_" + this.height;
/* 38:   */   }
/* 39:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.core.BitmapSize
 * JD-Core Version:    0.7.0.1
 */