/*   1:    */ package com.lidroid.xutils.bitmap;
/*   2:    */ 
/*   3:    */ import android.widget.AbsListView;
/*   4:    */ import android.widget.AbsListView.OnScrollListener;
/*   5:    */ import com.lidroid.xutils.task.TaskHandler;
/*   6:    */ 
/*   7:    */ public class PauseOnScrollListener
/*   8:    */   implements AbsListView.OnScrollListener
/*   9:    */ {
/*  10:    */   private TaskHandler taskHandler;
/*  11:    */   private final boolean pauseOnScroll;
/*  12:    */   private final boolean pauseOnFling;
/*  13:    */   private final AbsListView.OnScrollListener externalListener;
/*  14:    */   
/*  15:    */   public PauseOnScrollListener(TaskHandler taskHandler, boolean pauseOnScroll, boolean pauseOnFling)
/*  16:    */   {
/*  17: 46 */     this(taskHandler, pauseOnScroll, pauseOnFling, null);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public PauseOnScrollListener(TaskHandler taskHandler, boolean pauseOnScroll, boolean pauseOnFling, AbsListView.OnScrollListener customListener)
/*  21:    */   {
/*  22: 68 */     this.taskHandler = taskHandler;
/*  23: 69 */     this.pauseOnScroll = pauseOnScroll;
/*  24: 70 */     this.pauseOnFling = pauseOnFling;
/*  25: 71 */     this.externalListener = customListener;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void onScrollStateChanged(AbsListView view, int scrollState)
/*  29:    */   {
/*  30: 77 */     switch (scrollState)
/*  31:    */     {
/*  32:    */     case 0: 
/*  33: 80 */       this.taskHandler.resume();
/*  34: 81 */       break;
/*  35:    */     case 1: 
/*  36: 83 */       if (this.pauseOnScroll) {
/*  37: 85 */         this.taskHandler.pause();
/*  38:    */       }
/*  39: 87 */       break;
/*  40:    */     case 2: 
/*  41: 89 */       if (this.pauseOnFling) {
/*  42: 91 */         this.taskHandler.pause();
/*  43:    */       }
/*  44:    */       break;
/*  45:    */     }
/*  46: 95 */     if (this.externalListener != null) {
/*  47: 97 */       this.externalListener.onScrollStateChanged(view, scrollState);
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
/*  52:    */   {
/*  53:104 */     if (this.externalListener != null) {
/*  54:106 */       this.externalListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
/*  55:    */     }
/*  56:    */   }
/*  57:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.PauseOnScrollListener
 * JD-Core Version:    0.7.0.1
 */