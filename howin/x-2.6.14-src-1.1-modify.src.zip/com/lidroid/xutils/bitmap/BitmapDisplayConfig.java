/*   1:    */ package com.lidroid.xutils.bitmap;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap.Config;
/*   4:    */ import android.graphics.drawable.Drawable;
/*   5:    */ import android.view.animation.Animation;
/*   6:    */ import com.lidroid.xutils.bitmap.core.BitmapSize;
/*   7:    */ import com.lidroid.xutils.bitmap.factory.BitmapFactory;
/*   8:    */ import com.lidroid.xutils.task.Priority;
/*   9:    */ 
/*  10:    */ public class BitmapDisplayConfig
/*  11:    */ {
/*  12:    */   private BitmapSize bitmapMaxSize;
/*  13:    */   private Animation animation;
/*  14:    */   private Drawable loadingDrawable;
/*  15:    */   private Drawable loadFailedDrawable;
/*  16: 32 */   private boolean autoRotation = false;
/*  17: 33 */   private boolean showOriginal = false;
/*  18: 34 */   private Bitmap.Config bitmapConfig = Bitmap.Config.RGB_565;
/*  19:    */   private BitmapFactory bitmapFactory;
/*  20:    */   private Priority priority;
/*  21:    */   
/*  22:    */   public BitmapSize getBitmapMaxSize()
/*  23:    */   {
/*  24: 45 */     return this.bitmapMaxSize == null ? BitmapSize.ZERO : this.bitmapMaxSize;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setBitmapMaxSize(BitmapSize bitmapMaxSize)
/*  28:    */   {
/*  29: 50 */     this.bitmapMaxSize = bitmapMaxSize;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Animation getAnimation()
/*  33:    */   {
/*  34: 55 */     return this.animation;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setAnimation(Animation animation)
/*  38:    */   {
/*  39: 60 */     this.animation = animation;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Drawable getLoadingDrawable()
/*  43:    */   {
/*  44: 65 */     return this.loadingDrawable;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setLoadingDrawable(Drawable loadingDrawable)
/*  48:    */   {
/*  49: 70 */     this.loadingDrawable = loadingDrawable;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Drawable getLoadFailedDrawable()
/*  53:    */   {
/*  54: 75 */     return this.loadFailedDrawable;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setLoadFailedDrawable(Drawable loadFailedDrawable)
/*  58:    */   {
/*  59: 80 */     this.loadFailedDrawable = loadFailedDrawable;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean isAutoRotation()
/*  63:    */   {
/*  64: 85 */     return this.autoRotation;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setAutoRotation(boolean autoRotation)
/*  68:    */   {
/*  69: 90 */     this.autoRotation = autoRotation;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isShowOriginal()
/*  73:    */   {
/*  74: 95 */     return this.showOriginal;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setShowOriginal(boolean showOriginal)
/*  78:    */   {
/*  79:100 */     this.showOriginal = showOriginal;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Bitmap.Config getBitmapConfig()
/*  83:    */   {
/*  84:105 */     return this.bitmapConfig;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setBitmapConfig(Bitmap.Config bitmapConfig)
/*  88:    */   {
/*  89:110 */     this.bitmapConfig = bitmapConfig;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public BitmapFactory getBitmapFactory()
/*  93:    */   {
/*  94:115 */     return this.bitmapFactory;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setBitmapFactory(BitmapFactory bitmapFactory)
/*  98:    */   {
/*  99:120 */     this.bitmapFactory = bitmapFactory;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Priority getPriority()
/* 103:    */   {
/* 104:125 */     return this.priority;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setPriority(Priority priority)
/* 108:    */   {
/* 109:130 */     this.priority = priority;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String toString()
/* 113:    */   {
/* 114:136 */     return (isShowOriginal() ? "" : this.bitmapMaxSize.toString()) + (this.bitmapFactory == null ? "" : this.bitmapFactory.getClass().getName());
/* 115:    */   }
/* 116:    */   
/* 117:    */   public BitmapDisplayConfig cloneNew()
/* 118:    */   {
/* 119:141 */     BitmapDisplayConfig config = new BitmapDisplayConfig();
/* 120:142 */     config.bitmapMaxSize = this.bitmapMaxSize;
/* 121:143 */     config.animation = this.animation;
/* 122:144 */     config.loadingDrawable = this.loadingDrawable;
/* 123:145 */     config.loadFailedDrawable = this.loadFailedDrawable;
/* 124:146 */     config.autoRotation = this.autoRotation;
/* 125:147 */     config.showOriginal = this.showOriginal;
/* 126:148 */     config.bitmapConfig = this.bitmapConfig;
/* 127:149 */     config.bitmapFactory = this.bitmapFactory;
/* 128:150 */     config.priority = this.priority;
/* 129:151 */     return config;
/* 130:    */   }
/* 131:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.BitmapDisplayConfig
 * JD-Core Version:    0.7.0.1
 */