package com.lidroid.xutils.bitmap.factory;

import android.graphics.Bitmap;

public abstract interface BitmapFactory
{
  public abstract BitmapFactory cloneNew();
  
  public abstract Bitmap createBitmap(Bitmap paramBitmap);
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.factory.BitmapFactory
 * JD-Core Version:    0.7.0.1
 */