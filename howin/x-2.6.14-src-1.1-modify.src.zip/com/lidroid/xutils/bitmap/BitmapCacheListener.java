package com.lidroid.xutils.bitmap;

public abstract interface BitmapCacheListener
{
  public abstract void onInitMemoryCacheFinished();
  
  public abstract void onInitDiskFinished();
  
  public abstract void onClearCacheFinished();
  
  public abstract void onClearMemoryCacheFinished();
  
  public abstract void onClearDiskCacheFinished();
  
  public abstract void onClearCacheFinished(String paramString);
  
  public abstract void onClearMemoryCacheFinished(String paramString);
  
  public abstract void onClearDiskCacheFinished(String paramString);
  
  public abstract void onFlushCacheFinished();
  
  public abstract void onCloseCacheFinished();
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.BitmapCacheListener
 * JD-Core Version:    0.7.0.1
 */