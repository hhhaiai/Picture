/*   1:    */ package com.lidroid.xutils.bitmap;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.res.Resources;
/*   5:    */ import android.util.DisplayMetrics;
/*   6:    */ import android.view.View;
/*   7:    */ import android.view.ViewGroup.LayoutParams;
/*   8:    */ import android.widget.ImageView;
/*   9:    */ import com.lidroid.xutils.bitmap.core.BitmapSize;
/*  10:    */ import java.lang.reflect.Field;
/*  11:    */ 
/*  12:    */ public class BitmapCommonUtils
/*  13:    */ {
/*  14: 34 */   private static BitmapSize screenSize = null;
/*  15:    */   
/*  16:    */   public static BitmapSize getScreenSize(Context context)
/*  17:    */   {
/*  18: 38 */     if (screenSize == null)
/*  19:    */     {
/*  20: 40 */       DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
/*  21: 41 */       screenSize = new BitmapSize(displayMetrics.widthPixels, displayMetrics.heightPixels);
/*  22:    */     }
/*  23: 43 */     return screenSize;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static BitmapSize optimizeMaxSizeByView(View view, int maxImageWidth, int maxImageHeight)
/*  27:    */   {
/*  28: 48 */     int width = maxImageWidth;
/*  29: 49 */     int height = maxImageHeight;
/*  30: 51 */     if ((width > 0) && (height > 0)) {
/*  31: 53 */       return new BitmapSize(width, height);
/*  32:    */     }
/*  33: 56 */     ViewGroup.LayoutParams params = view.getLayoutParams();
/*  34: 57 */     if (params != null)
/*  35:    */     {
/*  36: 59 */       if (params.width > 0) {
/*  37: 61 */         width = params.width;
/*  38: 62 */       } else if (params.width != -2) {
/*  39: 64 */         width = view.getWidth();
/*  40:    */       }
/*  41: 67 */       if (params.height > 0) {
/*  42: 69 */         height = params.height;
/*  43: 70 */       } else if (params.height != -2) {
/*  44: 72 */         height = view.getHeight();
/*  45:    */       }
/*  46:    */     }
/*  47: 76 */     if (width <= 0) {
/*  48: 77 */       width = getImageViewFieldValue(view, "mMaxWidth");
/*  49:    */     }
/*  50: 78 */     if (height <= 0) {
/*  51: 79 */       height = getImageViewFieldValue(view, "mMaxHeight");
/*  52:    */     }
/*  53: 81 */     BitmapSize screenSize = getScreenSize(view.getContext());
/*  54: 82 */     if (width <= 0) {
/*  55: 83 */       width = screenSize.getWidth();
/*  56:    */     }
/*  57: 84 */     if (height <= 0) {
/*  58: 85 */       height = screenSize.getHeight();
/*  59:    */     }
/*  60: 87 */     return new BitmapSize(width, height);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private static int getImageViewFieldValue(Object object, String fieldName)
/*  64:    */   {
/*  65: 92 */     int value = 0;
/*  66: 93 */     if ((object instanceof ImageView)) {
/*  67:    */       try
/*  68:    */       {
/*  69: 97 */         Field field = ImageView.class.getDeclaredField(fieldName);
/*  70: 98 */         field.setAccessible(true);
/*  71: 99 */         int fieldValue = ((Integer)field.get(object)).intValue();
/*  72:100 */         if ((fieldValue > 0) && (fieldValue < 2147483647)) {
/*  73:102 */           value = fieldValue;
/*  74:    */         }
/*  75:    */       }
/*  76:    */       catch (Throwable localThrowable) {}
/*  77:    */     }
/*  78:108 */     return value;
/*  79:    */   }
/*  80:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.BitmapCommonUtils
 * JD-Core Version:    0.7.0.1
 */