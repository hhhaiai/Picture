/*   1:    */ package com.lidroid.xutils.bitmap;
/*   2:    */ 
/*   3:    */ import android.app.ActivityManager;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.text.TextUtils;
/*   6:    */ import com.lidroid.xutils.bitmap.core.BitmapCache;
/*   7:    */ import com.lidroid.xutils.bitmap.download.DefaultDownloader;
/*   8:    */ import com.lidroid.xutils.bitmap.download.Downloader;
/*   9:    */ import com.lidroid.xutils.cache.FileNameGenerator;
/*  10:    */ import com.lidroid.xutils.task.Priority;
/*  11:    */ import com.lidroid.xutils.task.PriorityAsyncTask;
/*  12:    */ import com.lidroid.xutils.task.PriorityExecutor;
/*  13:    */ import com.lidroid.xutils.util.LogUtils;
/*  14:    */ import com.lidroid.xutils.util.OtherUtils;
/*  15:    */ import java.util.HashMap;
/*  16:    */ 
/*  17:    */ public class BitmapGlobalConfig
/*  18:    */ {
/*  19:    */   private String diskCachePath;
/*  20:    */   public static final int MIN_MEMORY_CACHE_SIZE = 2097152;
/*  21: 41 */   private int memoryCacheSize = 4194304;
/*  22:    */   public static final int MIN_DISK_CACHE_SIZE = 10485760;
/*  23: 43 */   private int diskCacheSize = 52428800;
/*  24: 45 */   private boolean memoryCacheEnabled = true;
/*  25: 46 */   private boolean diskCacheEnabled = true;
/*  26:    */   private Downloader downloader;
/*  27:    */   private BitmapCache bitmapCache;
/*  28:    */   private static final int DEFAULT_POOL_SIZE = 5;
/*  29: 52 */   private static final PriorityExecutor BITMAP_LOAD_EXECUTOR = new PriorityExecutor(5);
/*  30: 53 */   private static final PriorityExecutor DISK_CACHE_EXECUTOR = new PriorityExecutor(2);
/*  31: 55 */   private long defaultCacheExpiry = 2592000000L;
/*  32: 56 */   private int defaultConnectTimeout = 15000;
/*  33: 57 */   private int defaultReadTimeout = 15000;
/*  34:    */   private FileNameGenerator fileNameGenerator;
/*  35:    */   private BitmapCacheListener bitmapCacheListener;
/*  36:    */   private Context mContext;
/*  37: 64 */   private static final HashMap<String, BitmapGlobalConfig> configMap = new HashMap(1);
/*  38:    */   
/*  39:    */   private BitmapGlobalConfig(Context context, String diskCachePath)
/*  40:    */   {
/*  41: 73 */     if (context == null) {
/*  42: 74 */       throw new IllegalArgumentException("context may not be null");
/*  43:    */     }
/*  44: 75 */     this.mContext = context;
/*  45: 76 */     this.diskCachePath = diskCachePath;
/*  46: 77 */     initBitmapCache();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static synchronized BitmapGlobalConfig getInstance(Context context, String diskCachePath)
/*  50:    */   {
/*  51: 83 */     if (TextUtils.isEmpty(diskCachePath)) {
/*  52: 85 */       diskCachePath = OtherUtils.getDiskCacheDir(context, "xBitmapCache");
/*  53:    */     }
/*  54: 88 */     if (configMap.containsKey(diskCachePath)) {
/*  55: 90 */       return (BitmapGlobalConfig)configMap.get(diskCachePath);
/*  56:    */     }
/*  57: 93 */     BitmapGlobalConfig config = new BitmapGlobalConfig(context, diskCachePath);
/*  58: 94 */     configMap.put(diskCachePath, config);
/*  59: 95 */     return config;
/*  60:    */   }
/*  61:    */   
/*  62:    */   private void initBitmapCache()
/*  63:    */   {
/*  64:101 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(0) });
/*  65:102 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(1) });
/*  66:    */   }
/*  67:    */   
/*  68:    */   public String getDiskCachePath()
/*  69:    */   {
/*  70:107 */     return this.diskCachePath;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Downloader getDownloader()
/*  74:    */   {
/*  75:112 */     if (this.downloader == null) {
/*  76:114 */       this.downloader = new DefaultDownloader();
/*  77:    */     }
/*  78:116 */     this.downloader.setContext(this.mContext);
/*  79:117 */     this.downloader.setDefaultExpiry(getDefaultCacheExpiry());
/*  80:118 */     this.downloader.setDefaultConnectTimeout(getDefaultConnectTimeout());
/*  81:119 */     this.downloader.setDefaultReadTimeout(getDefaultReadTimeout());
/*  82:120 */     return this.downloader;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setDownloader(Downloader downloader)
/*  86:    */   {
/*  87:125 */     this.downloader = downloader;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public long getDefaultCacheExpiry()
/*  91:    */   {
/*  92:130 */     return this.defaultCacheExpiry;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setDefaultCacheExpiry(long defaultCacheExpiry)
/*  96:    */   {
/*  97:135 */     this.defaultCacheExpiry = defaultCacheExpiry;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int getDefaultConnectTimeout()
/* 101:    */   {
/* 102:140 */     return this.defaultConnectTimeout;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setDefaultConnectTimeout(int defaultConnectTimeout)
/* 106:    */   {
/* 107:145 */     this.defaultConnectTimeout = defaultConnectTimeout;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public int getDefaultReadTimeout()
/* 111:    */   {
/* 112:150 */     return this.defaultReadTimeout;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setDefaultReadTimeout(int defaultReadTimeout)
/* 116:    */   {
/* 117:155 */     this.defaultReadTimeout = defaultReadTimeout;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public BitmapCache getBitmapCache()
/* 121:    */   {
/* 122:160 */     if (this.bitmapCache == null) {
/* 123:162 */       this.bitmapCache = new BitmapCache(this);
/* 124:    */     }
/* 125:164 */     return this.bitmapCache;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public int getMemoryCacheSize()
/* 129:    */   {
/* 130:169 */     return this.memoryCacheSize;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setMemoryCacheSize(int memoryCacheSize)
/* 134:    */   {
/* 135:174 */     if (memoryCacheSize >= 2097152)
/* 136:    */     {
/* 137:176 */       this.memoryCacheSize = memoryCacheSize;
/* 138:177 */       if (this.bitmapCache != null) {
/* 139:179 */         this.bitmapCache.setMemoryCacheSize(this.memoryCacheSize);
/* 140:    */       }
/* 141:    */     }
/* 142:    */     else
/* 143:    */     {
/* 144:183 */       setMemCacheSizePercent(0.3F);
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void setMemCacheSizePercent(float percent)
/* 149:    */   {
/* 150:193 */     if ((percent < 0.05F) || (percent > 0.8F)) {
/* 151:195 */       throw new IllegalArgumentException("percent must be between 0.05 and 0.8 (inclusive)");
/* 152:    */     }
/* 153:197 */     this.memoryCacheSize = Math.round(percent * getMemoryClass() * 1024.0F * 1024.0F);
/* 154:198 */     if (this.bitmapCache != null) {
/* 155:200 */       this.bitmapCache.setMemoryCacheSize(this.memoryCacheSize);
/* 156:    */     }
/* 157:    */   }
/* 158:    */   
/* 159:    */   public int getDiskCacheSize()
/* 160:    */   {
/* 161:206 */     return this.diskCacheSize;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setDiskCacheSize(int diskCacheSize)
/* 165:    */   {
/* 166:211 */     if (diskCacheSize >= 10485760)
/* 167:    */     {
/* 168:213 */       this.diskCacheSize = diskCacheSize;
/* 169:214 */       if (this.bitmapCache != null) {
/* 170:216 */         this.bitmapCache.setDiskCacheSize(this.diskCacheSize);
/* 171:    */       }
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public int getThreadPoolSize()
/* 176:    */   {
/* 177:223 */     return BITMAP_LOAD_EXECUTOR.getPoolSize();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setThreadPoolSize(int threadPoolSize)
/* 181:    */   {
/* 182:228 */     BITMAP_LOAD_EXECUTOR.setPoolSize(threadPoolSize);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public PriorityExecutor getBitmapLoadExecutor()
/* 186:    */   {
/* 187:233 */     return BITMAP_LOAD_EXECUTOR;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public PriorityExecutor getDiskCacheExecutor()
/* 191:    */   {
/* 192:238 */     return DISK_CACHE_EXECUTOR;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public boolean isMemoryCacheEnabled()
/* 196:    */   {
/* 197:243 */     return this.memoryCacheEnabled;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void setMemoryCacheEnabled(boolean memoryCacheEnabled)
/* 201:    */   {
/* 202:248 */     this.memoryCacheEnabled = memoryCacheEnabled;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean isDiskCacheEnabled()
/* 206:    */   {
/* 207:253 */     return this.diskCacheEnabled;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void setDiskCacheEnabled(boolean diskCacheEnabled)
/* 211:    */   {
/* 212:258 */     this.diskCacheEnabled = diskCacheEnabled;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public FileNameGenerator getFileNameGenerator()
/* 216:    */   {
/* 217:263 */     return this.fileNameGenerator;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setFileNameGenerator(FileNameGenerator fileNameGenerator)
/* 221:    */   {
/* 222:268 */     this.fileNameGenerator = fileNameGenerator;
/* 223:269 */     if (this.bitmapCache != null) {
/* 224:271 */       this.bitmapCache.setDiskCacheFileNameGenerator(fileNameGenerator);
/* 225:    */     }
/* 226:    */   }
/* 227:    */   
/* 228:    */   public BitmapCacheListener getBitmapCacheListener()
/* 229:    */   {
/* 230:277 */     return this.bitmapCacheListener;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void setBitmapCacheListener(BitmapCacheListener bitmapCacheListener)
/* 234:    */   {
/* 235:282 */     this.bitmapCacheListener = bitmapCacheListener;
/* 236:    */   }
/* 237:    */   
/* 238:    */   private int getMemoryClass()
/* 239:    */   {
/* 240:287 */     return ((ActivityManager)this.mContext.getSystemService("activity")).getMemoryClass();
/* 241:    */   }
/* 242:    */   
/* 243:    */   private class BitmapCacheManagementTask
/* 244:    */     extends PriorityAsyncTask<Object, Void, Object[]>
/* 245:    */   {
/* 246:    */     public static final int MESSAGE_INIT_MEMORY_CACHE = 0;
/* 247:    */     public static final int MESSAGE_INIT_DISK_CACHE = 1;
/* 248:    */     public static final int MESSAGE_FLUSH = 2;
/* 249:    */     public static final int MESSAGE_CLOSE = 3;
/* 250:    */     public static final int MESSAGE_CLEAR = 4;
/* 251:    */     public static final int MESSAGE_CLEAR_MEMORY = 5;
/* 252:    */     public static final int MESSAGE_CLEAR_DISK = 6;
/* 253:    */     public static final int MESSAGE_CLEAR_BY_KEY = 7;
/* 254:    */     public static final int MESSAGE_CLEAR_MEMORY_BY_KEY = 8;
/* 255:    */     public static final int MESSAGE_CLEAR_DISK_BY_KEY = 9;
/* 256:    */     
/* 257:    */     private BitmapCacheManagementTask()
/* 258:    */     {
/* 259:307 */       setPriority(Priority.UI_TOP);
/* 260:    */     }
/* 261:    */     
/* 262:    */     protected Object[] doInBackground(Object... params)
/* 263:    */     {
/* 264:313 */       if ((params == null) || (params.length == 0)) {
/* 265:314 */         return params;
/* 266:    */       }
/* 267:315 */       BitmapCache cache = BitmapGlobalConfig.this.getBitmapCache();
/* 268:316 */       if (cache == null) {
/* 269:317 */         return params;
/* 270:    */       }
/* 271:    */       try
/* 272:    */       {
/* 273:320 */         switch (((Integer)params[0]).intValue())
/* 274:    */         {
/* 275:    */         case 0: 
/* 276:323 */           cache.initMemoryCache();
/* 277:324 */           break;
/* 278:    */         case 1: 
/* 279:326 */           cache.initDiskCache();
/* 280:327 */           break;
/* 281:    */         case 2: 
/* 282:329 */           cache.flush();
/* 283:330 */           break;
/* 284:    */         case 3: 
/* 285:332 */           cache.clearMemoryCache();
/* 286:333 */           cache.close();
/* 287:334 */           break;
/* 288:    */         case 4: 
/* 289:336 */           cache.clearCache();
/* 290:337 */           break;
/* 291:    */         case 5: 
/* 292:339 */           cache.clearMemoryCache();
/* 293:340 */           break;
/* 294:    */         case 6: 
/* 295:342 */           cache.clearDiskCache();
/* 296:343 */           break;
/* 297:    */         case 7: 
/* 298:345 */           if (params.length != 2) {
/* 299:346 */             return params;
/* 300:    */           }
/* 301:347 */           cache.clearCache(String.valueOf(params[1]));
/* 302:348 */           break;
/* 303:    */         case 8: 
/* 304:350 */           if (params.length != 2) {
/* 305:351 */             return params;
/* 306:    */           }
/* 307:352 */           cache.clearMemoryCache(String.valueOf(params[1]));
/* 308:353 */           break;
/* 309:    */         case 9: 
/* 310:355 */           if (params.length != 2) {
/* 311:356 */             return params;
/* 312:    */           }
/* 313:357 */           cache.clearDiskCache(String.valueOf(params[1]));
/* 314:    */         }
/* 315:    */       }
/* 316:    */       catch (Throwable e)
/* 317:    */       {
/* 318:364 */         LogUtils.e(e.getMessage(), e);
/* 319:    */       }
/* 320:366 */       return params;
/* 321:    */     }
/* 322:    */     
/* 323:    */     protected void onPostExecute(Object[] params)
/* 324:    */     {
/* 325:372 */       if ((BitmapGlobalConfig.this.bitmapCacheListener == null) || (params == null) || (params.length == 0)) {
/* 326:373 */         return;
/* 327:    */       }
/* 328:    */       try
/* 329:    */       {
/* 330:376 */         switch (((Integer)params[0]).intValue())
/* 331:    */         {
/* 332:    */         case 0: 
/* 333:379 */           BitmapGlobalConfig.this.bitmapCacheListener.onInitMemoryCacheFinished();
/* 334:380 */           break;
/* 335:    */         case 1: 
/* 336:382 */           BitmapGlobalConfig.this.bitmapCacheListener.onInitDiskFinished();
/* 337:383 */           break;
/* 338:    */         case 2: 
/* 339:385 */           BitmapGlobalConfig.this.bitmapCacheListener.onFlushCacheFinished();
/* 340:386 */           break;
/* 341:    */         case 3: 
/* 342:388 */           BitmapGlobalConfig.this.bitmapCacheListener.onCloseCacheFinished();
/* 343:389 */           break;
/* 344:    */         case 4: 
/* 345:391 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearCacheFinished();
/* 346:392 */           break;
/* 347:    */         case 5: 
/* 348:394 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearMemoryCacheFinished();
/* 349:395 */           break;
/* 350:    */         case 6: 
/* 351:397 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearDiskCacheFinished();
/* 352:398 */           break;
/* 353:    */         case 7: 
/* 354:400 */           if (params.length != 2) {
/* 355:401 */             return;
/* 356:    */           }
/* 357:402 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearCacheFinished(String.valueOf(params[1]));
/* 358:403 */           break;
/* 359:    */         case 8: 
/* 360:405 */           if (params.length != 2) {
/* 361:406 */             return;
/* 362:    */           }
/* 363:407 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearMemoryCacheFinished(String.valueOf(params[1]));
/* 364:408 */           break;
/* 365:    */         case 9: 
/* 366:410 */           if (params.length != 2) {
/* 367:411 */             return;
/* 368:    */           }
/* 369:412 */           BitmapGlobalConfig.this.bitmapCacheListener.onClearDiskCacheFinished(String.valueOf(params[1]));
/* 370:    */         }
/* 371:    */       }
/* 372:    */       catch (Throwable e)
/* 373:    */       {
/* 374:419 */         LogUtils.e(e.getMessage(), e);
/* 375:    */       }
/* 376:    */     }
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void clearCache()
/* 380:    */   {
/* 381:426 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(4) });
/* 382:    */   }
/* 383:    */   
/* 384:    */   public void clearMemoryCache()
/* 385:    */   {
/* 386:431 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(5) });
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void clearDiskCache()
/* 390:    */   {
/* 391:436 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(6) });
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void clearCache(String uri)
/* 395:    */   {
/* 396:441 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(7), uri });
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void clearMemoryCache(String uri)
/* 400:    */   {
/* 401:446 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(8), uri });
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void clearDiskCache(String uri)
/* 405:    */   {
/* 406:451 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(9), uri });
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void flushCache()
/* 410:    */   {
/* 411:456 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(2) });
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void closeCache()
/* 415:    */   {
/* 416:461 */     new BitmapCacheManagementTask(null).execute(new Object[] { Integer.valueOf(3) });
/* 417:    */   }
/* 418:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.bitmap.BitmapGlobalConfig
 * JD-Core Version:    0.7.0.1
 */