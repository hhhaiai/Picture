package com.lidroid.xutils.task;

public abstract interface TaskHandler
{
  public abstract boolean supportPause();
  
  public abstract boolean supportResume();
  
  public abstract boolean supportCancel();
  
  public abstract void pause();
  
  public abstract void resume();
  
  public abstract void cancel();
  
  public abstract boolean isPaused();
  
  public abstract boolean isCancelled();
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.TaskHandler
 * JD-Core Version:    0.7.0.1
 */