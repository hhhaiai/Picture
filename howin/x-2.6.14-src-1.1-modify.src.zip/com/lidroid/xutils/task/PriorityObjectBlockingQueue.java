/*   1:    */ package com.lidroid.xutils.task;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.ObjectInputStream;
/*   5:    */ import java.io.ObjectOutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.lang.reflect.Array;
/*   8:    */ import java.util.AbstractQueue;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.NoSuchElementException;
/*  12:    */ import java.util.concurrent.BlockingQueue;
/*  13:    */ import java.util.concurrent.TimeUnit;
/*  14:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  15:    */ import java.util.concurrent.locks.Condition;
/*  16:    */ import java.util.concurrent.locks.ReentrantLock;
/*  17:    */ 
/*  18:    */ public class PriorityObjectBlockingQueue<E>
/*  19:    */   extends AbstractQueue<E>
/*  20:    */   implements BlockingQueue<E>, Serializable
/*  21:    */ {
/*  22:    */   private static final long serialVersionUID = -6903933977591709194L;
/*  23:    */   private final int capacity;
/*  24: 31 */   private final AtomicInteger count = new AtomicInteger();
/*  25:    */   transient Node<E> head;
/*  26:    */   private transient Node<E> last;
/*  27: 46 */   private final ReentrantLock takeLock = new ReentrantLock();
/*  28: 51 */   private final Condition notEmpty = this.takeLock.newCondition();
/*  29: 56 */   private final ReentrantLock putLock = new ReentrantLock();
/*  30: 61 */   private final Condition notFull = this.putLock.newCondition();
/*  31:    */   
/*  32:    */   private void signalNotEmpty()
/*  33:    */   {
/*  34: 69 */     ReentrantLock takeLock = this.takeLock;
/*  35: 70 */     takeLock.lock();
/*  36:    */     try
/*  37:    */     {
/*  38: 73 */       this.notEmpty.signal();
/*  39:    */     }
/*  40:    */     finally
/*  41:    */     {
/*  42: 76 */       takeLock.unlock();
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   private void signalNotFull()
/*  47:    */   {
/*  48: 85 */     ReentrantLock putLock = this.putLock;
/*  49: 86 */     putLock.lock();
/*  50:    */     try
/*  51:    */     {
/*  52: 89 */       this.notFull.signal();
/*  53:    */     }
/*  54:    */     finally
/*  55:    */     {
/*  56: 92 */       putLock.unlock();
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   private synchronized E opQueue(Node<E> node)
/*  61:    */   {
/*  62: 98 */     if (node == null) {
/*  63:100 */       return _dequeue();
/*  64:    */     }
/*  65:103 */     _enqueue(node);
/*  66:104 */     return null;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private void _enqueue(Node<E> node)
/*  70:    */   {
/*  71:111 */     boolean added = false;
/*  72:    */     
/*  73:113 */     Node<E> curr = this.head;
/*  74:114 */     Node<E> temp = null;
/*  75:116 */     while (curr.next != null)
/*  76:    */     {
/*  77:118 */       temp = curr.next;
/*  78:119 */       if (temp.getPriority().ordinal() > node.getPriority().ordinal())
/*  79:    */       {
/*  80:121 */         curr.next = node;
/*  81:122 */         node.next = temp;
/*  82:123 */         added = true;
/*  83:124 */         break;
/*  84:    */       }
/*  85:126 */       curr = curr.next;
/*  86:    */     }
/*  87:129 */     if (!added) {
/*  88:131 */       this.last = (this.last.next = node);
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   private E _dequeue()
/*  93:    */   {
/*  94:140 */     Node<E> h = this.head;
/*  95:141 */     Node<E> first = h.next;
/*  96:142 */     h.next = h;
/*  97:143 */     this.head = first;
/*  98:144 */     E x = first.getValue();
/*  99:145 */     first.setValue(null);
/* 100:146 */     return x;
/* 101:    */   }
/* 102:    */   
/* 103:    */   void fullyLock()
/* 104:    */   {
/* 105:154 */     this.putLock.lock();
/* 106:155 */     this.takeLock.lock();
/* 107:    */   }
/* 108:    */   
/* 109:    */   void fullyUnlock()
/* 110:    */   {
/* 111:163 */     this.takeLock.unlock();
/* 112:164 */     this.putLock.unlock();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public PriorityObjectBlockingQueue()
/* 116:    */   {
/* 117:169 */     this(2147483647);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public PriorityObjectBlockingQueue(int capacity)
/* 121:    */   {
/* 122:174 */     if (capacity <= 0) {
/* 123:175 */       throw new IllegalArgumentException();
/* 124:    */     }
/* 125:176 */     this.capacity = capacity;
/* 126:177 */     this.last = (this.head = new Node(null));
/* 127:    */   }
/* 128:    */   
/* 129:    */   public PriorityObjectBlockingQueue(Collection<? extends E> c)
/* 130:    */   {
/* 131:182 */     this(2147483647);
/* 132:183 */     ReentrantLock putLock = this.putLock;
/* 133:184 */     putLock.lock();
/* 134:    */     try
/* 135:    */     {
/* 136:187 */       int n = 0;
/* 137:188 */       for (E e : c)
/* 138:    */       {
/* 139:190 */         if (e == null) {
/* 140:191 */           throw new NullPointerException();
/* 141:    */         }
/* 142:192 */         if (n == this.capacity) {
/* 143:193 */           throw new IllegalStateException("Queue full");
/* 144:    */         }
/* 145:194 */         opQueue(new Node(e));
/* 146:195 */         n++;
/* 147:    */       }
/* 148:197 */       this.count.set(n);
/* 149:    */     }
/* 150:    */     finally
/* 151:    */     {
/* 152:200 */       putLock.unlock();
/* 153:    */     }
/* 154:    */   }
/* 155:    */   
/* 156:    */   public int size()
/* 157:    */   {
/* 158:206 */     return this.count.get();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public int remainingCapacity()
/* 162:    */   {
/* 163:211 */     return this.capacity - this.count.get();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public void put(E e)
/* 167:    */     throws InterruptedException
/* 168:    */   {
/* 169:216 */     if (e == null) {
/* 170:217 */       throw new NullPointerException();
/* 171:    */     }
/* 172:220 */     int c = -1;
/* 173:221 */     Node<E> node = new Node(e);
/* 174:222 */     ReentrantLock putLock = this.putLock;
/* 175:223 */     AtomicInteger count = this.count;
/* 176:224 */     putLock.lockInterruptibly();
/* 177:    */     try
/* 178:    */     {
/* 179:227 */       while (count.get() == this.capacity) {
/* 180:229 */         this.notFull.await();
/* 181:    */       }
/* 182:231 */       opQueue(node);
/* 183:232 */       c = count.getAndIncrement();
/* 184:233 */       if (c + 1 < this.capacity) {
/* 185:234 */         this.notFull.signal();
/* 186:    */       }
/* 187:    */     }
/* 188:    */     finally
/* 189:    */     {
/* 190:237 */       putLock.unlock();
/* 191:    */     }
/* 192:239 */     if (c == 0) {
/* 193:240 */       signalNotEmpty();
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   public boolean offer(E e, long timeout, TimeUnit unit)
/* 198:    */     throws InterruptedException
/* 199:    */   {
/* 200:246 */     if (e == null) {
/* 201:247 */       throw new NullPointerException();
/* 202:    */     }
/* 203:248 */     long nanos = unit.toNanos(timeout);
/* 204:249 */     int c = -1;
/* 205:250 */     ReentrantLock putLock = this.putLock;
/* 206:251 */     AtomicInteger count = this.count;
/* 207:252 */     putLock.lockInterruptibly();
/* 208:    */     try
/* 209:    */     {
/* 210:255 */       while (count.get() == this.capacity)
/* 211:    */       {
/* 212:257 */         if (nanos <= 0L) {
/* 213:258 */           return false;
/* 214:    */         }
/* 215:259 */         nanos = this.notFull.awaitNanos(nanos);
/* 216:    */       }
/* 217:261 */       opQueue(new Node(e));
/* 218:262 */       c = count.getAndIncrement();
/* 219:263 */       if (c + 1 < this.capacity) {
/* 220:264 */         this.notFull.signal();
/* 221:    */       }
/* 222:    */     }
/* 223:    */     finally
/* 224:    */     {
/* 225:267 */       putLock.unlock();
/* 226:    */     }
/* 227:267 */     putLock.unlock();
/* 228:269 */     if (c == 0) {
/* 229:270 */       signalNotEmpty();
/* 230:    */     }
/* 231:271 */     return true;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public boolean offer(E e)
/* 235:    */   {
/* 236:276 */     if (e == null) {
/* 237:277 */       throw new NullPointerException();
/* 238:    */     }
/* 239:278 */     AtomicInteger count = this.count;
/* 240:279 */     if (count.get() == this.capacity) {
/* 241:280 */       return false;
/* 242:    */     }
/* 243:281 */     int c = -1;
/* 244:282 */     Node<E> node = new Node(e);
/* 245:283 */     ReentrantLock putLock = this.putLock;
/* 246:284 */     putLock.lock();
/* 247:    */     try
/* 248:    */     {
/* 249:287 */       if (count.get() < this.capacity)
/* 250:    */       {
/* 251:289 */         opQueue(node);
/* 252:290 */         c = count.getAndIncrement();
/* 253:291 */         if (c + 1 < this.capacity) {
/* 254:292 */           this.notFull.signal();
/* 255:    */         }
/* 256:    */       }
/* 257:    */     }
/* 258:    */     finally
/* 259:    */     {
/* 260:296 */       putLock.unlock();
/* 261:    */     }
/* 262:298 */     if (c == 0) {
/* 263:299 */       signalNotEmpty();
/* 264:    */     }
/* 265:300 */     return c >= 0;
/* 266:    */   }
/* 267:    */   
/* 268:    */   public E take()
/* 269:    */     throws InterruptedException
/* 270:    */   {
/* 271:306 */     int c = -1;
/* 272:307 */     AtomicInteger count = this.count;
/* 273:308 */     ReentrantLock takeLock = this.takeLock;
/* 274:309 */     takeLock.lockInterruptibly();
/* 275:    */     E x;
/* 276:    */     try
/* 277:    */     {
/* 278:312 */       while (count.get() == 0) {
/* 279:314 */         this.notEmpty.await();
/* 280:    */       }
/* 281:316 */       E x = opQueue(null);
/* 282:317 */       c = count.getAndDecrement();
/* 283:318 */       if (c > 1) {
/* 284:319 */         this.notEmpty.signal();
/* 285:    */       }
/* 286:    */     }
/* 287:    */     finally
/* 288:    */     {
/* 289:322 */       takeLock.unlock();
/* 290:    */     }
/* 291:324 */     if (c == this.capacity) {
/* 292:325 */       signalNotFull();
/* 293:    */     }
/* 294:326 */     return x;
/* 295:    */   }
/* 296:    */   
/* 297:    */   public E poll(long timeout, TimeUnit unit)
/* 298:    */     throws InterruptedException
/* 299:    */   {
/* 300:331 */     E x = null;
/* 301:332 */     int c = -1;
/* 302:333 */     long nanos = unit.toNanos(timeout);
/* 303:334 */     AtomicInteger count = this.count;
/* 304:335 */     ReentrantLock takeLock = this.takeLock;
/* 305:336 */     takeLock.lockInterruptibly();
/* 306:    */     try
/* 307:    */     {
/* 308:339 */       while (count.get() == 0)
/* 309:    */       {
/* 310:341 */         if (nanos <= 0L) {
/* 311:342 */           return null;
/* 312:    */         }
/* 313:343 */         nanos = this.notEmpty.awaitNanos(nanos);
/* 314:    */       }
/* 315:345 */       x = opQueue(null);
/* 316:346 */       c = count.getAndDecrement();
/* 317:347 */       if (c > 1) {
/* 318:348 */         this.notEmpty.signal();
/* 319:    */       }
/* 320:    */     }
/* 321:    */     finally
/* 322:    */     {
/* 323:351 */       takeLock.unlock();
/* 324:    */     }
/* 325:351 */     takeLock.unlock();
/* 326:353 */     if (c == this.capacity) {
/* 327:354 */       signalNotFull();
/* 328:    */     }
/* 329:355 */     return x;
/* 330:    */   }
/* 331:    */   
/* 332:    */   public E poll()
/* 333:    */   {
/* 334:360 */     AtomicInteger count = this.count;
/* 335:361 */     if (count.get() == 0) {
/* 336:362 */       return null;
/* 337:    */     }
/* 338:363 */     E x = null;
/* 339:364 */     int c = -1;
/* 340:365 */     ReentrantLock takeLock = this.takeLock;
/* 341:366 */     takeLock.lock();
/* 342:    */     label74:
/* 343:    */     try
/* 344:    */     {
/* 345:369 */       if (count.get() > 0)
/* 346:    */       {
/* 347:371 */         x = opQueue(null);
/* 348:372 */         c = count.getAndDecrement();
/* 349:373 */         if (c <= 1) {
/* 350:    */           break label74;
/* 351:    */         }
/* 352:374 */         this.notEmpty.signal();
/* 353:    */       }
/* 354:    */     }
/* 355:    */     finally
/* 356:    */     {
/* 357:378 */       takeLock.unlock();
/* 358:    */     }
/* 359:380 */     if (c == this.capacity) {
/* 360:381 */       signalNotFull();
/* 361:    */     }
/* 362:382 */     return x;
/* 363:    */   }
/* 364:    */   
/* 365:    */   public E peek()
/* 366:    */   {
/* 367:387 */     if (this.count.get() == 0) {
/* 368:388 */       return null;
/* 369:    */     }
/* 370:389 */     ReentrantLock takeLock = this.takeLock;
/* 371:390 */     takeLock.lock();
/* 372:    */     try
/* 373:    */     {
/* 374:393 */       Node<E> first = this.head.next;
/* 375:394 */       if (first == null) {
/* 376:395 */         return null;
/* 377:    */       }
/* 378:397 */       return first.getValue();
/* 379:    */     }
/* 380:    */     finally
/* 381:    */     {
/* 382:400 */       takeLock.unlock();
/* 383:    */     }
/* 384:    */   }
/* 385:    */   
/* 386:    */   void unlink(Node<E> p, Node<E> trail)
/* 387:    */   {
/* 388:412 */     p.setValue(null);
/* 389:413 */     trail.next = p.next;
/* 390:414 */     if (this.last == p) {
/* 391:415 */       this.last = trail;
/* 392:    */     }
/* 393:416 */     if (this.count.getAndDecrement() == this.capacity) {
/* 394:417 */       this.notFull.signal();
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   public boolean remove(Object o)
/* 399:    */   {
/* 400:422 */     if (o == null) {
/* 401:423 */       return false;
/* 402:    */     }
/* 403:424 */     fullyLock();
/* 404:    */     try
/* 405:    */     {
/* 406:427 */       Node<E> trail = this.head;
/* 407:427 */       for (Node<E> p = trail.next; p != null; p = p.next)
/* 408:    */       {
/* 409:429 */         if (o.equals(p.getValue()))
/* 410:    */         {
/* 411:431 */           unlink(p, trail);
/* 412:432 */           return true;
/* 413:    */         }
/* 414:427 */         trail = p;
/* 415:    */       }
/* 416:435 */       return false;
/* 417:    */     }
/* 418:    */     finally
/* 419:    */     {
/* 420:438 */       fullyUnlock();
/* 421:    */     }
/* 422:    */   }
/* 423:    */   
/* 424:    */   public boolean contains(Object o)
/* 425:    */   {
/* 426:444 */     if (o == null) {
/* 427:445 */       return false;
/* 428:    */     }
/* 429:446 */     fullyLock();
/* 430:    */     try
/* 431:    */     {
/* 432:449 */       for (Node<E> p = this.head.next; p != null; p = p.next) {
/* 433:450 */         if (o.equals(p.getValue())) {
/* 434:451 */           return true;
/* 435:    */         }
/* 436:    */       }
/* 437:452 */       return false;
/* 438:    */     }
/* 439:    */     finally
/* 440:    */     {
/* 441:455 */       fullyUnlock();
/* 442:    */     }
/* 443:    */   }
/* 444:    */   
/* 445:    */   public Object[] toArray()
/* 446:    */   {
/* 447:461 */     fullyLock();
/* 448:    */     try
/* 449:    */     {
/* 450:464 */       int size = this.count.get();
/* 451:465 */       Object[] a = new Object[size];
/* 452:466 */       int k = 0;
/* 453:467 */       for (Node<E> p = this.head.next; p != null; p = p.next) {
/* 454:468 */         a[(k++)] = p.getValue();
/* 455:    */       }
/* 456:469 */       return a;
/* 457:    */     }
/* 458:    */     finally
/* 459:    */     {
/* 460:472 */       fullyUnlock();
/* 461:    */     }
/* 462:    */   }
/* 463:    */   
/* 464:    */   public <T> T[] toArray(T[] a)
/* 465:    */   {
/* 466:479 */     fullyLock();
/* 467:    */     try
/* 468:    */     {
/* 469:482 */       int size = this.count.get();
/* 470:483 */       if (a.length < size) {
/* 471:484 */         a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
/* 472:    */       }
/* 473:486 */       int k = 0;
/* 474:487 */       for (Node<T> p = this.head.next; p != null; p = p.next) {
/* 475:488 */         a[(k++)] = p.getValue();
/* 476:    */       }
/* 477:489 */       if (a.length > k) {
/* 478:490 */         a[k] = null;
/* 479:    */       }
/* 480:491 */       return a;
/* 481:    */     }
/* 482:    */     finally
/* 483:    */     {
/* 484:494 */       fullyUnlock();
/* 485:    */     }
/* 486:    */   }
/* 487:    */   
/* 488:    */   public void clear()
/* 489:    */   {
/* 490:500 */     fullyLock();
/* 491:    */     try
/* 492:    */     {
/* 493:    */       Node<E> p;
/* 494:    */       Node<E> p;
/* 495:503 */       for (Node<E> h = this.head; (p = h.next) != null; h = p)
/* 496:    */       {
/* 497:505 */         h.next = h;
/* 498:506 */         p.setValue(null);
/* 499:    */       }
/* 500:508 */       this.head = this.last;
/* 501:510 */       if (this.count.getAndSet(0) == this.capacity) {
/* 502:511 */         this.notFull.signal();
/* 503:    */       }
/* 504:    */     }
/* 505:    */     finally
/* 506:    */     {
/* 507:514 */       fullyUnlock();
/* 508:    */     }
/* 509:    */   }
/* 510:    */   
/* 511:    */   public int drainTo(Collection<? super E> c)
/* 512:    */   {
/* 513:520 */     return drainTo(c, 2147483647);
/* 514:    */   }
/* 515:    */   
/* 516:    */   /* Error */
/* 517:    */   public int drainTo(Collection<? super E> c, int maxElements)
/* 518:    */   {
/* 519:    */     // Byte code:
/* 520:    */     //   0: aload_1
/* 521:    */     //   1: ifnonnull +11 -> 12
/* 522:    */     //   4: new 152	java/lang/NullPointerException
/* 523:    */     //   7: dup
/* 524:    */     //   8: invokespecial 154	java/lang/NullPointerException:<init>	()V
/* 525:    */     //   11: athrow
/* 526:    */     //   12: aload_1
/* 527:    */     //   13: aload_0
/* 528:    */     //   14: if_acmpne +11 -> 25
/* 529:    */     //   17: new 131	java/lang/IllegalArgumentException
/* 530:    */     //   20: dup
/* 531:    */     //   21: invokespecial 133	java/lang/IllegalArgumentException:<init>	()V
/* 532:    */     //   24: athrow
/* 533:    */     //   25: iload_2
/* 534:    */     //   26: ifgt +5 -> 31
/* 535:    */     //   29: iconst_0
/* 536:    */     //   30: ireturn
/* 537:    */     //   31: iconst_0
/* 538:    */     //   32: istore_3
/* 539:    */     //   33: aload_0
/* 540:    */     //   34: getfield 32	com/lidroid/xutils/task/PriorityObjectBlockingQueue:takeLock	Ljava/util/concurrent/locks/ReentrantLock;
/* 541:    */     //   37: astore 4
/* 542:    */     //   39: aload 4
/* 543:    */     //   41: invokevirtual 34	java/util/concurrent/locks/ReentrantLock:lock	()V
/* 544:    */     //   44: iload_2
/* 545:    */     //   45: aload_0
/* 546:    */     //   46: getfield 124	com/lidroid/xutils/task/PriorityObjectBlockingQueue:count	Ljava/util/concurrent/atomic/AtomicInteger;
/* 547:    */     //   49: invokevirtual 177	java/util/concurrent/atomic/AtomicInteger:get	()I
/* 548:    */     //   52: invokestatic 279	java/lang/Math:min	(II)I
/* 549:    */     //   55: istore 5
/* 550:    */     //   57: aload_0
/* 551:    */     //   58: getfield 76	com/lidroid/xutils/task/PriorityObjectBlockingQueue:head	Lcom/lidroid/xutils/task/Node;
/* 552:    */     //   61: astore 6
/* 553:    */     //   63: iconst_0
/* 554:    */     //   64: istore 7
/* 555:    */     //   66: goto +42 -> 108
/* 556:    */     //   69: aload 6
/* 557:    */     //   71: getfield 78	com/lidroid/xutils/task/Node:next	Lcom/lidroid/xutils/task/Node;
/* 558:    */     //   74: astore 8
/* 559:    */     //   76: aload_1
/* 560:    */     //   77: aload 8
/* 561:    */     //   79: invokevirtual 100	com/lidroid/xutils/task/Node:getValue	()Ljava/lang/Object;
/* 562:    */     //   82: invokeinterface 285 2 0
/* 563:    */     //   87: pop
/* 564:    */     //   88: aload 8
/* 565:    */     //   90: aconst_null
/* 566:    */     //   91: invokevirtual 103	com/lidroid/xutils/task/Node:setValue	(Ljava/lang/Object;)V
/* 567:    */     //   94: aload 6
/* 568:    */     //   96: aload 6
/* 569:    */     //   98: putfield 78	com/lidroid/xutils/task/Node:next	Lcom/lidroid/xutils/task/Node;
/* 570:    */     //   101: aload 8
/* 571:    */     //   103: astore 6
/* 572:    */     //   105: iinc 7 1
/* 573:    */     //   108: iload 7
/* 574:    */     //   110: iload 5
/* 575:    */     //   112: if_icmplt -43 -> 69
/* 576:    */     //   115: iload 5
/* 577:    */     //   117: istore 10
/* 578:    */     //   119: iload 7
/* 579:    */     //   121: ifle +32 -> 153
/* 580:    */     //   124: aload_0
/* 581:    */     //   125: aload 6
/* 582:    */     //   127: putfield 76	com/lidroid/xutils/task/PriorityObjectBlockingQueue:head	Lcom/lidroid/xutils/task/Node;
/* 583:    */     //   130: aload_0
/* 584:    */     //   131: getfield 124	com/lidroid/xutils/task/PriorityObjectBlockingQueue:count	Ljava/util/concurrent/atomic/AtomicInteger;
/* 585:    */     //   134: iload 7
/* 586:    */     //   136: ineg
/* 587:    */     //   137: invokevirtual 288	java/util/concurrent/atomic/AtomicInteger:getAndAdd	(I)I
/* 588:    */     //   140: aload_0
/* 589:    */     //   141: getfield 134	com/lidroid/xutils/task/PriorityObjectBlockingQueue:capacity	I
/* 590:    */     //   144: if_icmpne +7 -> 151
/* 591:    */     //   147: iconst_1
/* 592:    */     //   148: goto +4 -> 152
/* 593:    */     //   151: iconst_0
/* 594:    */     //   152: istore_3
/* 595:    */     //   153: aload 4
/* 596:    */     //   155: invokevirtual 46	java/util/concurrent/locks/ReentrantLock:unlock	()V
/* 597:    */     //   158: iload_3
/* 598:    */     //   159: ifeq +7 -> 166
/* 599:    */     //   162: aload_0
/* 600:    */     //   163: invokespecial 219	com/lidroid/xutils/task/PriorityObjectBlockingQueue:signalNotFull	()V
/* 601:    */     //   166: iload 10
/* 602:    */     //   168: ireturn
/* 603:    */     //   169: astore 9
/* 604:    */     //   171: iload 7
/* 605:    */     //   173: ifle +32 -> 205
/* 606:    */     //   176: aload_0
/* 607:    */     //   177: aload 6
/* 608:    */     //   179: putfield 76	com/lidroid/xutils/task/PriorityObjectBlockingQueue:head	Lcom/lidroid/xutils/task/Node;
/* 609:    */     //   182: aload_0
/* 610:    */     //   183: getfield 124	com/lidroid/xutils/task/PriorityObjectBlockingQueue:count	Ljava/util/concurrent/atomic/AtomicInteger;
/* 611:    */     //   186: iload 7
/* 612:    */     //   188: ineg
/* 613:    */     //   189: invokevirtual 288	java/util/concurrent/atomic/AtomicInteger:getAndAdd	(I)I
/* 614:    */     //   192: aload_0
/* 615:    */     //   193: getfield 134	com/lidroid/xutils/task/PriorityObjectBlockingQueue:capacity	I
/* 616:    */     //   196: if_icmpne +7 -> 203
/* 617:    */     //   199: iconst_1
/* 618:    */     //   200: goto +4 -> 204
/* 619:    */     //   203: iconst_0
/* 620:    */     //   204: istore_3
/* 621:    */     //   205: aload 9
/* 622:    */     //   207: athrow
/* 623:    */     //   208: astore 11
/* 624:    */     //   210: aload 4
/* 625:    */     //   212: invokevirtual 46	java/util/concurrent/locks/ReentrantLock:unlock	()V
/* 626:    */     //   215: iload_3
/* 627:    */     //   216: ifeq +7 -> 223
/* 628:    */     //   219: aload_0
/* 629:    */     //   220: invokespecial 219	com/lidroid/xutils/task/PriorityObjectBlockingQueue:signalNotFull	()V
/* 630:    */     //   223: aload 11
/* 631:    */     //   225: athrow
/* 632:    */     // Line number table:
/* 633:    */     //   Java source line #525	-> byte code offset #0
/* 634:    */     //   Java source line #526	-> byte code offset #4
/* 635:    */     //   Java source line #527	-> byte code offset #12
/* 636:    */     //   Java source line #528	-> byte code offset #17
/* 637:    */     //   Java source line #529	-> byte code offset #25
/* 638:    */     //   Java source line #530	-> byte code offset #29
/* 639:    */     //   Java source line #531	-> byte code offset #31
/* 640:    */     //   Java source line #532	-> byte code offset #33
/* 641:    */     //   Java source line #533	-> byte code offset #39
/* 642:    */     //   Java source line #536	-> byte code offset #44
/* 643:    */     //   Java source line #538	-> byte code offset #57
/* 644:    */     //   Java source line #539	-> byte code offset #63
/* 645:    */     //   Java source line #542	-> byte code offset #66
/* 646:    */     //   Java source line #544	-> byte code offset #69
/* 647:    */     //   Java source line #545	-> byte code offset #76
/* 648:    */     //   Java source line #546	-> byte code offset #88
/* 649:    */     //   Java source line #547	-> byte code offset #94
/* 650:    */     //   Java source line #548	-> byte code offset #101
/* 651:    */     //   Java source line #549	-> byte code offset #105
/* 652:    */     //   Java source line #542	-> byte code offset #108
/* 653:    */     //   Java source line #551	-> byte code offset #115
/* 654:    */     //   Java source line #555	-> byte code offset #119
/* 655:    */     //   Java source line #558	-> byte code offset #124
/* 656:    */     //   Java source line #559	-> byte code offset #130
/* 657:    */     //   Java source line #564	-> byte code offset #153
/* 658:    */     //   Java source line #565	-> byte code offset #158
/* 659:    */     //   Java source line #566	-> byte code offset #162
/* 660:    */     //   Java source line #551	-> byte code offset #166
/* 661:    */     //   Java source line #553	-> byte code offset #169
/* 662:    */     //   Java source line #555	-> byte code offset #171
/* 663:    */     //   Java source line #558	-> byte code offset #176
/* 664:    */     //   Java source line #559	-> byte code offset #182
/* 665:    */     //   Java source line #561	-> byte code offset #205
/* 666:    */     //   Java source line #563	-> byte code offset #208
/* 667:    */     //   Java source line #564	-> byte code offset #210
/* 668:    */     //   Java source line #565	-> byte code offset #215
/* 669:    */     //   Java source line #566	-> byte code offset #219
/* 670:    */     //   Java source line #567	-> byte code offset #223
/* 671:    */     // Local variable table:
/* 672:    */     //   start	length	slot	name	signature
/* 673:    */     //   0	226	0	this	PriorityObjectBlockingQueue<E>
/* 674:    */     //   0	226	1	c	Collection<? super E>
/* 675:    */     //   0	226	2	maxElements	int
/* 676:    */     //   32	184	3	signalNotFull	boolean
/* 677:    */     //   37	174	4	takeLock	ReentrantLock
/* 678:    */     //   55	61	5	n	int
/* 679:    */     //   61	117	6	h	Node<E>
/* 680:    */     //   64	123	7	i	int
/* 681:    */     //   74	28	8	p	Node<E>
/* 682:    */     //   169	37	9	localObject1	Object
/* 683:    */     //   117	50	10	i	int
/* 684:    */     //   208	16	11	localObject2	Object
/* 685:    */     // Exception table:
/* 686:    */     //   from	to	target	type
/* 687:    */     //   66	119	169	finally
/* 688:    */     //   44	153	208	finally
/* 689:    */     //   169	208	208	finally
/* 690:    */   }
/* 691:    */   
/* 692:    */   public Iterator<E> iterator()
/* 693:    */   {
/* 694:572 */     return new Itr();
/* 695:    */   }
/* 696:    */   
/* 697:    */   private class Itr
/* 698:    */     implements Iterator<E>
/* 699:    */   {
/* 700:    */     private Node<E> current;
/* 701:    */     private Node<E> lastRet;
/* 702:    */     private E currentElement;
/* 703:    */     
/* 704:    */     Itr()
/* 705:    */     {
/* 706:584 */       PriorityObjectBlockingQueue.this.fullyLock();
/* 707:    */       try
/* 708:    */       {
/* 709:587 */         this.current = PriorityObjectBlockingQueue.this.head.next;
/* 710:588 */         if (this.current != null) {
/* 711:589 */           this.currentElement = this.current.getValue();
/* 712:    */         }
/* 713:    */       }
/* 714:    */       finally
/* 715:    */       {
/* 716:592 */         PriorityObjectBlockingQueue.this.fullyUnlock();
/* 717:    */       }
/* 718:    */     }
/* 719:    */     
/* 720:    */     public boolean hasNext()
/* 721:    */     {
/* 722:598 */       return this.current != null;
/* 723:    */     }
/* 724:    */     
/* 725:    */     private Node<E> nextNode(Node<E> p)
/* 726:    */     {
/* 727:    */       for (;;)
/* 728:    */       {
/* 729:605 */         Node<E> s = p.next;
/* 730:606 */         if (s == p) {
/* 731:607 */           return PriorityObjectBlockingQueue.this.head.next;
/* 732:    */         }
/* 733:608 */         if ((s == null) || (s.getValue() != null)) {
/* 734:609 */           return s;
/* 735:    */         }
/* 736:610 */         p = s;
/* 737:    */       }
/* 738:    */     }
/* 739:    */     
/* 740:    */     public E next()
/* 741:    */     {
/* 742:616 */       PriorityObjectBlockingQueue.this.fullyLock();
/* 743:    */       try
/* 744:    */       {
/* 745:619 */         if (this.current == null) {
/* 746:620 */           throw new NoSuchElementException();
/* 747:    */         }
/* 748:621 */         E x = this.currentElement;
/* 749:622 */         this.lastRet = this.current;
/* 750:623 */         this.current = nextNode(this.current);
/* 751:624 */         this.currentElement = (this.current == null ? null : this.current.getValue());
/* 752:625 */         return x;
/* 753:    */       }
/* 754:    */       finally
/* 755:    */       {
/* 756:628 */         PriorityObjectBlockingQueue.this.fullyUnlock();
/* 757:    */       }
/* 758:    */     }
/* 759:    */     
/* 760:    */     public void remove()
/* 761:    */     {
/* 762:634 */       if (this.lastRet == null) {
/* 763:635 */         throw new IllegalStateException();
/* 764:    */       }
/* 765:636 */       PriorityObjectBlockingQueue.this.fullyLock();
/* 766:    */       try
/* 767:    */       {
/* 768:639 */         Node<E> node = this.lastRet;
/* 769:640 */         this.lastRet = null;
/* 770:641 */         Node<E> trail = PriorityObjectBlockingQueue.this.head;
/* 771:641 */         for (Node<E> p = trail.next; p != null; p = p.next)
/* 772:    */         {
/* 773:643 */           if (p == node)
/* 774:    */           {
/* 775:645 */             PriorityObjectBlockingQueue.this.unlink(p, trail);
/* 776:646 */             break;
/* 777:    */           }
/* 778:641 */           trail = p;
/* 779:    */         }
/* 780:    */       }
/* 781:    */       finally
/* 782:    */       {
/* 783:651 */         PriorityObjectBlockingQueue.this.fullyUnlock();
/* 784:    */       }
/* 785:    */     }
/* 786:    */   }
/* 787:    */   
/* 788:    */   private void writeObject(ObjectOutputStream s)
/* 789:    */     throws IOException
/* 790:    */   {
/* 791:659 */     fullyLock();
/* 792:    */     try
/* 793:    */     {
/* 794:663 */       s.defaultWriteObject();
/* 795:666 */       for (Node<E> p = this.head.next; p != null; p = p.next) {
/* 796:667 */         s.writeObject(p.getValue());
/* 797:    */       }
/* 798:670 */       s.writeObject(null);
/* 799:    */     }
/* 800:    */     finally
/* 801:    */     {
/* 802:673 */       fullyUnlock();
/* 803:    */     }
/* 804:    */   }
/* 805:    */   
/* 806:    */   private void readObject(ObjectInputStream s)
/* 807:    */     throws IOException, ClassNotFoundException
/* 808:    */   {
/* 809:683 */     s.defaultReadObject();
/* 810:    */     
/* 811:685 */     this.count.set(0);
/* 812:686 */     this.last = (this.head = new Node(null));
/* 813:    */     for (;;)
/* 814:    */     {
/* 815:692 */       E item = s.readObject();
/* 816:693 */       if (item == null) {
/* 817:    */         break;
/* 818:    */       }
/* 819:695 */       add(item);
/* 820:    */     }
/* 821:    */   }
/* 822:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.PriorityObjectBlockingQueue
 * JD-Core Version:    0.7.0.1
 */