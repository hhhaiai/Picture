/*   1:    */ package com.lidroid.xutils.task;
/*   2:    */ 
/*   3:    */ class Node<T>
/*   4:    */ {
/*   5:705 */   private boolean valueAsT = false;
/*   6:    */   private PriorityObject<?> value;
/*   7:    */   Node<T> next;
/*   8:    */   
/*   9:    */   Node(T value)
/*  10:    */   {
/*  11:711 */     setValue(value);
/*  12:    */   }
/*  13:    */   
/*  14:    */   public Priority getPriority()
/*  15:    */   {
/*  16:716 */     return this.value.priority;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public T getValue()
/*  20:    */   {
/*  21:722 */     if (this.value == null) {
/*  22:724 */       return null;
/*  23:    */     }
/*  24:725 */     if (this.valueAsT) {
/*  25:727 */       return this.value;
/*  26:    */     }
/*  27:730 */     return this.value.obj;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setValue(T value)
/*  31:    */   {
/*  32:736 */     if (value == null)
/*  33:    */     {
/*  34:738 */       this.value = null;
/*  35:    */     }
/*  36:739 */     else if ((value instanceof PriorityObject))
/*  37:    */     {
/*  38:741 */       this.value = ((PriorityObject)value);
/*  39:742 */       this.valueAsT = true;
/*  40:    */     }
/*  41:    */     else
/*  42:    */     {
/*  43:745 */       this.value = new PriorityObject(Priority.DEFAULT, value);
/*  44:    */     }
/*  45:    */   }
/*  46:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.Node
 * JD-Core Version:    0.7.0.1
 */