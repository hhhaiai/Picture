/*  1:   */ package com.lidroid.xutils.task;
/*  2:   */ 
/*  3:   */ public class PriorityObject<E>
/*  4:   */ {
/*  5:   */   public final Priority priority;
/*  6:   */   public final E obj;
/*  7:   */   
/*  8:   */   public PriorityObject(Priority priority, E obj)
/*  9:   */   {
/* 10:14 */     this.priority = (priority == null ? Priority.DEFAULT : priority);
/* 11:15 */     this.obj = obj;
/* 12:   */   }
/* 13:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.PriorityObject
 * JD-Core Version:    0.7.0.1
 */