/*  1:   */ package com.lidroid.xutils.task;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.BlockingQueue;
/*  4:   */ import java.util.concurrent.Executor;
/*  5:   */ import java.util.concurrent.ThreadFactory;
/*  6:   */ import java.util.concurrent.ThreadPoolExecutor;
/*  7:   */ import java.util.concurrent.TimeUnit;
/*  8:   */ import java.util.concurrent.atomic.AtomicInteger;
/*  9:   */ 
/* 10:   */ public class PriorityExecutor
/* 11:   */   implements Executor
/* 12:   */ {
/* 13:   */   private static final int CORE_POOL_SIZE = 5;
/* 14:   */   private static final int MAXIMUM_POOL_SIZE = 256;
/* 15:   */   private static final int KEEP_ALIVE = 1;
/* 16:16 */   private static final ThreadFactory sThreadFactory = new ThreadFactory()
/* 17:   */   {
/* 18:18 */     private final AtomicInteger mCount = new AtomicInteger(1);
/* 19:   */     
/* 20:   */     public Thread newThread(Runnable r)
/* 21:   */     {
/* 22:23 */       return new Thread(r, "PriorityExecutor #" + this.mCount.getAndIncrement());
/* 23:   */     }
/* 24:   */   };
/* 25:27 */   private final BlockingQueue<Runnable> mPoolWorkQueue = new PriorityObjectBlockingQueue();
/* 26:   */   private final ThreadPoolExecutor mThreadPoolExecutor;
/* 27:   */   
/* 28:   */   public PriorityExecutor()
/* 29:   */   {
/* 30:32 */     this(5);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public PriorityExecutor(int poolSize)
/* 34:   */   {
/* 35:37 */     this.mThreadPoolExecutor = new ThreadPoolExecutor(poolSize, 256, 1L, TimeUnit.SECONDS, this.mPoolWorkQueue, sThreadFactory);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public int getPoolSize()
/* 39:   */   {
/* 40:42 */     return this.mThreadPoolExecutor.getCorePoolSize();
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setPoolSize(int poolSize)
/* 44:   */   {
/* 45:47 */     if (poolSize > 0) {
/* 46:49 */       this.mThreadPoolExecutor.setCorePoolSize(poolSize);
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   public boolean isBusy()
/* 51:   */   {
/* 52:55 */     return this.mThreadPoolExecutor.getActiveCount() >= this.mThreadPoolExecutor.getCorePoolSize();
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void execute(Runnable r)
/* 56:   */   {
/* 57:61 */     this.mThreadPoolExecutor.execute(r);
/* 58:   */   }
/* 59:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.PriorityExecutor
 * JD-Core Version:    0.7.0.1
 */