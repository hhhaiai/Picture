package com.lidroid.xutils.task;

public enum Priority
{
  UI_TOP,  UI_NORMAL,  UI_LOW,  DEFAULT,  BG_TOP,  BG_NORMAL,  BG_LOW;
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.Priority
 * JD-Core Version:    0.7.0.1
 */