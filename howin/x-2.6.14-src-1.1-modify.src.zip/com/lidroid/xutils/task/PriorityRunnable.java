/*  1:   */ package com.lidroid.xutils.task;
/*  2:   */ 
/*  3:   */ public class PriorityRunnable
/*  4:   */   extends PriorityObject<Runnable>
/*  5:   */   implements Runnable
/*  6:   */ {
/*  7:   */   public PriorityRunnable(Priority priority, Runnable obj)
/*  8:   */   {
/*  9:11 */     super(priority, obj);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public void run()
/* 13:   */   {
/* 14:17 */     ((Runnable)this.obj).run();
/* 15:   */   }
/* 16:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.task.PriorityRunnable
 * JD-Core Version:    0.7.0.1
 */