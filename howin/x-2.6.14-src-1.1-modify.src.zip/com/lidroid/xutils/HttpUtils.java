/*   1:    */ package com.lidroid.xutils;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.http.HttpCache;
/*   5:    */ import com.lidroid.xutils.http.HttpHandler;
/*   6:    */ import com.lidroid.xutils.http.RequestParams;
/*   7:    */ import com.lidroid.xutils.http.ResponseStream;
/*   8:    */ import com.lidroid.xutils.http.SyncHttpHandler;
/*   9:    */ import com.lidroid.xutils.http.callback.HttpRedirectHandler;
/*  10:    */ import com.lidroid.xutils.http.callback.RequestCallBack;
/*  11:    */ import com.lidroid.xutils.http.client.DefaultSSLSocketFactory;
/*  12:    */ import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
/*  13:    */ import com.lidroid.xutils.http.client.RetryHandler;
/*  14:    */ import com.lidroid.xutils.http.client.entity.GZipDecompressingEntity;
/*  15:    */ import com.lidroid.xutils.task.PriorityExecutor;
/*  16:    */ import com.lidroid.xutils.util.OtherUtils;
/*  17:    */ import java.io.File;
/*  18:    */ import java.io.IOException;
/*  19:    */ import org.apache.http.Header;
/*  20:    */ import org.apache.http.HeaderElement;
/*  21:    */ import org.apache.http.HttpEntity;
/*  22:    */ import org.apache.http.HttpRequestInterceptor;
/*  23:    */ import org.apache.http.HttpResponse;
/*  24:    */ import org.apache.http.HttpResponseInterceptor;
/*  25:    */ import org.apache.http.HttpVersion;
/*  26:    */ import org.apache.http.client.CookieStore;
/*  27:    */ import org.apache.http.client.HttpClient;
/*  28:    */ import org.apache.http.conn.ClientConnectionManager;
/*  29:    */ import org.apache.http.conn.params.ConnManagerParams;
/*  30:    */ import org.apache.http.conn.params.ConnPerRouteBean;
/*  31:    */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*  32:    */ import org.apache.http.conn.scheme.Scheme;
/*  33:    */ import org.apache.http.conn.scheme.SchemeRegistry;
/*  34:    */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*  35:    */ import org.apache.http.impl.client.DefaultHttpClient;
/*  36:    */ import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
/*  37:    */ import org.apache.http.params.BasicHttpParams;
/*  38:    */ import org.apache.http.params.HttpConnectionParams;
/*  39:    */ import org.apache.http.params.HttpParams;
/*  40:    */ import org.apache.http.params.HttpProtocolParams;
/*  41:    */ import org.apache.http.protocol.BasicHttpContext;
/*  42:    */ import org.apache.http.protocol.HttpContext;
/*  43:    */ 
/*  44:    */ public class HttpUtils
/*  45:    */ {
/*  46: 55 */   public static final HttpCache sHttpCache = new HttpCache();
/*  47:    */   private final DefaultHttpClient httpClient;
/*  48: 58 */   private final HttpContext httpContext = new BasicHttpContext();
/*  49:    */   private HttpRedirectHandler httpRedirectHandler;
/*  50:    */   
/*  51:    */   public HttpUtils()
/*  52:    */   {
/*  53: 64 */     this(15000, null);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public HttpUtils(int connTimeout)
/*  57:    */   {
/*  58: 69 */     this(connTimeout, null);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public HttpUtils(String userAgent)
/*  62:    */   {
/*  63: 74 */     this(15000, userAgent);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public HttpUtils(int connTimeout, String userAgent)
/*  67:    */   {
/*  68: 79 */     HttpParams params = new BasicHttpParams();
/*  69:    */     
/*  70: 81 */     ConnManagerParams.setTimeout(params, connTimeout);
/*  71: 82 */     HttpConnectionParams.setSoTimeout(params, connTimeout);
/*  72: 83 */     HttpConnectionParams.setConnectionTimeout(params, connTimeout);
/*  73: 85 */     if (TextUtils.isEmpty(userAgent)) {
/*  74: 87 */       userAgent = OtherUtils.getUserAgent(null);
/*  75:    */     }
/*  76: 89 */     HttpProtocolParams.setUserAgent(params, userAgent);
/*  77:    */     
/*  78: 91 */     ConnManagerParams.setMaxConnectionsPerRoute(params, new ConnPerRouteBean(10));
/*  79: 92 */     ConnManagerParams.setMaxTotalConnections(params, 10);
/*  80:    */     
/*  81: 94 */     HttpConnectionParams.setTcpNoDelay(params, true);
/*  82: 95 */     HttpConnectionParams.setSocketBufferSize(params, 8192);
/*  83: 96 */     HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
/*  84:    */     
/*  85: 98 */     SchemeRegistry schemeRegistry = new SchemeRegistry();
/*  86: 99 */     schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
/*  87:100 */     schemeRegistry.register(new Scheme("https", DefaultSSLSocketFactory.getSocketFactory(), 443));
/*  88:    */     
/*  89:102 */     this.httpClient = new DefaultHttpClient(new ThreadSafeClientConnManager(params, schemeRegistry), params);
/*  90:    */     
/*  91:104 */     this.httpClient.setHttpRequestRetryHandler(new RetryHandler(3));
/*  92:    */     
/*  93:106 */     this.httpClient.addRequestInterceptor(new HttpRequestInterceptor()
/*  94:    */     {
/*  95:    */       public void process(org.apache.http.HttpRequest httpRequest, HttpContext httpContext)
/*  96:    */         throws org.apache.http.HttpException, IOException
/*  97:    */       {
/*  98:111 */         if (!httpRequest.containsHeader("Accept-Encoding")) {
/*  99:113 */           httpRequest.addHeader("Accept-Encoding", "gzip");
/* 100:    */         }
/* 101:    */       }
/* 102:117 */     });
/* 103:118 */     this.httpClient.addResponseInterceptor(new HttpResponseInterceptor()
/* 104:    */     {
/* 105:    */       public void process(HttpResponse response, HttpContext httpContext)
/* 106:    */         throws org.apache.http.HttpException, IOException
/* 107:    */       {
/* 108:123 */         HttpEntity entity = response.getEntity();
/* 109:124 */         if (entity == null) {
/* 110:126 */           return;
/* 111:    */         }
/* 112:128 */         Header encoding = entity.getContentEncoding();
/* 113:129 */         if (encoding != null) {
/* 114:131 */           for (HeaderElement element : encoding.getElements()) {
/* 115:133 */             if (element.getName().equalsIgnoreCase("gzip"))
/* 116:    */             {
/* 117:135 */               response.setEntity(new GZipDecompressingEntity(response.getEntity()));
/* 118:136 */               return;
/* 119:    */             }
/* 120:    */           }
/* 121:    */         }
/* 122:    */       }
/* 123:    */     });
/* 124:    */   }
/* 125:    */   
/* 126:147 */   private String responseTextCharset = "UTF-8";
/* 127:149 */   private long currentRequestExpiry = HttpCache.getDefaultExpiryTime();
/* 128:    */   private static final int DEFAULT_CONN_TIMEOUT = 15000;
/* 129:    */   private static final int DEFAULT_RETRY_TIMES = 3;
/* 130:    */   private static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
/* 131:    */   private static final String ENCODING_GZIP = "gzip";
/* 132:    */   private static final int DEFAULT_POOL_SIZE = 3;
/* 133:159 */   private static final PriorityExecutor EXECUTOR = new PriorityExecutor(3);
/* 134:    */   
/* 135:    */   public HttpClient getHttpClient()
/* 136:    */   {
/* 137:163 */     return this.httpClient;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public HttpUtils configResponseTextCharset(String charSet)
/* 141:    */   {
/* 142:171 */     if (!TextUtils.isEmpty(charSet)) {
/* 143:173 */       this.responseTextCharset = charSet;
/* 144:    */     }
/* 145:175 */     return this;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public HttpUtils configHttpRedirectHandler(HttpRedirectHandler httpRedirectHandler)
/* 149:    */   {
/* 150:180 */     this.httpRedirectHandler = httpRedirectHandler;
/* 151:181 */     return this;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public HttpUtils configHttpCacheSize(int httpCacheSize)
/* 155:    */   {
/* 156:186 */     sHttpCache.setCacheSize(httpCacheSize);
/* 157:187 */     return this;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public HttpUtils configDefaultHttpCacheExpiry(long defaultExpiry)
/* 161:    */   {
/* 162:192 */     HttpCache.setDefaultExpiryTime(defaultExpiry);
/* 163:193 */     this.currentRequestExpiry = HttpCache.getDefaultExpiryTime();
/* 164:194 */     return this;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public HttpUtils configCurrentHttpCacheExpiry(long currRequestExpiry)
/* 168:    */   {
/* 169:199 */     this.currentRequestExpiry = currRequestExpiry;
/* 170:200 */     return this;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public HttpUtils configCookieStore(CookieStore cookieStore)
/* 174:    */   {
/* 175:205 */     this.httpContext.setAttribute("http.cookie-store", cookieStore);
/* 176:206 */     return this;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public HttpUtils configUserAgent(String userAgent)
/* 180:    */   {
/* 181:211 */     HttpProtocolParams.setUserAgent(this.httpClient.getParams(), userAgent);
/* 182:212 */     return this;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public HttpUtils configTimeout(int timeout)
/* 186:    */   {
/* 187:217 */     HttpParams httpParams = this.httpClient.getParams();
/* 188:218 */     ConnManagerParams.setTimeout(httpParams, timeout);
/* 189:219 */     HttpConnectionParams.setConnectionTimeout(httpParams, timeout);
/* 190:220 */     return this;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public HttpUtils configSoTimeout(int timeout)
/* 194:    */   {
/* 195:225 */     HttpParams httpParams = this.httpClient.getParams();
/* 196:226 */     HttpConnectionParams.setSoTimeout(httpParams, timeout);
/* 197:227 */     return this;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public HttpUtils configRegisterScheme(Scheme scheme)
/* 201:    */   {
/* 202:232 */     this.httpClient.getConnectionManager().getSchemeRegistry().register(scheme);
/* 203:233 */     return this;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public HttpUtils configSSLSocketFactory(SSLSocketFactory sslSocketFactory)
/* 207:    */   {
/* 208:238 */     Scheme scheme = new Scheme("https", sslSocketFactory, 443);
/* 209:239 */     this.httpClient.getConnectionManager().getSchemeRegistry().register(scheme);
/* 210:240 */     return this;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public HttpUtils configRequestRetryCount(int count)
/* 214:    */   {
/* 215:245 */     this.httpClient.setHttpRequestRetryHandler(new RetryHandler(count));
/* 216:246 */     return this;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public HttpUtils configRequestThreadPoolSize(int threadPoolSize)
/* 220:    */   {
/* 221:251 */     EXECUTOR.setPoolSize(threadPoolSize);
/* 222:252 */     return this;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public <T> HttpHandler<T> send(HttpRequest.HttpMethod method, String url, RequestCallBack<T> callBack)
/* 226:    */   {
/* 227:260 */     return send(method, url, null, callBack);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public <T> HttpHandler<T> send(HttpRequest.HttpMethod method, String url, RequestParams params, RequestCallBack<T> callBack)
/* 231:    */   {
/* 232:265 */     if (url == null) {
/* 233:266 */       throw new IllegalArgumentException("url may not be null");
/* 234:    */     }
/* 235:268 */     com.lidroid.xutils.http.client.HttpRequest request = new com.lidroid.xutils.http.client.HttpRequest(method, url);
/* 236:269 */     return sendRequest(request, params, callBack);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public ResponseStream sendSync(HttpRequest.HttpMethod method, String url)
/* 240:    */     throws com.lidroid.xutils.exception.HttpException
/* 241:    */   {
/* 242:274 */     return sendSync(method, url, null);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public ResponseStream sendSync(HttpRequest.HttpMethod method, String url, RequestParams params)
/* 246:    */     throws com.lidroid.xutils.exception.HttpException
/* 247:    */   {
/* 248:279 */     if (url == null) {
/* 249:280 */       throw new IllegalArgumentException("url may not be null");
/* 250:    */     }
/* 251:282 */     com.lidroid.xutils.http.client.HttpRequest request = new com.lidroid.xutils.http.client.HttpRequest(method, url);
/* 252:283 */     return sendSyncRequest(request, params);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public HttpHandler<File> download(String url, String target, RequestCallBack<File> callback)
/* 256:    */   {
/* 257:291 */     return download(HttpRequest.HttpMethod.GET, url, target, null, false, false, callback);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public HttpHandler<File> download(String url, String target, boolean autoResume, RequestCallBack<File> callback)
/* 261:    */   {
/* 262:296 */     return download(HttpRequest.HttpMethod.GET, url, target, null, autoResume, false, callback);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public HttpHandler<File> download(String url, String target, boolean autoResume, boolean autoRename, RequestCallBack<File> callback)
/* 266:    */   {
/* 267:301 */     return download(HttpRequest.HttpMethod.GET, url, target, null, autoResume, autoRename, callback);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public HttpHandler<File> download(String url, String target, RequestParams params, RequestCallBack<File> callback)
/* 271:    */   {
/* 272:306 */     return download(HttpRequest.HttpMethod.GET, url, target, params, false, false, callback);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public HttpHandler<File> download(String url, String target, RequestParams params, boolean autoResume, RequestCallBack<File> callback)
/* 276:    */   {
/* 277:311 */     return download(HttpRequest.HttpMethod.GET, url, target, params, autoResume, false, callback);
/* 278:    */   }
/* 279:    */   
/* 280:    */   public HttpHandler<File> download(String url, String target, RequestParams params, boolean autoResume, boolean autoRename, RequestCallBack<File> callback)
/* 281:    */   {
/* 282:316 */     return download(HttpRequest.HttpMethod.GET, url, target, params, autoResume, autoRename, callback);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public HttpHandler<File> download(HttpRequest.HttpMethod method, String url, String target, RequestParams params, RequestCallBack<File> callback)
/* 286:    */   {
/* 287:321 */     return download(method, url, target, params, false, false, callback);
/* 288:    */   }
/* 289:    */   
/* 290:    */   public HttpHandler<File> download(HttpRequest.HttpMethod method, String url, String target, RequestParams params, boolean autoResume, RequestCallBack<File> callback)
/* 291:    */   {
/* 292:326 */     return download(method, url, target, params, autoResume, false, callback);
/* 293:    */   }
/* 294:    */   
/* 295:    */   public HttpHandler<File> download(HttpRequest.HttpMethod method, String url, String target, RequestParams params, boolean autoResume, boolean autoRename, RequestCallBack<File> callback)
/* 296:    */   {
/* 297:333 */     if (url == null) {
/* 298:334 */       throw new IllegalArgumentException("url may not be null");
/* 299:    */     }
/* 300:335 */     if (target == null) {
/* 301:336 */       throw new IllegalArgumentException("target may not be null");
/* 302:    */     }
/* 303:338 */     com.lidroid.xutils.http.client.HttpRequest request = new com.lidroid.xutils.http.client.HttpRequest(method, url);
/* 304:    */     
/* 305:340 */     HttpHandler<File> handler = new HttpHandler(this.httpClient, this.httpContext, this.responseTextCharset, callback);
/* 306:    */     
/* 307:342 */     handler.setExpiry(this.currentRequestExpiry);
/* 308:343 */     handler.setHttpRedirectHandler(this.httpRedirectHandler);
/* 309:345 */     if (params != null)
/* 310:    */     {
/* 311:347 */       request.setRequestParams(params, handler);
/* 312:348 */       handler.setPriority(params.getPriority());
/* 313:    */     }
/* 314:350 */     if (callback != null) {
/* 315:352 */       callback.setmHttpHandler(handler);
/* 316:    */     }
/* 317:354 */     handler.executeOnExecutor(EXECUTOR, new Object[] { request, target, Boolean.valueOf(autoResume), Boolean.valueOf(autoRename) });
/* 318:355 */     return handler;
/* 319:    */   }
/* 320:    */   
/* 321:    */   private <T> HttpHandler<T> sendRequest(com.lidroid.xutils.http.client.HttpRequest request, RequestParams params, RequestCallBack<T> callBack)
/* 322:    */   {
/* 323:362 */     HttpHandler<T> handler = new HttpHandler(this.httpClient, this.httpContext, this.responseTextCharset, callBack);
/* 324:    */     
/* 325:364 */     handler.setExpiry(this.currentRequestExpiry);
/* 326:365 */     handler.setHttpRedirectHandler(this.httpRedirectHandler);
/* 327:366 */     request.setRequestParams(params, handler);
/* 328:368 */     if (params != null) {
/* 329:370 */       handler.setPriority(params.getPriority());
/* 330:    */     }
/* 331:372 */     if (callBack != null) {
/* 332:374 */       callBack.setmHttpHandler(handler);
/* 333:    */     }
/* 334:376 */     handler.executeOnExecutor(EXECUTOR, new Object[] { request });
/* 335:377 */     return handler;
/* 336:    */   }
/* 337:    */   
/* 338:    */   private ResponseStream sendSyncRequest(com.lidroid.xutils.http.client.HttpRequest request, RequestParams params)
/* 339:    */     throws com.lidroid.xutils.exception.HttpException
/* 340:    */   {
/* 341:383 */     SyncHttpHandler handler = new SyncHttpHandler(this.httpClient, this.httpContext, this.responseTextCharset);
/* 342:    */     
/* 343:385 */     handler.setExpiry(this.currentRequestExpiry);
/* 344:386 */     handler.setHttpRedirectHandler(this.httpRedirectHandler);
/* 345:387 */     request.setRequestParams(params);
/* 346:    */     
/* 347:389 */     return handler.sendRequest(request);
/* 348:    */   }
/* 349:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.HttpUtils
 * JD-Core Version:    0.7.0.1
 */