/*  1:   */ package com.lidroid.xutils.view;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.preference.Preference;
/*  6:   */ import android.preference.PreferenceActivity;
/*  7:   */ import android.preference.PreferenceGroup;
/*  8:   */ import android.view.View;
/*  9:   */ 
/* 10:   */ public class ViewFinder
/* 11:   */ {
/* 12:   */   private View view;
/* 13:   */   private Activity activity;
/* 14:   */   private PreferenceGroup preferenceGroup;
/* 15:   */   private PreferenceActivity preferenceActivity;
/* 16:   */   
/* 17:   */   public ViewFinder(View view)
/* 18:   */   {
/* 19:23 */     this.view = view;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public ViewFinder(Activity activity)
/* 23:   */   {
/* 24:28 */     this.activity = activity;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public ViewFinder(PreferenceGroup preferenceGroup)
/* 28:   */   {
/* 29:33 */     this.preferenceGroup = preferenceGroup;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public ViewFinder(PreferenceActivity preferenceActivity)
/* 33:   */   {
/* 34:38 */     this.preferenceActivity = preferenceActivity;
/* 35:39 */     this.activity = preferenceActivity;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public View findViewById(int id)
/* 39:   */   {
/* 40:44 */     return this.activity == null ? this.view.findViewById(id) : this.activity.findViewById(id);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public View findViewByInfo(ViewInjectInfo info)
/* 44:   */   {
/* 45:49 */     return findViewById(((Integer)info.value).intValue(), info.parentId);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public View findViewById(int id, int pid)
/* 49:   */   {
/* 50:54 */     View pView = null;
/* 51:55 */     if (pid > 0) {
/* 52:57 */       pView = findViewById(pid);
/* 53:   */     }
/* 54:60 */     View view = null;
/* 55:61 */     if (pView != null) {
/* 56:63 */       view = pView.findViewById(id);
/* 57:   */     } else {
/* 58:66 */       view = findViewById(id);
/* 59:   */     }
/* 60:68 */     return view;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public Preference findPreference(CharSequence key)
/* 64:   */   {
/* 65:74 */     return this.preferenceGroup == null ? this.preferenceActivity.findPreference(key) : this.preferenceGroup.findPreference(key);
/* 66:   */   }
/* 67:   */   
/* 68:   */   public Context getContext()
/* 69:   */   {
/* 70:79 */     if (this.view != null) {
/* 71:80 */       return this.view.getContext();
/* 72:   */     }
/* 73:81 */     if (this.activity != null) {
/* 74:82 */       return this.activity;
/* 75:   */     }
/* 76:83 */     if (this.preferenceActivity != null) {
/* 77:84 */       return this.preferenceActivity;
/* 78:   */     }
/* 79:85 */     return null;
/* 80:   */   }
/* 81:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.ViewFinder
 * JD-Core Version:    0.7.0.1
 */