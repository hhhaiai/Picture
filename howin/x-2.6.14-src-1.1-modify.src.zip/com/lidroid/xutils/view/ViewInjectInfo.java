/*  1:   */ package com.lidroid.xutils.view;
/*  2:   */ 
/*  3:   */ public class ViewInjectInfo
/*  4:   */ {
/*  5:   */   public Object value;
/*  6:   */   public int parentId;
/*  7:   */   
/*  8:   */   public boolean equals(Object o)
/*  9:   */   {
/* 10:14 */     if (this == o) {
/* 11:15 */       return true;
/* 12:   */     }
/* 13:16 */     if (!(o instanceof ViewInjectInfo)) {
/* 14:17 */       return false;
/* 15:   */     }
/* 16:19 */     ViewInjectInfo that = (ViewInjectInfo)o;
/* 17:21 */     if (this.parentId != that.parentId) {
/* 18:22 */       return false;
/* 19:   */     }
/* 20:23 */     if (this.value == null) {
/* 21:24 */       return that.value == null;
/* 22:   */     }
/* 23:26 */     return this.value.equals(that.value);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int hashCode()
/* 27:   */   {
/* 28:32 */     int result = this.value.hashCode();
/* 29:33 */     result = 31 * result + this.parentId;
/* 30:34 */     return result;
/* 31:   */   }
/* 32:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.ViewInjectInfo
 * JD-Core Version:    0.7.0.1
 */