package com.lidroid.xutils.view.annotation.event;

import android.view.View.OnKeyListener;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@EventBase(listenerType=View.OnKeyListener.class, listenerSetter="setOnKeyListener", methodName="onKey")
public @interface OnKey
{
  int[] value();
  
  int[] parentId() default {0};
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.annotation.event.OnKey
 * JD-Core Version:    0.7.0.1
 */