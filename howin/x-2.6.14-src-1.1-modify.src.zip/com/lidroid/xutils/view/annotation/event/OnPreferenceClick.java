package com.lidroid.xutils.view.annotation.event;

import android.preference.Preference.OnPreferenceClickListener;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@EventBase(listenerType=Preference.OnPreferenceClickListener.class, listenerSetter="setOnPreferenceClickListener", methodName="onPreferenceClick")
public @interface OnPreferenceClick
{
  String[] value();
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.annotation.event.OnPreferenceClick
 * JD-Core Version:    0.7.0.1
 */