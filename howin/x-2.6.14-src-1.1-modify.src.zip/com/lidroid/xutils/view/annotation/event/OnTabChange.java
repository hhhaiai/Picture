package com.lidroid.xutils.view.annotation.event;

import android.widget.TabHost.OnTabChangeListener;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@EventBase(listenerType=TabHost.OnTabChangeListener.class, listenerSetter="setOnTabChangeListener", methodName="onTabChange")
public @interface OnTabChange
{
  int[] value();
  
  int[] parentId() default {0};
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.annotation.event.OnTabChange
 * JD-Core Version:    0.7.0.1
 */