package com.lidroid.xutils.view.annotation.event;

import android.preference.Preference.OnPreferenceChangeListener;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@EventBase(listenerType=Preference.OnPreferenceChangeListener.class, listenerSetter="setOnPreferenceChangeListener", methodName="onPreferenceChange")
public @interface OnPreferenceChange
{
  String[] value();
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.annotation.event.OnPreferenceChange
 * JD-Core Version:    0.7.0.1
 */