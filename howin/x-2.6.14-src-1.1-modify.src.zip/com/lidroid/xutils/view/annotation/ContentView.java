package com.lidroid.xutils.view.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ContentView
{
  int value();
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.annotation.ContentView
 * JD-Core Version:    0.7.0.1
 */