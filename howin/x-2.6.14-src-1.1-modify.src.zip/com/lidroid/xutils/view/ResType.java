package com.lidroid.xutils.view;

public enum ResType
{
  Animation,  Boolean,  Color,  ColorStateList,  Dimension,  DimensionPixelOffset,  DimensionPixelSize,  Drawable,  Integer,  IntArray,  Movie,  String,  StringArray,  Text,  TextArray,  Xml;
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.ResType
 * JD-Core Version:    0.7.0.1
 */