/*   1:    */ package com.lidroid.xutils.view;
/*   2:    */ 
/*   3:    */ import android.view.View;
/*   4:    */ import com.lidroid.xutils.util.DoubleKeyValueMap;
/*   5:    */ import com.lidroid.xutils.util.LogUtils;
/*   6:    */ import com.lidroid.xutils.view.annotation.event.EventBase;
/*   7:    */ import java.lang.annotation.Annotation;
/*   8:    */ import java.lang.ref.WeakReference;
/*   9:    */ import java.lang.reflect.InvocationHandler;
/*  10:    */ import java.lang.reflect.Method;
/*  11:    */ import java.lang.reflect.Proxy;
/*  12:    */ import java.util.HashMap;
/*  13:    */ 
/*  14:    */ public class EventListenerManager
/*  15:    */ {
/*  16: 40 */   private static final DoubleKeyValueMap<ViewInjectInfo, Class<?>, Object> listenerCache = new DoubleKeyValueMap();
/*  17:    */   
/*  18:    */   public static void addEventMethod(ViewFinder finder, ViewInjectInfo info, Annotation eventAnnotation, Object handler, Method method)
/*  19:    */   {
/*  20:    */     try
/*  21:    */     {
/*  22: 46 */       View view = finder.findViewByInfo(info);
/*  23: 47 */       if (view != null)
/*  24:    */       {
/*  25: 49 */         EventBase eventBase = (EventBase)eventAnnotation.annotationType().getAnnotation(EventBase.class);
/*  26: 50 */         Class<?> listenerType = eventBase.listenerType();
/*  27: 51 */         String listenerSetter = eventBase.listenerSetter();
/*  28: 52 */         String methodName = eventBase.methodName();
/*  29:    */         
/*  30: 54 */         boolean addNewMethod = false;
/*  31: 55 */         Object listener = listenerCache.get(info, listenerType);
/*  32: 56 */         DynamicHandler dynamicHandler = null;
/*  33: 57 */         if (listener != null)
/*  34:    */         {
/*  35: 59 */           dynamicHandler = (DynamicHandler)Proxy.getInvocationHandler(listener);
/*  36: 60 */           addNewMethod = handler.equals(dynamicHandler.getHandler());
/*  37: 61 */           if (addNewMethod) {
/*  38: 63 */             dynamicHandler.addMethod(methodName, method);
/*  39:    */           }
/*  40:    */         }
/*  41: 66 */         if (!addNewMethod)
/*  42:    */         {
/*  43: 68 */           dynamicHandler = new DynamicHandler(handler);
/*  44: 69 */           dynamicHandler.addMethod(methodName, method);
/*  45: 70 */           listener = Proxy.newProxyInstance(listenerType.getClassLoader(), new Class[] { listenerType }, dynamicHandler);
/*  46:    */           
/*  47: 72 */           listenerCache.put(info, listenerType, listener);
/*  48:    */         }
/*  49: 75 */         Method setEventListenerMethod = view.getClass().getMethod(listenerSetter, new Class[] { listenerType });
/*  50: 76 */         setEventListenerMethod.invoke(view, new Object[] { listener });
/*  51:    */       }
/*  52:    */     }
/*  53:    */     catch (Throwable e)
/*  54:    */     {
/*  55: 80 */       LogUtils.e(e.getMessage(), e);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static class DynamicHandler
/*  60:    */     implements InvocationHandler
/*  61:    */   {
/*  62:    */     private WeakReference<Object> handlerRef;
/*  63: 87 */     private final HashMap<String, Method> methodMap = new HashMap(1);
/*  64:    */     
/*  65:    */     public DynamicHandler(Object handler)
/*  66:    */     {
/*  67: 91 */       this.handlerRef = new WeakReference(handler);
/*  68:    */     }
/*  69:    */     
/*  70:    */     public void addMethod(String name, Method method)
/*  71:    */     {
/*  72: 96 */       this.methodMap.put(name, method);
/*  73:    */     }
/*  74:    */     
/*  75:    */     public Object getHandler()
/*  76:    */     {
/*  77:101 */       return this.handlerRef.get();
/*  78:    */     }
/*  79:    */     
/*  80:    */     public void setHandler(Object handler)
/*  81:    */     {
/*  82:106 */       this.handlerRef = new WeakReference(handler);
/*  83:    */     }
/*  84:    */     
/*  85:    */     public Object invoke(Object proxy, Method method, Object[] args)
/*  86:    */       throws Throwable
/*  87:    */     {
/*  88:112 */       Object handler = this.handlerRef.get();
/*  89:113 */       if (handler != null)
/*  90:    */       {
/*  91:115 */         String methodName = method.getName();
/*  92:116 */         method = (Method)this.methodMap.get(methodName);
/*  93:117 */         if (method != null) {
/*  94:119 */           return method.invoke(handler, args);
/*  95:    */         }
/*  96:    */       }
/*  97:122 */       return null;
/*  98:    */     }
/*  99:    */   }
/* 100:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.EventListenerManager
 * JD-Core Version:    0.7.0.1
 */