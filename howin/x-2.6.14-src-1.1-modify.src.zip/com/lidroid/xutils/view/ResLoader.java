/*  1:   */ package com.lidroid.xutils.view;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.content.res.Resources;
/*  5:   */ import android.view.animation.AnimationUtils;
/*  6:   */ 
/*  7:   */ public class ResLoader
/*  8:   */ {
/*  9:   */   public static Object loadRes(ResType type, Context context, int id)
/* 10:   */   {
/* 11:14 */     if ((context == null) || (id < 1)) {
/* 12:15 */       return null;
/* 13:   */     }
/* 14:16 */     switch (type)
/* 15:   */     {
/* 16:   */     case Animation: 
/* 17:19 */       return AnimationUtils.loadAnimation(context, id);
/* 18:   */     case Boolean: 
/* 19:21 */       return Boolean.valueOf(context.getResources().getBoolean(id));
/* 20:   */     case Color: 
/* 21:23 */       return Integer.valueOf(context.getResources().getColor(id));
/* 22:   */     case ColorStateList: 
/* 23:25 */       return context.getResources().getColorStateList(id);
/* 24:   */     case Dimension: 
/* 25:27 */       return Float.valueOf(context.getResources().getDimension(id));
/* 26:   */     case DimensionPixelOffset: 
/* 27:29 */       return Integer.valueOf(context.getResources().getDimensionPixelOffset(id));
/* 28:   */     case DimensionPixelSize: 
/* 29:31 */       return Integer.valueOf(context.getResources().getDimensionPixelSize(id));
/* 30:   */     case Drawable: 
/* 31:33 */       return context.getResources().getDrawable(id);
/* 32:   */     case IntArray: 
/* 33:35 */       return Integer.valueOf(context.getResources().getInteger(id));
/* 34:   */     case Integer: 
/* 35:37 */       return context.getResources().getIntArray(id);
/* 36:   */     case Movie: 
/* 37:39 */       return context.getResources().getMovie(id);
/* 38:   */     case String: 
/* 39:41 */       return context.getResources().getString(id);
/* 40:   */     case StringArray: 
/* 41:43 */       return context.getResources().getStringArray(id);
/* 42:   */     case Text: 
/* 43:45 */       return context.getResources().getText(id);
/* 44:   */     case TextArray: 
/* 45:47 */       return context.getResources().getTextArray(id);
/* 46:   */     case Xml: 
/* 47:49 */       return context.getResources().getXml(id);
/* 48:   */     }
/* 49:54 */     return null;
/* 50:   */   }
/* 51:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.view.ResLoader
 * JD-Core Version:    0.7.0.1
 */