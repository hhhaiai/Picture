/*  1:   */ package com.lidroid.xutils.exception;
/*  2:   */ 
/*  3:   */ public class HttpException
/*  4:   */   extends BaseException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   private int exceptionCode;
/*  8:   */   
/*  9:   */   public HttpException() {}
/* 10:   */   
/* 11:   */   public HttpException(String detailMessage)
/* 12:   */   {
/* 13:30 */     super(detailMessage);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public HttpException(String detailMessage, Throwable throwable)
/* 17:   */   {
/* 18:35 */     super(detailMessage, throwable);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public HttpException(Throwable throwable)
/* 22:   */   {
/* 23:40 */     super(throwable);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public HttpException(int exceptionCode)
/* 27:   */   {
/* 28:50 */     this.exceptionCode = exceptionCode;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public HttpException(int exceptionCode, String detailMessage)
/* 32:   */   {
/* 33:61 */     super(detailMessage);
/* 34:62 */     this.exceptionCode = exceptionCode;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public HttpException(int exceptionCode, String detailMessage, Throwable throwable)
/* 38:   */   {
/* 39:74 */     super(detailMessage, throwable);
/* 40:75 */     this.exceptionCode = exceptionCode;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public HttpException(int exceptionCode, Throwable throwable)
/* 44:   */   {
/* 45:86 */     super(throwable);
/* 46:87 */     this.exceptionCode = exceptionCode;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public int getExceptionCode()
/* 50:   */   {
/* 51:96 */     return this.exceptionCode;
/* 52:   */   }
/* 53:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.exception.HttpException
 * JD-Core Version:    0.7.0.1
 */