/*  1:   */ package com.lidroid.xutils.exception;
/*  2:   */ 
/*  3:   */ public class DbException
/*  4:   */   extends BaseException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public DbException() {}
/*  9:   */   
/* 10:   */   public DbException(String detailMessage)
/* 11:   */   {
/* 12:28 */     super(detailMessage);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public DbException(String detailMessage, Throwable throwable)
/* 16:   */   {
/* 17:33 */     super(detailMessage, throwable);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public DbException(Throwable throwable)
/* 21:   */   {
/* 22:38 */     super(throwable);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.exception.DbException
 * JD-Core Version:    0.7.0.1
 */