/*  1:   */ package com.lidroid.xutils.exception;
/*  2:   */ 
/*  3:   */ public class BaseException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public BaseException() {}
/*  9:   */   
/* 10:   */   public BaseException(String detailMessage)
/* 11:   */   {
/* 12:31 */     super(detailMessage);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public BaseException(String detailMessage, Throwable throwable)
/* 16:   */   {
/* 17:36 */     super(detailMessage, throwable);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public BaseException(Throwable throwable)
/* 21:   */   {
/* 22:41 */     super(throwable);
/* 23:   */   }
/* 24:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.exception.BaseException
 * JD-Core Version:    0.7.0.1
 */