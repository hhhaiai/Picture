/*   1:    */ package com.lidroid.xutils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.res.Resources;
/*   5:    */ import android.graphics.Bitmap;
/*   6:    */ import android.graphics.Bitmap.Config;
/*   7:    */ import android.graphics.drawable.BitmapDrawable;
/*   8:    */ import android.graphics.drawable.Drawable;
/*   9:    */ import android.text.TextUtils;
/*  10:    */ import android.view.View;
/*  11:    */ import android.view.animation.Animation;
/*  12:    */ import com.lidroid.xutils.bitmap.BitmapCacheListener;
/*  13:    */ import com.lidroid.xutils.bitmap.BitmapCommonUtils;
/*  14:    */ import com.lidroid.xutils.bitmap.BitmapDisplayConfig;
/*  15:    */ import com.lidroid.xutils.bitmap.BitmapGlobalConfig;
/*  16:    */ import com.lidroid.xutils.bitmap.callback.BitmapLoadCallBack;
/*  17:    */ import com.lidroid.xutils.bitmap.callback.BitmapLoadFrom;
/*  18:    */ import com.lidroid.xutils.bitmap.callback.DefaultBitmapLoadCallBack;
/*  19:    */ import com.lidroid.xutils.bitmap.core.AsyncDrawable;
/*  20:    */ import com.lidroid.xutils.bitmap.core.BitmapCache;
/*  21:    */ import com.lidroid.xutils.bitmap.core.BitmapSize;
/*  22:    */ import com.lidroid.xutils.bitmap.download.Downloader;
/*  23:    */ import com.lidroid.xutils.cache.FileNameGenerator;
/*  24:    */ import com.lidroid.xutils.task.PriorityAsyncTask;
/*  25:    */ import com.lidroid.xutils.task.PriorityExecutor;
/*  26:    */ import com.lidroid.xutils.task.TaskHandler;
/*  27:    */ import java.io.File;
/*  28:    */ import java.lang.ref.WeakReference;
/*  29:    */ 
/*  30:    */ public class BitmapUtils
/*  31:    */   implements TaskHandler
/*  32:    */ {
/*  33: 46 */   private boolean pauseTask = false;
/*  34: 47 */   private boolean cancelAllTask = false;
/*  35: 48 */   private final Object pauseTaskLock = new Object();
/*  36:    */   private Context context;
/*  37:    */   private BitmapGlobalConfig globalConfig;
/*  38:    */   private BitmapDisplayConfig defaultDisplayConfig;
/*  39:    */   
/*  40:    */   public BitmapUtils(Context context)
/*  41:    */   {
/*  42: 58 */     this(context, null);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public BitmapUtils(Context context, String diskCachePath)
/*  46:    */   {
/*  47: 63 */     if (context == null) {
/*  48: 65 */       throw new IllegalArgumentException("context may not be null");
/*  49:    */     }
/*  50: 68 */     this.context = context.getApplicationContext();
/*  51: 69 */     this.globalConfig = BitmapGlobalConfig.getInstance(this.context, diskCachePath);
/*  52: 70 */     this.defaultDisplayConfig = new BitmapDisplayConfig();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public BitmapUtils(Context context, String diskCachePath, int memoryCacheSize)
/*  56:    */   {
/*  57: 75 */     this(context, diskCachePath);
/*  58: 76 */     this.globalConfig.setMemoryCacheSize(memoryCacheSize);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public BitmapUtils(Context context, String diskCachePath, int memoryCacheSize, int diskCacheSize)
/*  62:    */   {
/*  63: 81 */     this(context, diskCachePath);
/*  64: 82 */     this.globalConfig.setMemoryCacheSize(memoryCacheSize);
/*  65: 83 */     this.globalConfig.setDiskCacheSize(diskCacheSize);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public BitmapUtils(Context context, String diskCachePath, float memoryCachePercent)
/*  69:    */   {
/*  70: 88 */     this(context, diskCachePath);
/*  71: 89 */     this.globalConfig.setMemCacheSizePercent(memoryCachePercent);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public BitmapUtils(Context context, String diskCachePath, float memoryCachePercent, int diskCacheSize)
/*  75:    */   {
/*  76: 94 */     this(context, diskCachePath);
/*  77: 95 */     this.globalConfig.setMemCacheSizePercent(memoryCachePercent);
/*  78: 96 */     this.globalConfig.setDiskCacheSize(diskCacheSize);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public BitmapUtils configDefaultLoadingImage(Drawable drawable)
/*  82:    */   {
/*  83:104 */     this.defaultDisplayConfig.setLoadingDrawable(drawable);
/*  84:105 */     return this;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public BitmapUtils configDefaultLoadingImage(int resId)
/*  88:    */   {
/*  89:110 */     this.defaultDisplayConfig.setLoadingDrawable(this.context.getResources().getDrawable(resId));
/*  90:111 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public BitmapUtils configDefaultLoadingImage(Bitmap bitmap)
/*  94:    */   {
/*  95:116 */     this.defaultDisplayConfig.setLoadingDrawable(new BitmapDrawable(this.context.getResources(), bitmap));
/*  96:117 */     return this;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public BitmapUtils configDefaultLoadFailedImage(Drawable drawable)
/* 100:    */   {
/* 101:122 */     this.defaultDisplayConfig.setLoadFailedDrawable(drawable);
/* 102:123 */     return this;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public BitmapUtils configDefaultLoadFailedImage(int resId)
/* 106:    */   {
/* 107:128 */     this.defaultDisplayConfig.setLoadFailedDrawable(this.context.getResources().getDrawable(resId));
/* 108:129 */     return this;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public BitmapUtils configDefaultLoadFailedImage(Bitmap bitmap)
/* 112:    */   {
/* 113:134 */     this.defaultDisplayConfig.setLoadFailedDrawable(new BitmapDrawable(this.context.getResources(), bitmap));
/* 114:135 */     return this;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public BitmapUtils configDefaultBitmapMaxSize(int maxWidth, int maxHeight)
/* 118:    */   {
/* 119:140 */     this.defaultDisplayConfig.setBitmapMaxSize(new BitmapSize(maxWidth, maxHeight));
/* 120:141 */     return this;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public BitmapUtils configDefaultBitmapMaxSize(BitmapSize maxSize)
/* 124:    */   {
/* 125:146 */     this.defaultDisplayConfig.setBitmapMaxSize(maxSize);
/* 126:147 */     return this;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public BitmapUtils configDefaultImageLoadAnimation(Animation animation)
/* 130:    */   {
/* 131:152 */     this.defaultDisplayConfig.setAnimation(animation);
/* 132:153 */     return this;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public BitmapUtils configDefaultAutoRotation(boolean autoRotation)
/* 136:    */   {
/* 137:158 */     this.defaultDisplayConfig.setAutoRotation(autoRotation);
/* 138:159 */     return this;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public BitmapUtils configDefaultShowOriginal(boolean showOriginal)
/* 142:    */   {
/* 143:164 */     this.defaultDisplayConfig.setShowOriginal(showOriginal);
/* 144:165 */     return this;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public BitmapUtils configDefaultBitmapConfig(Bitmap.Config config)
/* 148:    */   {
/* 149:170 */     this.defaultDisplayConfig.setBitmapConfig(config);
/* 150:171 */     return this;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public BitmapUtils configDefaultDisplayConfig(BitmapDisplayConfig displayConfig)
/* 154:    */   {
/* 155:176 */     this.defaultDisplayConfig = displayConfig;
/* 156:177 */     return this;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public BitmapUtils configDownloader(Downloader downloader)
/* 160:    */   {
/* 161:182 */     this.globalConfig.setDownloader(downloader);
/* 162:183 */     return this;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public BitmapUtils configDefaultCacheExpiry(long defaultExpiry)
/* 166:    */   {
/* 167:188 */     this.globalConfig.setDefaultCacheExpiry(defaultExpiry);
/* 168:189 */     return this;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public BitmapUtils configDefaultConnectTimeout(int connectTimeout)
/* 172:    */   {
/* 173:194 */     this.globalConfig.setDefaultConnectTimeout(connectTimeout);
/* 174:195 */     return this;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public BitmapUtils configDefaultReadTimeout(int readTimeout)
/* 178:    */   {
/* 179:200 */     this.globalConfig.setDefaultReadTimeout(readTimeout);
/* 180:201 */     return this;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public BitmapUtils configThreadPoolSize(int threadPoolSize)
/* 184:    */   {
/* 185:206 */     this.globalConfig.setThreadPoolSize(threadPoolSize);
/* 186:207 */     return this;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public BitmapUtils configMemoryCacheEnabled(boolean enabled)
/* 190:    */   {
/* 191:212 */     this.globalConfig.setMemoryCacheEnabled(enabled);
/* 192:213 */     return this;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public BitmapUtils configDiskCacheEnabled(boolean enabled)
/* 196:    */   {
/* 197:218 */     this.globalConfig.setDiskCacheEnabled(enabled);
/* 198:219 */     return this;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public BitmapUtils configDiskCacheFileNameGenerator(FileNameGenerator fileNameGenerator)
/* 202:    */   {
/* 203:224 */     this.globalConfig.setFileNameGenerator(fileNameGenerator);
/* 204:225 */     return this;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public BitmapUtils configBitmapCacheListener(BitmapCacheListener listener)
/* 208:    */   {
/* 209:230 */     this.globalConfig.setBitmapCacheListener(listener);
/* 210:231 */     return this;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public <T extends View> void display(T container, String uri)
/* 214:    */   {
/* 215:238 */     display(container, uri, null, null);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public <T extends View> void display(T container, String uri, BitmapDisplayConfig displayConfig)
/* 219:    */   {
/* 220:243 */     display(container, uri, displayConfig, null);
/* 221:    */   }
/* 222:    */   
/* 223:    */   public <T extends View> void display(T container, String uri, BitmapLoadCallBack<T> callBack)
/* 224:    */   {
/* 225:248 */     display(container, uri, null, callBack);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public <T extends View> void display(T container, String uri, BitmapDisplayConfig displayConfig, BitmapLoadCallBack<T> callBack)
/* 229:    */   {
/* 230:253 */     if (container == null) {
/* 231:255 */       return;
/* 232:    */     }
/* 233:258 */     if (callBack == null) {
/* 234:260 */       callBack = new DefaultBitmapLoadCallBack();
/* 235:    */     }
/* 236:263 */     if ((displayConfig == null) || (displayConfig == this.defaultDisplayConfig)) {
/* 237:265 */       displayConfig = this.defaultDisplayConfig.cloneNew();
/* 238:    */     }
/* 239:269 */     BitmapSize size = displayConfig.getBitmapMaxSize();
/* 240:270 */     displayConfig.setBitmapMaxSize(BitmapCommonUtils.optimizeMaxSizeByView(container, size.getWidth(), size.getHeight()));
/* 241:    */     
/* 242:272 */     container.clearAnimation();
/* 243:274 */     if (TextUtils.isEmpty(uri))
/* 244:    */     {
/* 245:276 */       callBack.onLoadFailed(container, uri, displayConfig.getLoadFailedDrawable());
/* 246:277 */       return;
/* 247:    */     }
/* 248:281 */     callBack.onPreLoad(container, uri, displayConfig);
/* 249:    */     
/* 250:    */ 
/* 251:284 */     Bitmap bitmap = this.globalConfig.getBitmapCache().getBitmapFromMemCache(uri, displayConfig);
/* 252:286 */     if (bitmap != null)
/* 253:    */     {
/* 254:288 */       callBack.onLoadStarted(container, uri, displayConfig);
/* 255:289 */       callBack.onLoadCompleted(container, uri, bitmap, displayConfig, BitmapLoadFrom.MEMORY_CACHE);
/* 256:    */     }
/* 257:290 */     else if (!bitmapLoadTaskExist(container, uri, callBack))
/* 258:    */     {
/* 259:293 */       BitmapLoadTask<T> loadTask = new BitmapLoadTask(container, uri, displayConfig, callBack);
/* 260:    */       
/* 261:    */ 
/* 262:296 */       PriorityExecutor executor = this.globalConfig.getBitmapLoadExecutor();
/* 263:297 */       File diskCacheFile = getBitmapFileFromDiskCache(uri);
/* 264:298 */       boolean diskCacheExist = (diskCacheFile != null) && (diskCacheFile.exists());
/* 265:299 */       if ((diskCacheExist) && (executor.isBusy())) {
/* 266:301 */         executor = this.globalConfig.getDiskCacheExecutor();
/* 267:    */       }
/* 268:304 */       Drawable loadingDrawable = displayConfig.getLoadingDrawable();
/* 269:305 */       callBack.setDrawable(container, new AsyncDrawable(loadingDrawable, loadTask));
/* 270:    */       
/* 271:307 */       loadTask.setPriority(displayConfig.getPriority());
/* 272:308 */       loadTask.executeOnExecutor(executor, new Object[0]);
/* 273:    */     }
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void clearCache()
/* 277:    */   {
/* 278:317 */     this.globalConfig.clearCache();
/* 279:    */   }
/* 280:    */   
/* 281:    */   public void clearMemoryCache()
/* 282:    */   {
/* 283:322 */     this.globalConfig.clearMemoryCache();
/* 284:    */   }
/* 285:    */   
/* 286:    */   public void clearDiskCache()
/* 287:    */   {
/* 288:327 */     this.globalConfig.clearDiskCache();
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void clearCache(String uri)
/* 292:    */   {
/* 293:332 */     this.globalConfig.clearCache(uri);
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void clearMemoryCache(String uri)
/* 297:    */   {
/* 298:337 */     this.globalConfig.clearMemoryCache(uri);
/* 299:    */   }
/* 300:    */   
/* 301:    */   public void clearDiskCache(String uri)
/* 302:    */   {
/* 303:342 */     this.globalConfig.clearDiskCache(uri);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void flushCache()
/* 307:    */   {
/* 308:347 */     this.globalConfig.flushCache();
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void closeCache()
/* 312:    */   {
/* 313:352 */     this.globalConfig.closeCache();
/* 314:    */   }
/* 315:    */   
/* 316:    */   public File getBitmapFileFromDiskCache(String uri)
/* 317:    */   {
/* 318:357 */     return this.globalConfig.getBitmapCache().getBitmapFileFromDiskCache(uri);
/* 319:    */   }
/* 320:    */   
/* 321:    */   public Bitmap getBitmapFromMemCache(String uri, BitmapDisplayConfig config)
/* 322:    */   {
/* 323:362 */     if (config == null) {
/* 324:364 */       config = this.defaultDisplayConfig;
/* 325:    */     }
/* 326:366 */     return this.globalConfig.getBitmapCache().getBitmapFromMemCache(uri, config);
/* 327:    */   }
/* 328:    */   
/* 329:    */   public boolean supportPause()
/* 330:    */   {
/* 331:375 */     return true;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public boolean supportResume()
/* 335:    */   {
/* 336:381 */     return true;
/* 337:    */   }
/* 338:    */   
/* 339:    */   public boolean supportCancel()
/* 340:    */   {
/* 341:387 */     return true;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public void pause()
/* 345:    */   {
/* 346:393 */     this.pauseTask = true;
/* 347:394 */     flushCache();
/* 348:    */   }
/* 349:    */   
/* 350:    */   public void resume()
/* 351:    */   {
/* 352:400 */     this.pauseTask = false;
/* 353:401 */     synchronized (this.pauseTaskLock)
/* 354:    */     {
/* 355:403 */       this.pauseTaskLock.notifyAll();
/* 356:    */     }
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void cancel()
/* 360:    */   {
/* 361:410 */     this.pauseTask = true;
/* 362:411 */     this.cancelAllTask = true;
/* 363:412 */     synchronized (this.pauseTaskLock)
/* 364:    */     {
/* 365:414 */       this.pauseTaskLock.notifyAll();
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   public boolean isPaused()
/* 370:    */   {
/* 371:421 */     return this.pauseTask;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public boolean isCancelled()
/* 375:    */   {
/* 376:427 */     return this.cancelAllTask;
/* 377:    */   }
/* 378:    */   
/* 379:    */   private static <T extends View> BitmapLoadTask<T> getBitmapTaskFromContainer(T container, BitmapLoadCallBack<T> callBack)
/* 380:    */   {
/* 381:435 */     if (container != null)
/* 382:    */     {
/* 383:437 */       Drawable drawable = callBack.getDrawable(container);
/* 384:438 */       if ((drawable instanceof AsyncDrawable))
/* 385:    */       {
/* 386:440 */         AsyncDrawable<T> asyncDrawable = (AsyncDrawable)drawable;
/* 387:441 */         return asyncDrawable.getBitmapWorkerTask();
/* 388:    */       }
/* 389:    */     }
/* 390:444 */     return null;
/* 391:    */   }
/* 392:    */   
/* 393:    */   private static <T extends View> boolean bitmapLoadTaskExist(T container, String uri, BitmapLoadCallBack<T> callBack)
/* 394:    */   {
/* 395:449 */     BitmapLoadTask<T> oldLoadTask = getBitmapTaskFromContainer(container, callBack);
/* 396:451 */     if (oldLoadTask != null)
/* 397:    */     {
/* 398:453 */       String oldUrl = oldLoadTask.uri;
/* 399:454 */       if ((TextUtils.isEmpty(oldUrl)) || (!oldUrl.equals(uri))) {
/* 400:456 */         oldLoadTask.cancel(true);
/* 401:    */       } else {
/* 402:459 */         return true;
/* 403:    */       }
/* 404:    */     }
/* 405:462 */     return false;
/* 406:    */   }
/* 407:    */   
/* 408:    */   public class BitmapLoadTask<T extends View>
/* 409:    */     extends PriorityAsyncTask<Object, Object, Bitmap>
/* 410:    */   {
/* 411:    */     private final String uri;
/* 412:    */     private final WeakReference<T> containerReference;
/* 413:    */     private final BitmapLoadCallBack<T> callBack;
/* 414:    */     private final BitmapDisplayConfig displayConfig;
/* 415:472 */     private BitmapLoadFrom from = BitmapLoadFrom.DISK_CACHE;
/* 416:    */     private static final int PROGRESS_LOAD_STARTED = 0;
/* 417:    */     private static final int PROGRESS_LOADING = 1;
/* 418:    */     
/* 419:    */     public BitmapLoadTask(String container, BitmapDisplayConfig uri, BitmapLoadCallBack<T> config)
/* 420:    */     {
/* 421:476 */       if ((container == null) || (uri == null) || (config == null) || (callBack == null)) {
/* 422:478 */         throw new IllegalArgumentException("args may not be null");
/* 423:    */       }
/* 424:481 */       this.containerReference = new WeakReference(container);
/* 425:482 */       this.callBack = callBack;
/* 426:483 */       this.uri = uri;
/* 427:484 */       this.displayConfig = config;
/* 428:    */     }
/* 429:    */     
/* 430:    */     protected Bitmap doInBackground(Object... params)
/* 431:    */     {
/* 432:491 */       synchronized (BitmapUtils.this.pauseTaskLock)
/* 433:    */       {
/* 434:    */         do
/* 435:    */         {
/* 436:    */           try
/* 437:    */           {
/* 438:497 */             BitmapUtils.this.pauseTaskLock.wait();
/* 439:498 */             if (BitmapUtils.this.cancelAllTask) {
/* 440:500 */               return null;
/* 441:    */             }
/* 442:    */           }
/* 443:    */           catch (Throwable localThrowable) {}
/* 444:493 */           if (!BitmapUtils.this.pauseTask) {
/* 445:    */             break;
/* 446:    */           }
/* 447:493 */         } while (!isCancelled());
/* 448:    */       }
/* 449:508 */       Bitmap bitmap = null;
/* 450:511 */       if ((!isCancelled()) && (getTargetContainer() != null))
/* 451:    */       {
/* 452:513 */         publishProgress(new Object[] { Integer.valueOf(0) });
/* 453:514 */         bitmap = BitmapUtils.this.globalConfig.getBitmapCache().getBitmapFromDiskCache(this.uri, this.displayConfig);
/* 454:    */       }
/* 455:518 */       if ((bitmap == null) && (!isCancelled()) && (getTargetContainer() != null))
/* 456:    */       {
/* 457:520 */         bitmap = BitmapUtils.this.globalConfig.getBitmapCache().downloadBitmap(this.uri, this.displayConfig, this);
/* 458:521 */         this.from = BitmapLoadFrom.URI;
/* 459:    */       }
/* 460:524 */       return bitmap;
/* 461:    */     }
/* 462:    */     
/* 463:    */     public void updateProgress(long total, long current)
/* 464:    */     {
/* 465:529 */       publishProgress(new Object[] { Integer.valueOf(1), Long.valueOf(total), Long.valueOf(current) });
/* 466:    */     }
/* 467:    */     
/* 468:    */     protected void onProgressUpdate(Object... values)
/* 469:    */     {
/* 470:538 */       if ((values == null) || (values.length == 0)) {
/* 471:539 */         return;
/* 472:    */       }
/* 473:541 */       T container = getTargetContainer();
/* 474:542 */       if (container == null) {
/* 475:543 */         return;
/* 476:    */       }
/* 477:545 */       switch (((Integer)values[0]).intValue())
/* 478:    */       {
/* 479:    */       case 0: 
/* 480:548 */         this.callBack.onLoadStarted(container, this.uri, this.displayConfig);
/* 481:549 */         break;
/* 482:    */       case 1: 
/* 483:551 */         if (values.length != 3) {
/* 484:552 */           return;
/* 485:    */         }
/* 486:553 */         this.callBack.onLoading(container, this.uri, this.displayConfig, ((Long)values[1]).longValue(), ((Long)values[2]).longValue());
/* 487:554 */         break;
/* 488:    */       }
/* 489:    */     }
/* 490:    */     
/* 491:    */     protected void onPostExecute(Bitmap bitmap)
/* 492:    */     {
/* 493:563 */       T container = getTargetContainer();
/* 494:564 */       if (container != null) {
/* 495:566 */         if (bitmap != null) {
/* 496:568 */           this.callBack.onLoadCompleted(container, this.uri, bitmap, this.displayConfig, this.from);
/* 497:    */         } else {
/* 498:571 */           this.callBack.onLoadFailed(container, this.uri, this.displayConfig.getLoadFailedDrawable());
/* 499:    */         }
/* 500:    */       }
/* 501:    */     }
/* 502:    */     
/* 503:    */     protected void onCancelled(Bitmap bitmap)
/* 504:    */     {
/* 505:579 */       synchronized (BitmapUtils.this.pauseTaskLock)
/* 506:    */       {
/* 507:581 */         BitmapUtils.this.pauseTaskLock.notifyAll();
/* 508:    */       }
/* 509:    */     }
/* 510:    */     
/* 511:    */     public T getTargetContainer()
/* 512:    */     {
/* 513:587 */       T container = (View)this.containerReference.get();
/* 514:588 */       BitmapLoadTask<T> bitmapWorkerTask = BitmapUtils.getBitmapTaskFromContainer(container, this.callBack);
/* 515:590 */       if (this == bitmapWorkerTask) {
/* 516:592 */         return container;
/* 517:    */       }
/* 518:595 */       return null;
/* 519:    */     }
/* 520:    */   }
/* 521:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.BitmapUtils
 * JD-Core Version:    0.7.0.1
 */