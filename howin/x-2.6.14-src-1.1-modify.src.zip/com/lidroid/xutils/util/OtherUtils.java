/*   1:    */ package com.lidroid.xutils.util;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.os.Build;
/*   5:    */ import android.os.Build.VERSION;
/*   6:    */ import android.os.Environment;
/*   7:    */ import android.os.StatFs;
/*   8:    */ import android.text.TextUtils;
/*   9:    */ import java.io.File;
/*  10:    */ import java.io.UnsupportedEncodingException;
/*  11:    */ import java.lang.reflect.Field;
/*  12:    */ import java.nio.charset.Charset;
/*  13:    */ import java.security.cert.X509Certificate;
/*  14:    */ import java.util.Locale;
/*  15:    */ import javax.net.ssl.HttpsURLConnection;
/*  16:    */ import javax.net.ssl.SSLContext;
/*  17:    */ import javax.net.ssl.TrustManager;
/*  18:    */ import javax.net.ssl.X509TrustManager;
/*  19:    */ import org.apache.http.Header;
/*  20:    */ import org.apache.http.HeaderElement;
/*  21:    */ import org.apache.http.HttpResponse;
/*  22:    */ import org.apache.http.NameValuePair;
/*  23:    */ import org.apache.http.client.methods.HttpRequestBase;
/*  24:    */ 
/*  25:    */ public class OtherUtils
/*  26:    */ {
/*  27:    */   private static final int STRING_BUFFER_LENGTH = 100;
/*  28:    */   private static javax.net.ssl.SSLSocketFactory sslSocketFactory;
/*  29:    */   
/*  30:    */   public static String getUserAgent(Context context)
/*  31:    */   {
/*  32: 56 */     String webUserAgent = null;
/*  33: 57 */     if (context != null) {
/*  34:    */       try
/*  35:    */       {
/*  36: 61 */         Class sysResCls = Class.forName("com.android.internal.R$string");
/*  37: 62 */         Field webUserAgentField = sysResCls.getDeclaredField("web_user_agent");
/*  38: 63 */         Integer resId = (Integer)webUserAgentField.get(null);
/*  39: 64 */         webUserAgent = context.getString(resId.intValue());
/*  40:    */       }
/*  41:    */       catch (Throwable localThrowable) {}
/*  42:    */     }
/*  43: 69 */     if (TextUtils.isEmpty(webUserAgent)) {
/*  44: 71 */       webUserAgent = "Mozilla/5.0 (Linux; U; Android %s) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 %sSafari/533.1";
/*  45:    */     }
/*  46: 74 */     Locale locale = Locale.getDefault();
/*  47: 75 */     StringBuffer buffer = new StringBuffer();
/*  48:    */     
/*  49: 77 */     String version = Build.VERSION.RELEASE;
/*  50: 78 */     if (version.length() > 0) {
/*  51: 80 */       buffer.append(version);
/*  52:    */     } else {
/*  53: 84 */       buffer.append("1.0");
/*  54:    */     }
/*  55: 86 */     buffer.append("; ");
/*  56: 87 */     String language = locale.getLanguage();
/*  57: 88 */     if (language != null)
/*  58:    */     {
/*  59: 90 */       buffer.append(language.toLowerCase());
/*  60: 91 */       String country = locale.getCountry();
/*  61: 92 */       if (country != null)
/*  62:    */       {
/*  63: 94 */         buffer.append("-");
/*  64: 95 */         buffer.append(country.toLowerCase());
/*  65:    */       }
/*  66:    */     }
/*  67:    */     else
/*  68:    */     {
/*  69:100 */       buffer.append("en");
/*  70:    */     }
/*  71:103 */     if ("REL".equals(Build.VERSION.CODENAME))
/*  72:    */     {
/*  73:105 */       String model = Build.MODEL;
/*  74:106 */       if (model.length() > 0)
/*  75:    */       {
/*  76:108 */         buffer.append("; ");
/*  77:109 */         buffer.append(model);
/*  78:    */       }
/*  79:    */     }
/*  80:112 */     String id = Build.ID;
/*  81:113 */     if (id.length() > 0)
/*  82:    */     {
/*  83:115 */       buffer.append(" Build/");
/*  84:116 */       buffer.append(id);
/*  85:    */     }
/*  86:118 */     return String.format(webUserAgent, new Object[] { buffer, "Mobile " });
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static String getDiskCacheDir(Context context, String dirName)
/*  90:    */   {
/*  91:129 */     String cachePath = null;
/*  92:130 */     if ("mounted".equals(Environment.getExternalStorageState()))
/*  93:    */     {
/*  94:132 */       File externalCacheDir = context.getExternalCacheDir();
/*  95:133 */       if (externalCacheDir != null) {
/*  96:135 */         cachePath = externalCacheDir.getPath();
/*  97:    */       }
/*  98:    */     }
/*  99:138 */     if (cachePath == null)
/* 100:    */     {
/* 101:140 */       File cacheDir = context.getCacheDir();
/* 102:141 */       if ((cacheDir != null) && (cacheDir.exists())) {
/* 103:143 */         cachePath = cacheDir.getPath();
/* 104:    */       }
/* 105:    */     }
/* 106:147 */     return cachePath + File.separator + dirName;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static long getAvailableSpace(File dir)
/* 110:    */   {
/* 111:    */     try
/* 112:    */     {
/* 113:154 */       StatFs stats = new StatFs(dir.getPath());
/* 114:155 */       return stats.getBlockSize() * stats.getAvailableBlocks();
/* 115:    */     }
/* 116:    */     catch (Throwable e)
/* 117:    */     {
/* 118:158 */       LogUtils.e(e.getMessage(), e);
/* 119:    */     }
/* 120:159 */     return -1L;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static boolean isSupportRange(HttpResponse response)
/* 124:    */   {
/* 125:166 */     if (response == null) {
/* 126:167 */       return false;
/* 127:    */     }
/* 128:168 */     Header header = response.getFirstHeader("Accept-Ranges");
/* 129:169 */     if (header != null) {
/* 130:171 */       return "bytes".equals(header.getValue());
/* 131:    */     }
/* 132:173 */     header = response.getFirstHeader("Content-Range");
/* 133:174 */     if (header != null)
/* 134:    */     {
/* 135:176 */       String value = header.getValue();
/* 136:177 */       return (value != null) && (value.startsWith("bytes"));
/* 137:    */     }
/* 138:179 */     return false;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static String getFileNameFromHttpResponse(HttpResponse response)
/* 142:    */   {
/* 143:184 */     if (response == null) {
/* 144:185 */       return null;
/* 145:    */     }
/* 146:186 */     String result = null;
/* 147:187 */     Header header = response.getFirstHeader("Content-Disposition");
/* 148:188 */     if (header != null) {
/* 149:190 */       for (HeaderElement element : header.getElements())
/* 150:    */       {
/* 151:192 */         NameValuePair fileNamePair = element.getParameterByName("filename");
/* 152:193 */         if (fileNamePair != null)
/* 153:    */         {
/* 154:195 */           result = fileNamePair.getValue();
/* 155:    */           
/* 156:197 */           result = CharsetUtils.toCharset(result, "UTF-8", result.length());
/* 157:198 */           break;
/* 158:    */         }
/* 159:    */       }
/* 160:    */     }
/* 161:202 */     return result;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static Charset getCharsetFromHttpRequest(HttpRequestBase request)
/* 165:    */   {
/* 166:207 */     if (request == null) {
/* 167:208 */       return null;
/* 168:    */     }
/* 169:209 */     String charsetName = null;
/* 170:210 */     Header header = request.getFirstHeader("Content-Type");
/* 171:211 */     if (header != null) {
/* 172:213 */       for (HeaderElement element : header.getElements())
/* 173:    */       {
/* 174:215 */         NameValuePair charsetPair = element.getParameterByName("charset");
/* 175:216 */         if (charsetPair != null)
/* 176:    */         {
/* 177:218 */           charsetName = charsetPair.getValue();
/* 178:219 */           break;
/* 179:    */         }
/* 180:    */       }
/* 181:    */     }
/* 182:224 */     boolean isSupportedCharset = false;
/* 183:225 */     if (!TextUtils.isEmpty(charsetName)) {
/* 184:    */       try
/* 185:    */       {
/* 186:229 */         isSupportedCharset = Charset.isSupported(charsetName);
/* 187:    */       }
/* 188:    */       catch (Throwable localThrowable1) {}
/* 189:    */     }
/* 190:235 */     return isSupportedCharset ? Charset.forName(charsetName) : null;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static long sizeOfString(String str, String charset)
/* 194:    */     throws UnsupportedEncodingException
/* 195:    */   {
/* 196:242 */     if (TextUtils.isEmpty(str)) {
/* 197:244 */       return 0L;
/* 198:    */     }
/* 199:246 */     int len = str.length();
/* 200:247 */     if (len < 100) {
/* 201:249 */       return str.getBytes(charset).length;
/* 202:    */     }
/* 203:251 */     long size = 0L;
/* 204:252 */     for (int i = 0; i < len; i += 100)
/* 205:    */     {
/* 206:254 */       int end = i + 100;
/* 207:255 */       end = end < len ? end : len;
/* 208:256 */       String temp = getSubString(str, i, end);
/* 209:257 */       size += temp.getBytes(charset).length;
/* 210:    */     }
/* 211:259 */     return size;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static String getSubString(String str, int start, int end)
/* 215:    */   {
/* 216:265 */     return new String(str.substring(start, end));
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static StackTraceElement getCurrentStackTraceElement()
/* 220:    */   {
/* 221:270 */     return java.lang.Thread.currentThread().getStackTrace()[3];
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static StackTraceElement getCallerStackTraceElement()
/* 225:    */   {
/* 226:275 */     return java.lang.Thread.currentThread().getStackTrace()[4];
/* 227:    */   }
/* 228:    */   
/* 229:    */   public static void trustAllHttpsURLConnection()
/* 230:    */   {
/* 231:283 */     if (sslSocketFactory == null)
/* 232:    */     {
/* 233:285 */       TrustManager[] trustAllCerts = { new X509TrustManager()
/* 234:    */       {
/* 235:    */         public X509Certificate[] getAcceptedIssuers()
/* 236:    */         {
/* 237:290 */           return null;
/* 238:    */         }
/* 239:    */         
/* 240:    */         public void checkClientTrusted(X509Certificate[] certs, String authType) {}
/* 241:    */         
/* 242:    */         public void checkServerTrusted(X509Certificate[] certs, String authType) {}
/* 243:    */       } };
/* 244:    */       try
/* 245:    */       {
/* 246:305 */         SSLContext sslContext = SSLContext.getInstance("TLS");
/* 247:306 */         sslContext.init(null, trustAllCerts, null);
/* 248:307 */         sslSocketFactory = sslContext.getSocketFactory();
/* 249:    */       }
/* 250:    */       catch (Throwable e)
/* 251:    */       {
/* 252:310 */         LogUtils.e(e.getMessage(), e);
/* 253:    */       }
/* 254:    */     }
/* 255:314 */     if (sslSocketFactory != null)
/* 256:    */     {
/* 257:316 */       HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory);
/* 258:317 */       HttpsURLConnection.setDefaultHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
/* 259:    */     }
/* 260:    */   }
/* 261:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.OtherUtils
 * JD-Core Version:    0.7.0.1
 */