/*  1:   */ package com.lidroid.xutils.util;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import java.io.Closeable;
/*  5:   */ 
/*  6:   */ public class IOUtils
/*  7:   */ {
/*  8:   */   public static void closeQuietly(Closeable closeable)
/*  9:   */   {
/* 10:34 */     if (closeable != null) {
/* 11:   */       try
/* 12:   */       {
/* 13:38 */         closeable.close();
/* 14:   */       }
/* 15:   */       catch (Throwable localThrowable) {}
/* 16:   */     }
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void closeQuietly(Cursor cursor)
/* 20:   */   {
/* 21:47 */     if (cursor != null) {
/* 22:   */       try
/* 23:   */       {
/* 24:51 */         cursor.close();
/* 25:   */       }
/* 26:   */       catch (Throwable localThrowable) {}
/* 27:   */     }
/* 28:   */   }
/* 29:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.IOUtils
 * JD-Core Version:    0.7.0.1
 */