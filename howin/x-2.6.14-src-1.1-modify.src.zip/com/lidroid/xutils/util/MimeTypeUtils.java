/*  1:   */ package com.lidroid.xutils.util;
/*  2:   */ 
/*  3:   */ import android.webkit.MimeTypeMap;
/*  4:   */ 
/*  5:   */ public class MimeTypeUtils
/*  6:   */ {
/*  7:   */   public static String getMimeType(String fileName)
/*  8:   */   {
/*  9:32 */     String result = "application/octet-stream";
/* 10:33 */     int extPos = fileName.lastIndexOf(".");
/* 11:34 */     if (extPos != -1)
/* 12:   */     {
/* 13:36 */       String ext = fileName.substring(extPos + 1);
/* 14:37 */       result = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
/* 15:   */     }
/* 16:39 */     return result;
/* 17:   */   }
/* 18:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.MimeTypeUtils
 * JD-Core Version:    0.7.0.1
 */