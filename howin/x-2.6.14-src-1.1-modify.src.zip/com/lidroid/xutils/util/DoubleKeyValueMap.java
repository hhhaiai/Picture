/*   1:    */ package com.lidroid.xutils.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Set;
/*   6:    */ import java.util.concurrent.ConcurrentHashMap;
/*   7:    */ 
/*   8:    */ public class DoubleKeyValueMap<K1, K2, V>
/*   9:    */ {
/*  10:    */   private ConcurrentHashMap<K1, ConcurrentHashMap<K2, V>> k1_k2V_map;
/*  11:    */   
/*  12:    */   public DoubleKeyValueMap()
/*  13:    */   {
/*  14: 33 */     this.k1_k2V_map = new ConcurrentHashMap();
/*  15:    */   }
/*  16:    */   
/*  17:    */   public void put(K1 key1, K2 key2, V value)
/*  18:    */   {
/*  19: 38 */     if ((key1 == null) || (key2 == null) || (value == null)) {
/*  20: 39 */       return;
/*  21:    */     }
/*  22: 40 */     if (this.k1_k2V_map.containsKey(key1))
/*  23:    */     {
/*  24: 42 */       ConcurrentHashMap<K2, V> k2V_map = (ConcurrentHashMap)this.k1_k2V_map.get(key1);
/*  25: 43 */       if (k2V_map != null)
/*  26:    */       {
/*  27: 45 */         k2V_map.put(key2, value);
/*  28:    */       }
/*  29:    */       else
/*  30:    */       {
/*  31: 48 */         k2V_map = new ConcurrentHashMap();
/*  32: 49 */         k2V_map.put(key2, value);
/*  33: 50 */         this.k1_k2V_map.put(key1, k2V_map);
/*  34:    */       }
/*  35:    */     }
/*  36:    */     else
/*  37:    */     {
/*  38: 54 */       ConcurrentHashMap<K2, V> k2V_map = new ConcurrentHashMap();
/*  39: 55 */       k2V_map.put(key2, value);
/*  40: 56 */       this.k1_k2V_map.put(key1, k2V_map);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Set<K1> getFirstKeys()
/*  45:    */   {
/*  46: 62 */     return this.k1_k2V_map.keySet();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public ConcurrentHashMap<K2, V> get(K1 key1)
/*  50:    */   {
/*  51: 67 */     return (ConcurrentHashMap)this.k1_k2V_map.get(key1);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public V get(K1 key1, K2 key2)
/*  55:    */   {
/*  56: 72 */     ConcurrentHashMap<K2, V> k2_v = (ConcurrentHashMap)this.k1_k2V_map.get(key1);
/*  57: 73 */     return k2_v == null ? null : k2_v.get(key2);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Collection<V> getAllValues(K1 key1)
/*  61:    */   {
/*  62: 78 */     ConcurrentHashMap<K2, V> k2_v = (ConcurrentHashMap)this.k1_k2V_map.get(key1);
/*  63: 79 */     return k2_v == null ? null : k2_v.values();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Collection<V> getAllValues()
/*  67:    */   {
/*  68: 84 */     Collection<V> result = null;
/*  69: 85 */     Set<K1> k1Set = this.k1_k2V_map.keySet();
/*  70: 86 */     if (k1Set != null)
/*  71:    */     {
/*  72: 88 */       result = new ArrayList();
/*  73: 89 */       for (K1 k1 : k1Set)
/*  74:    */       {
/*  75: 91 */         Collection<V> values = ((ConcurrentHashMap)this.k1_k2V_map.get(k1)).values();
/*  76: 92 */         if (values != null) {
/*  77: 94 */           result.addAll(values);
/*  78:    */         }
/*  79:    */       }
/*  80:    */     }
/*  81: 98 */     return result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean containsKey(K1 key1, K2 key2)
/*  85:    */   {
/*  86:103 */     if (this.k1_k2V_map.containsKey(key1)) {
/*  87:105 */       return ((ConcurrentHashMap)this.k1_k2V_map.get(key1)).containsKey(key2);
/*  88:    */     }
/*  89:107 */     return false;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean containsKey(K1 key1)
/*  93:    */   {
/*  94:112 */     return this.k1_k2V_map.containsKey(key1);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int size()
/*  98:    */   {
/*  99:117 */     if (this.k1_k2V_map.size() == 0) {
/* 100:118 */       return 0;
/* 101:    */     }
/* 102:120 */     int result = 0;
/* 103:121 */     for (ConcurrentHashMap<K2, V> k2V_map : this.k1_k2V_map.values()) {
/* 104:123 */       result += k2V_map.size();
/* 105:    */     }
/* 106:125 */     return result;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void remove(K1 key1)
/* 110:    */   {
/* 111:130 */     this.k1_k2V_map.remove(key1);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void remove(K1 key1, K2 key2)
/* 115:    */   {
/* 116:135 */     ConcurrentHashMap<K2, V> k2_v = (ConcurrentHashMap)this.k1_k2V_map.get(key1);
/* 117:136 */     if (k2_v != null) {
/* 118:138 */       k2_v.remove(key2);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void clear()
/* 123:    */   {
/* 124:144 */     if (this.k1_k2V_map.size() > 0)
/* 125:    */     {
/* 126:146 */       for (ConcurrentHashMap<K2, V> k2V_map : this.k1_k2V_map.values()) {
/* 127:148 */         k2V_map.clear();
/* 128:    */       }
/* 129:150 */       this.k1_k2V_map.clear();
/* 130:    */     }
/* 131:    */   }
/* 132:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.DoubleKeyValueMap
 * JD-Core Version:    0.7.0.1
 */