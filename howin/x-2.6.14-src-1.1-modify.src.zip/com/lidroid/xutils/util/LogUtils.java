/*   1:    */ package com.lidroid.xutils.util;
/*   2:    */ 
/*   3:    */ import android.util.Log;
/*   4:    */ 
/*   5:    */ public class LogUtils
/*   6:    */ {
/*   7: 31 */   public static String customTagPrefix = "";
/*   8: 37 */   public static boolean allowD = true;
/*   9: 38 */   public static boolean allowE = true;
/*  10: 39 */   public static boolean allowI = true;
/*  11: 40 */   public static boolean allowV = true;
/*  12: 41 */   public static boolean allowW = true;
/*  13: 42 */   public static boolean allowWtf = true;
/*  14:    */   public static CustomLogger customLogger;
/*  15:    */   
/*  16:    */   private static String generateTag(StackTraceElement caller)
/*  17:    */   {
/*  18: 46 */     String tag = "%s.%s(L:%d)";
/*  19: 47 */     String callerClazzName = caller.getClassName();
/*  20: 48 */     callerClazzName = callerClazzName.substring(callerClazzName.lastIndexOf(".") + 1);
/*  21: 49 */     tag = String.format(tag, new Object[] { callerClazzName, caller.getMethodName(), Integer.valueOf(caller.getLineNumber()) });
/*  22: 50 */     tag = customTagPrefix + ":" + tag;
/*  23: 51 */     return tag;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static void d(String content)
/*  27:    */   {
/*  28: 89 */     if (!allowD) {
/*  29: 90 */       return;
/*  30:    */     }
/*  31: 91 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/*  32: 92 */     String tag = generateTag(caller);
/*  33: 94 */     if (customLogger != null) {
/*  34: 96 */       customLogger.d(tag, content);
/*  35:    */     } else {
/*  36: 99 */       Log.d(tag, content);
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void d(String content, Throwable tr)
/*  41:    */   {
/*  42:105 */     if (!allowD) {
/*  43:106 */       return;
/*  44:    */     }
/*  45:107 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/*  46:108 */     String tag = generateTag(caller);
/*  47:110 */     if (customLogger != null) {
/*  48:112 */       customLogger.d(tag, content, tr);
/*  49:    */     } else {
/*  50:115 */       Log.d(tag, content, tr);
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static void e(String content)
/*  55:    */   {
/*  56:121 */     if (!allowE) {
/*  57:122 */       return;
/*  58:    */     }
/*  59:123 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/*  60:124 */     String tag = generateTag(caller);
/*  61:126 */     if (customLogger != null) {
/*  62:128 */       customLogger.e(tag, content);
/*  63:    */     } else {
/*  64:131 */       Log.e(tag, content);
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static void e(String content, Throwable tr)
/*  69:    */   {
/*  70:137 */     if (!allowE) {
/*  71:138 */       return;
/*  72:    */     }
/*  73:139 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/*  74:140 */     String tag = generateTag(caller);
/*  75:142 */     if (customLogger != null) {
/*  76:144 */       customLogger.e(tag, content, tr);
/*  77:    */     } else {
/*  78:147 */       Log.e(tag, content, tr);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static void i(String content)
/*  83:    */   {
/*  84:153 */     if (!allowI) {
/*  85:154 */       return;
/*  86:    */     }
/*  87:155 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/*  88:156 */     String tag = generateTag(caller);
/*  89:158 */     if (customLogger != null) {
/*  90:160 */       customLogger.i(tag, content);
/*  91:    */     } else {
/*  92:163 */       Log.i(tag, content);
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static void i(String content, Throwable tr)
/*  97:    */   {
/*  98:169 */     if (!allowI) {
/*  99:170 */       return;
/* 100:    */     }
/* 101:171 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 102:172 */     String tag = generateTag(caller);
/* 103:174 */     if (customLogger != null) {
/* 104:176 */       customLogger.i(tag, content, tr);
/* 105:    */     } else {
/* 106:179 */       Log.i(tag, content, tr);
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void v(String content)
/* 111:    */   {
/* 112:185 */     if (!allowV) {
/* 113:186 */       return;
/* 114:    */     }
/* 115:187 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 116:188 */     String tag = generateTag(caller);
/* 117:190 */     if (customLogger != null) {
/* 118:192 */       customLogger.v(tag, content);
/* 119:    */     } else {
/* 120:195 */       Log.v(tag, content);
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static void v(String content, Throwable tr)
/* 125:    */   {
/* 126:201 */     if (!allowV) {
/* 127:202 */       return;
/* 128:    */     }
/* 129:203 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 130:204 */     String tag = generateTag(caller);
/* 131:206 */     if (customLogger != null) {
/* 132:208 */       customLogger.v(tag, content, tr);
/* 133:    */     } else {
/* 134:211 */       Log.v(tag, content, tr);
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static void w(String content)
/* 139:    */   {
/* 140:217 */     if (!allowW) {
/* 141:218 */       return;
/* 142:    */     }
/* 143:219 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 144:220 */     String tag = generateTag(caller);
/* 145:222 */     if (customLogger != null) {
/* 146:224 */       customLogger.w(tag, content);
/* 147:    */     } else {
/* 148:227 */       Log.w(tag, content);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static void w(String content, Throwable tr)
/* 153:    */   {
/* 154:233 */     if (!allowW) {
/* 155:234 */       return;
/* 156:    */     }
/* 157:235 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 158:236 */     String tag = generateTag(caller);
/* 159:238 */     if (customLogger != null) {
/* 160:240 */       customLogger.w(tag, content, tr);
/* 161:    */     } else {
/* 162:243 */       Log.w(tag, content, tr);
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static void w(Throwable tr)
/* 167:    */   {
/* 168:249 */     if (!allowW) {
/* 169:250 */       return;
/* 170:    */     }
/* 171:251 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 172:252 */     String tag = generateTag(caller);
/* 173:254 */     if (customLogger != null) {
/* 174:256 */       customLogger.w(tag, tr);
/* 175:    */     } else {
/* 176:259 */       Log.w(tag, tr);
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static void wtf(String content)
/* 181:    */   {
/* 182:265 */     if (!allowWtf) {
/* 183:266 */       return;
/* 184:    */     }
/* 185:267 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 186:268 */     String tag = generateTag(caller);
/* 187:270 */     if (customLogger != null) {
/* 188:272 */       customLogger.wtf(tag, content);
/* 189:    */     } else {
/* 190:275 */       Log.wtf(tag, content);
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   public static void wtf(String content, Throwable tr)
/* 195:    */   {
/* 196:281 */     if (!allowWtf) {
/* 197:282 */       return;
/* 198:    */     }
/* 199:283 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 200:284 */     String tag = generateTag(caller);
/* 201:286 */     if (customLogger != null) {
/* 202:288 */       customLogger.wtf(tag, content, tr);
/* 203:    */     } else {
/* 204:291 */       Log.wtf(tag, content, tr);
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public static void wtf(Throwable tr)
/* 209:    */   {
/* 210:297 */     if (!allowWtf) {
/* 211:298 */       return;
/* 212:    */     }
/* 213:299 */     StackTraceElement caller = OtherUtils.getCallerStackTraceElement();
/* 214:300 */     String tag = generateTag(caller);
/* 215:302 */     if (customLogger != null) {
/* 216:304 */       customLogger.wtf(tag, tr);
/* 217:    */     } else {
/* 218:307 */       Log.wtf(tag, tr);
/* 219:    */     }
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static abstract interface CustomLogger
/* 223:    */   {
/* 224:    */     public abstract void d(String paramString1, String paramString2);
/* 225:    */     
/* 226:    */     public abstract void d(String paramString1, String paramString2, Throwable paramThrowable);
/* 227:    */     
/* 228:    */     public abstract void e(String paramString1, String paramString2);
/* 229:    */     
/* 230:    */     public abstract void e(String paramString1, String paramString2, Throwable paramThrowable);
/* 231:    */     
/* 232:    */     public abstract void i(String paramString1, String paramString2);
/* 233:    */     
/* 234:    */     public abstract void i(String paramString1, String paramString2, Throwable paramThrowable);
/* 235:    */     
/* 236:    */     public abstract void v(String paramString1, String paramString2);
/* 237:    */     
/* 238:    */     public abstract void v(String paramString1, String paramString2, Throwable paramThrowable);
/* 239:    */     
/* 240:    */     public abstract void w(String paramString1, String paramString2);
/* 241:    */     
/* 242:    */     public abstract void w(String paramString1, String paramString2, Throwable paramThrowable);
/* 243:    */     
/* 244:    */     public abstract void w(String paramString, Throwable paramThrowable);
/* 245:    */     
/* 246:    */     public abstract void wtf(String paramString1, String paramString2);
/* 247:    */     
/* 248:    */     public abstract void wtf(String paramString1, String paramString2, Throwable paramThrowable);
/* 249:    */     
/* 250:    */     public abstract void wtf(String paramString, Throwable paramThrowable);
/* 251:    */   }
/* 252:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.LogUtils
 * JD-Core Version:    0.7.0.1
 */