/*  1:   */ package com.lidroid.xutils.util;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class CharsetUtils
/*  7:   */ {
/*  8:   */   public static final String DEFAULT_ENCODING_CHARSET = "ISO-8859-1";
/*  9:   */   
/* 10:   */   public static String toCharset(String str, String charset, int judgeCharsetLength)
/* 11:   */   {
/* 12:   */     try
/* 13:   */     {
/* 14:37 */       String oldCharset = getEncoding(str, judgeCharsetLength);
/* 15:38 */       return new String(str.getBytes(oldCharset), charset);
/* 16:   */     }
/* 17:   */     catch (Throwable ex)
/* 18:   */     {
/* 19:41 */       LogUtils.w(ex);
/* 20:   */     }
/* 21:42 */     return str;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static String getEncoding(String str, int judgeCharsetLength)
/* 25:   */   {
/* 26:48 */     String encode = "ISO-8859-1";
/* 27:49 */     for (String charset : SUPPORT_CHARSET) {
/* 28:51 */       if (isCharset(str, charset, judgeCharsetLength))
/* 29:   */       {
/* 30:53 */         encode = charset;
/* 31:54 */         break;
/* 32:   */       }
/* 33:   */     }
/* 34:57 */     return encode;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static boolean isCharset(String str, String charset, int judgeCharsetLength)
/* 38:   */   {
/* 39:   */     try
/* 40:   */     {
/* 41:64 */       String temp = str.length() > judgeCharsetLength ? str.substring(0, judgeCharsetLength) : str;
/* 42:65 */       return temp.equals(new String(temp.getBytes(charset), charset));
/* 43:   */     }
/* 44:   */     catch (Throwable e) {}
/* 45:68 */     return false;
/* 46:   */   }
/* 47:   */   
/* 48:74 */   public static final List<String> SUPPORT_CHARSET = new ArrayList();
/* 49:   */   
/* 50:   */   static
/* 51:   */   {
/* 52:78 */     SUPPORT_CHARSET.add("ISO-8859-1");
/* 53:   */     
/* 54:80 */     SUPPORT_CHARSET.add("GB2312");
/* 55:81 */     SUPPORT_CHARSET.add("GBK");
/* 56:82 */     SUPPORT_CHARSET.add("GB18030");
/* 57:   */     
/* 58:84 */     SUPPORT_CHARSET.add("US-ASCII");
/* 59:85 */     SUPPORT_CHARSET.add("ASCII");
/* 60:   */     
/* 61:87 */     SUPPORT_CHARSET.add("ISO-2022-KR");
/* 62:   */     
/* 63:89 */     SUPPORT_CHARSET.add("ISO-8859-2");
/* 64:   */     
/* 65:91 */     SUPPORT_CHARSET.add("ISO-2022-JP");
/* 66:92 */     SUPPORT_CHARSET.add("ISO-2022-JP-2");
/* 67:   */     
/* 68:94 */     SUPPORT_CHARSET.add("UTF-8");
/* 69:   */   }
/* 70:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.CharsetUtils
 * JD-Core Version:    0.7.0.1
 */