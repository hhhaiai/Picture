/*   1:    */ package com.lidroid.xutils.util;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.SharedPreferences;
/*   5:    */ import android.content.SharedPreferences.Editor;
/*   6:    */ import android.text.TextUtils;
/*   7:    */ import java.io.ByteArrayInputStream;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.ObjectInputStream;
/*  11:    */ import java.io.ObjectOutputStream;
/*  12:    */ import java.io.Serializable;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Date;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.Map.Entry;
/*  17:    */ import java.util.concurrent.ConcurrentHashMap;
/*  18:    */ import org.apache.http.client.CookieStore;
/*  19:    */ import org.apache.http.cookie.Cookie;
/*  20:    */ import org.apache.http.impl.cookie.BasicClientCookie;
/*  21:    */ 
/*  22:    */ public class PreferencesCookieStore
/*  23:    */   implements CookieStore
/*  24:    */ {
/*  25:    */   private static final String COOKIE_PREFS = "CookiePrefsFile";
/*  26:    */   private static final String COOKIE_NAME_STORE = "names";
/*  27:    */   private static final String COOKIE_NAME_PREFIX = "cookie_";
/*  28:    */   private final ConcurrentHashMap<String, Cookie> cookies;
/*  29:    */   private final SharedPreferences cookiePrefs;
/*  30:    */   
/*  31:    */   public PreferencesCookieStore(Context context)
/*  32:    */   {
/*  33: 51 */     this.cookiePrefs = context.getSharedPreferences("CookiePrefsFile", 0);
/*  34: 52 */     this.cookies = new ConcurrentHashMap();
/*  35:    */     
/*  36:    */ 
/*  37: 55 */     String storedCookieNames = this.cookiePrefs.getString("names", null);
/*  38: 56 */     if (storedCookieNames != null)
/*  39:    */     {
/*  40: 58 */       String[] cookieNames = TextUtils.split(storedCookieNames, ",");
/*  41: 59 */       for (String name : cookieNames)
/*  42:    */       {
/*  43: 61 */         String encodedCookie = this.cookiePrefs.getString("cookie_" + name, null);
/*  44: 62 */         if (encodedCookie != null)
/*  45:    */         {
/*  46: 64 */           Cookie decodedCookie = decodeCookie(encodedCookie);
/*  47: 65 */           if (decodedCookie != null) {
/*  48: 67 */             this.cookies.put(name, decodedCookie);
/*  49:    */           }
/*  50:    */         }
/*  51:    */       }
/*  52: 73 */       clearExpired(new Date());
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void addCookie(Cookie cookie)
/*  57:    */   {
/*  58: 80 */     String name = cookie.getName();
/*  59: 83 */     if (!cookie.isExpired(new Date())) {
/*  60: 85 */       this.cookies.put(name, cookie);
/*  61:    */     } else {
/*  62: 88 */       this.cookies.remove(name);
/*  63:    */     }
/*  64: 92 */     SharedPreferences.Editor editor = this.cookiePrefs.edit();
/*  65: 93 */     editor.putString("names", TextUtils.join(",", this.cookies.keySet()));
/*  66: 94 */     editor.putString("cookie_" + name, encodeCookie(new SerializableCookie(cookie)));
/*  67: 95 */     editor.commit();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void clear()
/*  71:    */   {
/*  72:102 */     SharedPreferences.Editor editor = this.cookiePrefs.edit();
/*  73:103 */     for (String name : this.cookies.keySet()) {
/*  74:105 */       editor.remove("cookie_" + name);
/*  75:    */     }
/*  76:107 */     editor.remove("names");
/*  77:108 */     editor.commit();
/*  78:    */     
/*  79:    */ 
/*  80:111 */     this.cookies.clear();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean clearExpired(Date date)
/*  84:    */   {
/*  85:117 */     boolean clearedAny = false;
/*  86:118 */     SharedPreferences.Editor editor = this.cookiePrefs.edit();
/*  87:120 */     for (Map.Entry<String, Cookie> entry : this.cookies.entrySet())
/*  88:    */     {
/*  89:122 */       String name = (String)entry.getKey();
/*  90:123 */       Cookie cookie = (Cookie)entry.getValue();
/*  91:124 */       if ((cookie.getExpiryDate() == null) || (cookie.isExpired(date)))
/*  92:    */       {
/*  93:127 */         this.cookies.remove(name);
/*  94:    */         
/*  95:    */ 
/*  96:130 */         editor.remove("cookie_" + name);
/*  97:    */         
/*  98:    */ 
/*  99:133 */         clearedAny = true;
/* 100:    */       }
/* 101:    */     }
/* 102:138 */     if (clearedAny) {
/* 103:140 */       editor.putString("names", TextUtils.join(",", this.cookies.keySet()));
/* 104:    */     }
/* 105:142 */     editor.commit();
/* 106:    */     
/* 107:144 */     return clearedAny;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public List<Cookie> getCookies()
/* 111:    */   {
/* 112:150 */     return new ArrayList(this.cookies.values());
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Cookie getCookie(String name)
/* 116:    */   {
/* 117:155 */     return (Cookie)this.cookies.get(name);
/* 118:    */   }
/* 119:    */   
/* 120:    */   protected String encodeCookie(SerializableCookie cookie)
/* 121:    */   {
/* 122:160 */     ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 123:    */     try
/* 124:    */     {
/* 125:163 */       ObjectOutputStream outputStream = new ObjectOutputStream(os);
/* 126:164 */       outputStream.writeObject(cookie);
/* 127:    */     }
/* 128:    */     catch (Throwable e)
/* 129:    */     {
/* 130:167 */       return null;
/* 131:    */     }
/* 132:170 */     return byteArrayToHexString(os.toByteArray());
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected Cookie decodeCookie(String cookieStr)
/* 136:    */   {
/* 137:175 */     byte[] bytes = hexStringToByteArray(cookieStr);
/* 138:176 */     ByteArrayInputStream is = new ByteArrayInputStream(bytes);
/* 139:177 */     Cookie cookie = null;
/* 140:    */     try
/* 141:    */     {
/* 142:180 */       ObjectInputStream ois = new ObjectInputStream(is);
/* 143:181 */       cookie = ((SerializableCookie)ois.readObject()).getCookie();
/* 144:    */     }
/* 145:    */     catch (Throwable e)
/* 146:    */     {
/* 147:184 */       LogUtils.e(e.getMessage(), e);
/* 148:    */     }
/* 149:187 */     return cookie;
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected String byteArrayToHexString(byte[] b)
/* 153:    */   {
/* 154:194 */     StringBuffer sb = new StringBuffer(b.length * 2);
/* 155:195 */     for (byte element : b)
/* 156:    */     {
/* 157:197 */       int v = element & 0xFF;
/* 158:198 */       if (v < 16) {
/* 159:200 */         sb.append('0');
/* 160:    */       }
/* 161:202 */       sb.append(Integer.toHexString(v));
/* 162:    */     }
/* 163:204 */     return sb.toString().toUpperCase();
/* 164:    */   }
/* 165:    */   
/* 166:    */   protected byte[] hexStringToByteArray(String s)
/* 167:    */   {
/* 168:209 */     int len = s.length();
/* 169:210 */     byte[] data = new byte[len / 2];
/* 170:211 */     for (int i = 0; i < len; i += 2) {
/* 171:213 */       data[(i / 2)] = ((byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16)));
/* 172:    */     }
/* 173:215 */     return data;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public class SerializableCookie
/* 177:    */     implements Serializable
/* 178:    */   {
/* 179:    */     private static final long serialVersionUID = 6374381828722046732L;
/* 180:    */     private final transient Cookie cookie;
/* 181:    */     private transient BasicClientCookie clientCookie;
/* 182:    */     
/* 183:    */     public SerializableCookie(Cookie cookie)
/* 184:    */     {
/* 185:227 */       this.cookie = cookie;
/* 186:    */     }
/* 187:    */     
/* 188:    */     public Cookie getCookie()
/* 189:    */     {
/* 190:232 */       Cookie bestCookie = this.cookie;
/* 191:233 */       if (this.clientCookie != null) {
/* 192:235 */         bestCookie = this.clientCookie;
/* 193:    */       }
/* 194:237 */       return bestCookie;
/* 195:    */     }
/* 196:    */     
/* 197:    */     private void writeObject(ObjectOutputStream out)
/* 198:    */       throws IOException
/* 199:    */     {
/* 200:242 */       out.writeObject(this.cookie.getName());
/* 201:243 */       out.writeObject(this.cookie.getValue());
/* 202:244 */       out.writeObject(this.cookie.getComment());
/* 203:245 */       out.writeObject(this.cookie.getDomain());
/* 204:246 */       out.writeObject(this.cookie.getExpiryDate());
/* 205:247 */       out.writeObject(this.cookie.getPath());
/* 206:248 */       out.writeInt(this.cookie.getVersion());
/* 207:249 */       out.writeBoolean(this.cookie.isSecure());
/* 208:    */     }
/* 209:    */     
/* 210:    */     private void readObject(ObjectInputStream in)
/* 211:    */       throws IOException, ClassNotFoundException
/* 212:    */     {
/* 213:254 */       String name = (String)in.readObject();
/* 214:255 */       String value = (String)in.readObject();
/* 215:256 */       this.clientCookie = new BasicClientCookie(name, value);
/* 216:257 */       this.clientCookie.setComment((String)in.readObject());
/* 217:258 */       this.clientCookie.setDomain((String)in.readObject());
/* 218:259 */       this.clientCookie.setExpiryDate((Date)in.readObject());
/* 219:260 */       this.clientCookie.setPath((String)in.readObject());
/* 220:261 */       this.clientCookie.setVersion(in.readInt());
/* 221:262 */       this.clientCookie.setSecure(in.readBoolean());
/* 222:    */     }
/* 223:    */   }
/* 224:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.util.PreferencesCookieStore
 * JD-Core Version:    0.7.0.1
 */