/*    1:     */ package com.lidroid.xutils;
/*    2:     */ 
/*    3:     */ import android.content.Context;
/*    4:     */ import android.database.Cursor;
/*    5:     */ import android.database.sqlite.SQLiteDatabase;
/*    6:     */ import android.text.TextUtils;
/*    7:     */ import com.lidroid.xutils.db.sqlite.CursorUtils;
/*    8:     */ import com.lidroid.xutils.db.sqlite.CursorUtils.FindCacheSequence;
/*    9:     */ import com.lidroid.xutils.db.sqlite.DbModelSelector;
/*   10:     */ import com.lidroid.xutils.db.sqlite.Selector;
/*   11:     */ import com.lidroid.xutils.db.sqlite.SqlInfo;
/*   12:     */ import com.lidroid.xutils.db.sqlite.SqlInfoBuilder;
/*   13:     */ import com.lidroid.xutils.db.sqlite.WhereBuilder;
/*   14:     */ import com.lidroid.xutils.db.table.DbModel;
/*   15:     */ import com.lidroid.xutils.db.table.Id;
/*   16:     */ import com.lidroid.xutils.db.table.Table;
/*   17:     */ import com.lidroid.xutils.db.table.TableUtils;
/*   18:     */ import com.lidroid.xutils.exception.DbException;
/*   19:     */ import com.lidroid.xutils.util.IOUtils;
/*   20:     */ import com.lidroid.xutils.util.LogUtils;
/*   21:     */ import java.io.File;
/*   22:     */ import java.util.ArrayList;
/*   23:     */ import java.util.HashMap;
/*   24:     */ import java.util.List;
/*   25:     */ import java.util.concurrent.ConcurrentHashMap;
/*   26:     */ import java.util.concurrent.locks.Lock;
/*   27:     */ import java.util.concurrent.locks.ReentrantLock;
/*   28:     */ 
/*   29:     */ public class DbUtils
/*   30:     */ {
/*   31:  48 */   private static HashMap<String, DbUtils> daoMap = new HashMap();
/*   32:     */   private SQLiteDatabase database;
/*   33:     */   private DaoConfig daoConfig;
/*   34:  52 */   private boolean debug = false;
/*   35:  53 */   private boolean allowTransaction = false;
/*   36:     */   
/*   37:     */   private DbUtils(DaoConfig config)
/*   38:     */   {
/*   39:  57 */     if (config == null) {
/*   40:  59 */       throw new IllegalArgumentException("daoConfig may not be null");
/*   41:     */     }
/*   42:  61 */     this.database = createDatabase(config);
/*   43:  62 */     this.daoConfig = config;
/*   44:     */   }
/*   45:     */   
/*   46:     */   private static synchronized DbUtils getInstance(DaoConfig daoConfig)
/*   47:     */   {
/*   48:  67 */     DbUtils dao = (DbUtils)daoMap.get(daoConfig.getDbName());
/*   49:  68 */     if (dao == null)
/*   50:     */     {
/*   51:  70 */       dao = new DbUtils(daoConfig);
/*   52:  71 */       daoMap.put(daoConfig.getDbName(), dao);
/*   53:     */     }
/*   54:     */     else
/*   55:     */     {
/*   56:  74 */       dao.daoConfig = daoConfig;
/*   57:     */     }
/*   58:  78 */     SQLiteDatabase database = dao.database;
/*   59:  79 */     int oldVersion = database.getVersion();
/*   60:  80 */     int newVersion = daoConfig.getDbVersion();
/*   61:  81 */     if (oldVersion != newVersion)
/*   62:     */     {
/*   63:  83 */       if (oldVersion != 0)
/*   64:     */       {
/*   65:  85 */         DbUpgradeListener upgradeListener = daoConfig.getDbUpgradeListener();
/*   66:  86 */         if (upgradeListener != null) {
/*   67:  88 */           upgradeListener.onUpgrade(dao, oldVersion, newVersion);
/*   68:     */         } else {
/*   69:     */           try
/*   70:     */           {
/*   71:  93 */             dao.dropDb();
/*   72:     */           }
/*   73:     */           catch (DbException e)
/*   74:     */           {
/*   75:  96 */             LogUtils.e(e.getMessage(), e);
/*   76:     */           }
/*   77:     */         }
/*   78:     */       }
/*   79: 100 */       database.setVersion(newVersion);
/*   80:     */     }
/*   81: 103 */     return dao;
/*   82:     */   }
/*   83:     */   
/*   84:     */   public static DbUtils create(Context context)
/*   85:     */   {
/*   86: 108 */     DaoConfig config = new DaoConfig(context);
/*   87: 109 */     return getInstance(config);
/*   88:     */   }
/*   89:     */   
/*   90:     */   public static DbUtils create(Context context, String dbName)
/*   91:     */   {
/*   92: 114 */     DaoConfig config = new DaoConfig(context);
/*   93: 115 */     config.setDbName(dbName);
/*   94: 116 */     return getInstance(config);
/*   95:     */   }
/*   96:     */   
/*   97:     */   public static DbUtils create(Context context, String dbDir, String dbName)
/*   98:     */   {
/*   99: 121 */     DaoConfig config = new DaoConfig(context);
/*  100: 122 */     config.setDbDir(dbDir);
/*  101: 123 */     config.setDbName(dbName);
/*  102: 124 */     return getInstance(config);
/*  103:     */   }
/*  104:     */   
/*  105:     */   public static DbUtils create(Context context, String dbName, int dbVersion, DbUpgradeListener dbUpgradeListener)
/*  106:     */   {
/*  107: 129 */     DaoConfig config = new DaoConfig(context);
/*  108: 130 */     config.setDbName(dbName);
/*  109: 131 */     config.setDbVersion(dbVersion);
/*  110: 132 */     config.setDbUpgradeListener(dbUpgradeListener);
/*  111: 133 */     return getInstance(config);
/*  112:     */   }
/*  113:     */   
/*  114:     */   public static DbUtils create(Context context, String dbDir, String dbName, int dbVersion, DbUpgradeListener dbUpgradeListener)
/*  115:     */   {
/*  116: 138 */     DaoConfig config = new DaoConfig(context);
/*  117: 139 */     config.setDbDir(dbDir);
/*  118: 140 */     config.setDbName(dbName);
/*  119: 141 */     config.setDbVersion(dbVersion);
/*  120: 142 */     config.setDbUpgradeListener(dbUpgradeListener);
/*  121: 143 */     return getInstance(config);
/*  122:     */   }
/*  123:     */   
/*  124:     */   public static DbUtils create(DaoConfig daoConfig)
/*  125:     */   {
/*  126: 148 */     return getInstance(daoConfig);
/*  127:     */   }
/*  128:     */   
/*  129:     */   public DbUtils configDebug(boolean debug)
/*  130:     */   {
/*  131: 153 */     this.debug = debug;
/*  132: 154 */     return this;
/*  133:     */   }
/*  134:     */   
/*  135:     */   public DbUtils configAllowTransaction(boolean allowTransaction)
/*  136:     */   {
/*  137: 159 */     this.allowTransaction = allowTransaction;
/*  138: 160 */     return this;
/*  139:     */   }
/*  140:     */   
/*  141:     */   public SQLiteDatabase getDatabase()
/*  142:     */   {
/*  143: 165 */     return this.database;
/*  144:     */   }
/*  145:     */   
/*  146:     */   public DaoConfig getDaoConfig()
/*  147:     */   {
/*  148: 170 */     return this.daoConfig;
/*  149:     */   }
/*  150:     */   
/*  151:     */   public void saveOrUpdate(Object entity)
/*  152:     */     throws DbException
/*  153:     */   {
/*  154:     */     try
/*  155:     */     {
/*  156: 180 */       beginTransaction();
/*  157:     */       
/*  158: 182 */       createTableIfNotExist(entity.getClass());
/*  159: 183 */       saveOrUpdateWithoutTransaction(entity);
/*  160:     */       
/*  161: 185 */       setTransactionSuccessful();
/*  162:     */     }
/*  163:     */     finally
/*  164:     */     {
/*  165: 188 */       endTransaction();
/*  166:     */     }
/*  167:     */   }
/*  168:     */   
/*  169:     */   public void saveOrUpdateAll(List<?> entities)
/*  170:     */     throws DbException
/*  171:     */   {
/*  172: 194 */     if ((entities == null) || (entities.size() == 0)) {
/*  173: 195 */       return;
/*  174:     */     }
/*  175:     */     try
/*  176:     */     {
/*  177: 198 */       beginTransaction();
/*  178:     */       
/*  179: 200 */       createTableIfNotExist(entities.get(0).getClass());
/*  180: 201 */       for (Object entity : entities) {
/*  181: 203 */         saveOrUpdateWithoutTransaction(entity);
/*  182:     */       }
/*  183: 206 */       setTransactionSuccessful();
/*  184:     */     }
/*  185:     */     finally
/*  186:     */     {
/*  187: 209 */       endTransaction();
/*  188:     */     }
/*  189:     */   }
/*  190:     */   
/*  191:     */   public void replace(Object entity)
/*  192:     */     throws DbException
/*  193:     */   {
/*  194:     */     try
/*  195:     */     {
/*  196: 217 */       beginTransaction();
/*  197:     */       
/*  198: 219 */       createTableIfNotExist(entity.getClass());
/*  199: 220 */       execNonQuery(SqlInfoBuilder.buildReplaceSqlInfo(this, entity));
/*  200:     */       
/*  201: 222 */       setTransactionSuccessful();
/*  202:     */     }
/*  203:     */     finally
/*  204:     */     {
/*  205: 225 */       endTransaction();
/*  206:     */     }
/*  207:     */   }
/*  208:     */   
/*  209:     */   public void replaceAll(List<?> entities)
/*  210:     */     throws DbException
/*  211:     */   {
/*  212: 231 */     if ((entities == null) || (entities.size() == 0)) {
/*  213: 232 */       return;
/*  214:     */     }
/*  215:     */     try
/*  216:     */     {
/*  217: 235 */       beginTransaction();
/*  218:     */       
/*  219: 237 */       createTableIfNotExist(entities.get(0).getClass());
/*  220: 238 */       for (Object entity : entities) {
/*  221: 240 */         execNonQuery(SqlInfoBuilder.buildReplaceSqlInfo(this, entity));
/*  222:     */       }
/*  223: 243 */       setTransactionSuccessful();
/*  224:     */     }
/*  225:     */     finally
/*  226:     */     {
/*  227: 246 */       endTransaction();
/*  228:     */     }
/*  229:     */   }
/*  230:     */   
/*  231:     */   public void save(Object entity)
/*  232:     */     throws DbException
/*  233:     */   {
/*  234:     */     try
/*  235:     */     {
/*  236: 254 */       beginTransaction();
/*  237:     */       
/*  238: 256 */       createTableIfNotExist(entity.getClass());
/*  239: 257 */       execNonQuery(SqlInfoBuilder.buildInsertSqlInfo(this, entity));
/*  240:     */       
/*  241: 259 */       setTransactionSuccessful();
/*  242:     */     }
/*  243:     */     finally
/*  244:     */     {
/*  245: 262 */       endTransaction();
/*  246:     */     }
/*  247:     */   }
/*  248:     */   
/*  249:     */   public void saveAll(List<?> entities)
/*  250:     */     throws DbException
/*  251:     */   {
/*  252: 268 */     if ((entities == null) || (entities.size() == 0)) {
/*  253: 269 */       return;
/*  254:     */     }
/*  255:     */     try
/*  256:     */     {
/*  257: 272 */       beginTransaction();
/*  258:     */       
/*  259: 274 */       createTableIfNotExist(entities.get(0).getClass());
/*  260: 275 */       for (Object entity : entities) {
/*  261: 277 */         execNonQuery(SqlInfoBuilder.buildInsertSqlInfo(this, entity));
/*  262:     */       }
/*  263: 280 */       setTransactionSuccessful();
/*  264:     */     }
/*  265:     */     finally
/*  266:     */     {
/*  267: 283 */       endTransaction();
/*  268:     */     }
/*  269:     */   }
/*  270:     */   
/*  271:     */   public boolean saveBindingId(Object entity)
/*  272:     */     throws DbException
/*  273:     */   {
/*  274: 289 */     boolean result = false;
/*  275:     */     try
/*  276:     */     {
/*  277: 292 */       beginTransaction();
/*  278:     */       
/*  279: 294 */       createTableIfNotExist(entity.getClass());
/*  280: 295 */       result = saveBindingIdWithoutTransaction(entity);
/*  281:     */       
/*  282: 297 */       setTransactionSuccessful();
/*  283:     */     }
/*  284:     */     finally
/*  285:     */     {
/*  286: 300 */       endTransaction();
/*  287:     */     }
/*  288: 302 */     return result;
/*  289:     */   }
/*  290:     */   
/*  291:     */   public void saveBindingIdAll(List<?> entities)
/*  292:     */     throws DbException
/*  293:     */   {
/*  294: 307 */     if ((entities == null) || (entities.size() == 0)) {
/*  295: 308 */       return;
/*  296:     */     }
/*  297:     */     try
/*  298:     */     {
/*  299: 311 */       beginTransaction();
/*  300:     */       
/*  301: 313 */       createTableIfNotExist(entities.get(0).getClass());
/*  302: 314 */       for (Object entity : entities) {
/*  303: 316 */         if (!saveBindingIdWithoutTransaction(entity)) {
/*  304: 318 */           throw new DbException("saveBindingId error, transaction will not commit!");
/*  305:     */         }
/*  306:     */       }
/*  307: 322 */       setTransactionSuccessful();
/*  308:     */     }
/*  309:     */     finally
/*  310:     */     {
/*  311: 325 */       endTransaction();
/*  312:     */     }
/*  313:     */   }
/*  314:     */   
/*  315:     */   public void deleteById(Class<?> entityType, Object idValue)
/*  316:     */     throws DbException
/*  317:     */   {
/*  318: 331 */     if (!tableIsExist(entityType)) {
/*  319: 332 */       return;
/*  320:     */     }
/*  321:     */     try
/*  322:     */     {
/*  323: 335 */       beginTransaction();
/*  324:     */       
/*  325: 337 */       execNonQuery(SqlInfoBuilder.buildDeleteSqlInfo(this, entityType, idValue));
/*  326:     */       
/*  327: 339 */       setTransactionSuccessful();
/*  328:     */     }
/*  329:     */     finally
/*  330:     */     {
/*  331: 342 */       endTransaction();
/*  332:     */     }
/*  333:     */   }
/*  334:     */   
/*  335:     */   public void delete(Object entity)
/*  336:     */     throws DbException
/*  337:     */   {
/*  338: 348 */     if (!tableIsExist(entity.getClass())) {
/*  339: 349 */       return;
/*  340:     */     }
/*  341:     */     try
/*  342:     */     {
/*  343: 352 */       beginTransaction();
/*  344:     */       
/*  345: 354 */       execNonQuery(SqlInfoBuilder.buildDeleteSqlInfo(this, entity));
/*  346:     */       
/*  347: 356 */       setTransactionSuccessful();
/*  348:     */     }
/*  349:     */     finally
/*  350:     */     {
/*  351: 359 */       endTransaction();
/*  352:     */     }
/*  353:     */   }
/*  354:     */   
/*  355:     */   public void delete(Class<?> entityType, WhereBuilder whereBuilder)
/*  356:     */     throws DbException
/*  357:     */   {
/*  358: 365 */     if (!tableIsExist(entityType)) {
/*  359: 366 */       return;
/*  360:     */     }
/*  361:     */     try
/*  362:     */     {
/*  363: 369 */       beginTransaction();
/*  364:     */       
/*  365: 371 */       execNonQuery(SqlInfoBuilder.buildDeleteSqlInfo(this, entityType, whereBuilder));
/*  366:     */       
/*  367: 373 */       setTransactionSuccessful();
/*  368:     */     }
/*  369:     */     finally
/*  370:     */     {
/*  371: 376 */       endTransaction();
/*  372:     */     }
/*  373:     */   }
/*  374:     */   
/*  375:     */   public void deleteAll(List<?> entities)
/*  376:     */     throws DbException
/*  377:     */   {
/*  378: 382 */     if ((entities == null) || (entities.size() == 0) || (!tableIsExist(entities.get(0).getClass()))) {
/*  379: 383 */       return;
/*  380:     */     }
/*  381:     */     try
/*  382:     */     {
/*  383: 386 */       beginTransaction();
/*  384: 388 */       for (Object entity : entities) {
/*  385: 390 */         execNonQuery(SqlInfoBuilder.buildDeleteSqlInfo(this, entity));
/*  386:     */       }
/*  387: 393 */       setTransactionSuccessful();
/*  388:     */     }
/*  389:     */     finally
/*  390:     */     {
/*  391: 396 */       endTransaction();
/*  392:     */     }
/*  393:     */   }
/*  394:     */   
/*  395:     */   public void deleteAll(Class<?> entityType)
/*  396:     */     throws DbException
/*  397:     */   {
/*  398: 402 */     delete(entityType, null);
/*  399:     */   }
/*  400:     */   
/*  401:     */   public void update(Object entity, String... updateColumnNames)
/*  402:     */     throws DbException
/*  403:     */   {
/*  404: 407 */     if (!tableIsExist(entity.getClass())) {
/*  405: 408 */       return;
/*  406:     */     }
/*  407:     */     try
/*  408:     */     {
/*  409: 411 */       beginTransaction();
/*  410:     */       
/*  411: 413 */       execNonQuery(SqlInfoBuilder.buildUpdateSqlInfo(this, entity, updateColumnNames));
/*  412:     */       
/*  413: 415 */       setTransactionSuccessful();
/*  414:     */     }
/*  415:     */     finally
/*  416:     */     {
/*  417: 418 */       endTransaction();
/*  418:     */     }
/*  419:     */   }
/*  420:     */   
/*  421:     */   public void update(Object entity, WhereBuilder whereBuilder, String... updateColumnNames)
/*  422:     */     throws DbException
/*  423:     */   {
/*  424: 424 */     if (!tableIsExist(entity.getClass())) {
/*  425: 425 */       return;
/*  426:     */     }
/*  427:     */     try
/*  428:     */     {
/*  429: 428 */       beginTransaction();
/*  430:     */       
/*  431: 430 */       execNonQuery(SqlInfoBuilder.buildUpdateSqlInfo(this, entity, whereBuilder, updateColumnNames));
/*  432:     */       
/*  433: 432 */       setTransactionSuccessful();
/*  434:     */     }
/*  435:     */     finally
/*  436:     */     {
/*  437: 435 */       endTransaction();
/*  438:     */     }
/*  439:     */   }
/*  440:     */   
/*  441:     */   public void updateAll(List<?> entities, String... updateColumnNames)
/*  442:     */     throws DbException
/*  443:     */   {
/*  444: 441 */     if ((entities == null) || (entities.size() == 0) || (!tableIsExist(entities.get(0).getClass()))) {
/*  445: 442 */       return;
/*  446:     */     }
/*  447:     */     try
/*  448:     */     {
/*  449: 445 */       beginTransaction();
/*  450: 447 */       for (Object entity : entities) {
/*  451: 449 */         execNonQuery(SqlInfoBuilder.buildUpdateSqlInfo(this, entity, updateColumnNames));
/*  452:     */       }
/*  453: 452 */       setTransactionSuccessful();
/*  454:     */     }
/*  455:     */     finally
/*  456:     */     {
/*  457: 455 */       endTransaction();
/*  458:     */     }
/*  459:     */   }
/*  460:     */   
/*  461:     */   public void updateAll(List<?> entities, WhereBuilder whereBuilder, String... updateColumnNames)
/*  462:     */     throws DbException
/*  463:     */   {
/*  464: 461 */     if ((entities == null) || (entities.size() == 0) || (!tableIsExist(entities.get(0).getClass()))) {
/*  465: 462 */       return;
/*  466:     */     }
/*  467:     */     try
/*  468:     */     {
/*  469: 465 */       beginTransaction();
/*  470: 467 */       for (Object entity : entities) {
/*  471: 469 */         execNonQuery(SqlInfoBuilder.buildUpdateSqlInfo(this, entity, whereBuilder, updateColumnNames));
/*  472:     */       }
/*  473: 472 */       setTransactionSuccessful();
/*  474:     */     }
/*  475:     */     finally
/*  476:     */     {
/*  477: 475 */       endTransaction();
/*  478:     */     }
/*  479:     */   }
/*  480:     */   
/*  481:     */   public <T> T findById(Class<T> entityType, Object idValue)
/*  482:     */     throws DbException
/*  483:     */   {
/*  484: 482 */     if (!tableIsExist(entityType)) {
/*  485: 483 */       return null;
/*  486:     */     }
/*  487: 485 */     Table table = Table.get(this, entityType);
/*  488: 486 */     Selector selector = Selector.from(entityType).where(table.id.getColumnName(), "=", idValue);
/*  489:     */     
/*  490: 488 */     String sql = selector.limit(1).toString();
/*  491: 489 */     long seq = CursorUtils.FindCacheSequence.getSeq();
/*  492: 490 */     this.findTempCache.setSeq(seq);
/*  493: 491 */     Object obj = this.findTempCache.get(sql);
/*  494: 492 */     if (obj != null) {
/*  495: 494 */       return obj;
/*  496:     */     }
/*  497: 497 */     Cursor cursor = execQuery(sql);
/*  498: 498 */     if (cursor != null)
/*  499:     */     {
/*  500:     */       try
/*  501:     */       {
/*  502: 502 */         if (cursor.moveToNext())
/*  503:     */         {
/*  504: 504 */           T entity = CursorUtils.getEntity(this, cursor, entityType, seq);
/*  505: 505 */           this.findTempCache.put(sql, entity);
/*  506: 506 */           return entity;
/*  507:     */         }
/*  508:     */       }
/*  509:     */       catch (Throwable e)
/*  510:     */       {
/*  511: 510 */         throw new DbException(e);
/*  512:     */       }
/*  513:     */       finally
/*  514:     */       {
/*  515: 513 */         IOUtils.closeQuietly(cursor);
/*  516:     */       }
/*  517: 513 */       IOUtils.closeQuietly(cursor);
/*  518:     */     }
/*  519: 516 */     return null;
/*  520:     */   }
/*  521:     */   
/*  522:     */   public <T> T findFirst(Selector selector)
/*  523:     */     throws DbException
/*  524:     */   {
/*  525: 522 */     if (!tableIsExist(selector.getEntityType())) {
/*  526: 523 */       return null;
/*  527:     */     }
/*  528: 525 */     String sql = selector.limit(1).toString();
/*  529: 526 */     long seq = CursorUtils.FindCacheSequence.getSeq();
/*  530: 527 */     this.findTempCache.setSeq(seq);
/*  531: 528 */     Object obj = this.findTempCache.get(sql);
/*  532: 529 */     if (obj != null) {
/*  533: 531 */       return obj;
/*  534:     */     }
/*  535: 534 */     Cursor cursor = execQuery(sql);
/*  536: 535 */     if (cursor != null)
/*  537:     */     {
/*  538:     */       try
/*  539:     */       {
/*  540: 539 */         if (cursor.moveToNext())
/*  541:     */         {
/*  542: 541 */           T entity = CursorUtils.getEntity(this, cursor, selector.getEntityType(), seq);
/*  543: 542 */           this.findTempCache.put(sql, entity);
/*  544: 543 */           return entity;
/*  545:     */         }
/*  546:     */       }
/*  547:     */       catch (Throwable e)
/*  548:     */       {
/*  549: 547 */         throw new DbException(e);
/*  550:     */       }
/*  551:     */       finally
/*  552:     */       {
/*  553: 550 */         IOUtils.closeQuietly(cursor);
/*  554:     */       }
/*  555: 550 */       IOUtils.closeQuietly(cursor);
/*  556:     */     }
/*  557: 553 */     return null;
/*  558:     */   }
/*  559:     */   
/*  560:     */   public <T> T findFirst(Class<T> entityType)
/*  561:     */     throws DbException
/*  562:     */   {
/*  563: 558 */     return findFirst(Selector.from(entityType));
/*  564:     */   }
/*  565:     */   
/*  566:     */   public <T> List<T> findAll(Selector selector)
/*  567:     */     throws DbException
/*  568:     */   {
/*  569: 564 */     if (!tableIsExist(selector.getEntityType())) {
/*  570: 565 */       return null;
/*  571:     */     }
/*  572: 567 */     String sql = selector.toString();
/*  573: 568 */     long seq = CursorUtils.FindCacheSequence.getSeq();
/*  574: 569 */     this.findTempCache.setSeq(seq);
/*  575: 570 */     Object obj = this.findTempCache.get(sql);
/*  576: 571 */     if (obj != null) {
/*  577: 573 */       return (List)obj;
/*  578:     */     }
/*  579: 576 */     List<T> result = new ArrayList();
/*  580:     */     
/*  581: 578 */     Cursor cursor = execQuery(sql);
/*  582: 579 */     if (cursor != null) {
/*  583:     */       try
/*  584:     */       {
/*  585: 583 */         while (cursor.moveToNext())
/*  586:     */         {
/*  587: 585 */           T entity = CursorUtils.getEntity(this, cursor, selector.getEntityType(), seq);
/*  588: 586 */           result.add(entity);
/*  589:     */         }
/*  590: 588 */         this.findTempCache.put(sql, result);
/*  591:     */       }
/*  592:     */       catch (Throwable e)
/*  593:     */       {
/*  594: 591 */         throw new DbException(e);
/*  595:     */       }
/*  596:     */       finally
/*  597:     */       {
/*  598: 594 */         IOUtils.closeQuietly(cursor);
/*  599:     */       }
/*  600:     */     }
/*  601: 597 */     return result;
/*  602:     */   }
/*  603:     */   
/*  604:     */   public <T> List<T> findAll(Class<T> entityType)
/*  605:     */     throws DbException
/*  606:     */   {
/*  607: 602 */     return findAll(Selector.from(entityType));
/*  608:     */   }
/*  609:     */   
/*  610:     */   public DbModel findDbModelFirst(SqlInfo sqlInfo)
/*  611:     */     throws DbException
/*  612:     */   {
/*  613: 607 */     Cursor cursor = execQuery(sqlInfo);
/*  614: 608 */     if (cursor != null)
/*  615:     */     {
/*  616:     */       try
/*  617:     */       {
/*  618: 612 */         if (cursor.moveToNext()) {
/*  619: 614 */           return CursorUtils.getDbModel(cursor);
/*  620:     */         }
/*  621:     */       }
/*  622:     */       catch (Throwable e)
/*  623:     */       {
/*  624: 618 */         throw new DbException(e);
/*  625:     */       }
/*  626:     */       finally
/*  627:     */       {
/*  628: 621 */         IOUtils.closeQuietly(cursor);
/*  629:     */       }
/*  630: 621 */       IOUtils.closeQuietly(cursor);
/*  631:     */     }
/*  632: 624 */     return null;
/*  633:     */   }
/*  634:     */   
/*  635:     */   public DbModel findDbModelFirst(DbModelSelector selector)
/*  636:     */     throws DbException
/*  637:     */   {
/*  638: 629 */     if (!tableIsExist(selector.getEntityType())) {
/*  639: 630 */       return null;
/*  640:     */     }
/*  641: 632 */     Cursor cursor = execQuery(selector.limit(1).toString());
/*  642: 633 */     if (cursor != null)
/*  643:     */     {
/*  644:     */       try
/*  645:     */       {
/*  646: 637 */         if (cursor.moveToNext()) {
/*  647: 639 */           return CursorUtils.getDbModel(cursor);
/*  648:     */         }
/*  649:     */       }
/*  650:     */       catch (Throwable e)
/*  651:     */       {
/*  652: 643 */         throw new DbException(e);
/*  653:     */       }
/*  654:     */       finally
/*  655:     */       {
/*  656: 646 */         IOUtils.closeQuietly(cursor);
/*  657:     */       }
/*  658: 646 */       IOUtils.closeQuietly(cursor);
/*  659:     */     }
/*  660: 649 */     return null;
/*  661:     */   }
/*  662:     */   
/*  663:     */   public List<DbModel> findDbModelAll(SqlInfo sqlInfo)
/*  664:     */     throws DbException
/*  665:     */   {
/*  666: 654 */     List<DbModel> dbModelList = new ArrayList();
/*  667:     */     
/*  668: 656 */     Cursor cursor = execQuery(sqlInfo);
/*  669: 657 */     if (cursor != null) {
/*  670:     */       try
/*  671:     */       {
/*  672: 661 */         while (cursor.moveToNext()) {
/*  673: 663 */           dbModelList.add(CursorUtils.getDbModel(cursor));
/*  674:     */         }
/*  675:     */       }
/*  676:     */       catch (Throwable e)
/*  677:     */       {
/*  678: 667 */         throw new DbException(e);
/*  679:     */       }
/*  680:     */       finally
/*  681:     */       {
/*  682: 670 */         IOUtils.closeQuietly(cursor);
/*  683:     */       }
/*  684:     */     }
/*  685: 673 */     return dbModelList;
/*  686:     */   }
/*  687:     */   
/*  688:     */   public List<DbModel> findDbModelAll(DbModelSelector selector)
/*  689:     */     throws DbException
/*  690:     */   {
/*  691: 678 */     if (!tableIsExist(selector.getEntityType())) {
/*  692: 679 */       return null;
/*  693:     */     }
/*  694: 681 */     List<DbModel> dbModelList = new ArrayList();
/*  695:     */     
/*  696: 683 */     Cursor cursor = execQuery(selector.toString());
/*  697: 684 */     if (cursor != null) {
/*  698:     */       try
/*  699:     */       {
/*  700: 688 */         while (cursor.moveToNext()) {
/*  701: 690 */           dbModelList.add(CursorUtils.getDbModel(cursor));
/*  702:     */         }
/*  703:     */       }
/*  704:     */       catch (Throwable e)
/*  705:     */       {
/*  706: 694 */         throw new DbException(e);
/*  707:     */       }
/*  708:     */       finally
/*  709:     */       {
/*  710: 697 */         IOUtils.closeQuietly(cursor);
/*  711:     */       }
/*  712:     */     }
/*  713: 700 */     return dbModelList;
/*  714:     */   }
/*  715:     */   
/*  716:     */   public long count(Selector selector)
/*  717:     */     throws DbException
/*  718:     */   {
/*  719: 705 */     Class<?> entityType = selector.getEntityType();
/*  720: 706 */     if (!tableIsExist(entityType)) {
/*  721: 707 */       return 0L;
/*  722:     */     }
/*  723: 709 */     Table table = Table.get(this, entityType);
/*  724: 710 */     DbModelSelector dmSelector = selector.select(new String[] { "count(" + table.id.getColumnName() + ") as count" });
/*  725: 711 */     return findDbModelFirst(dmSelector).getLong("count");
/*  726:     */   }
/*  727:     */   
/*  728:     */   public long count(Class<?> entityType)
/*  729:     */     throws DbException
/*  730:     */   {
/*  731: 716 */     return count(Selector.from(entityType));
/*  732:     */   }
/*  733:     */   
/*  734:     */   public static class DaoConfig
/*  735:     */   {
/*  736:     */     private Context context;
/*  737: 725 */     private String dbName = "xUtils.db";
/*  738: 726 */     private int dbVersion = 1;
/*  739:     */     private DbUtils.DbUpgradeListener dbUpgradeListener;
/*  740:     */     private String dbDir;
/*  741:     */     
/*  742:     */     public DaoConfig(Context context)
/*  743:     */     {
/*  744: 733 */       this.context = context.getApplicationContext();
/*  745:     */     }
/*  746:     */     
/*  747:     */     public Context getContext()
/*  748:     */     {
/*  749: 738 */       return this.context;
/*  750:     */     }
/*  751:     */     
/*  752:     */     public String getDbName()
/*  753:     */     {
/*  754: 743 */       return this.dbName;
/*  755:     */     }
/*  756:     */     
/*  757:     */     public void setDbName(String dbName)
/*  758:     */     {
/*  759: 748 */       if (!TextUtils.isEmpty(dbName)) {
/*  760: 750 */         this.dbName = dbName;
/*  761:     */       }
/*  762:     */     }
/*  763:     */     
/*  764:     */     public int getDbVersion()
/*  765:     */     {
/*  766: 756 */       return this.dbVersion;
/*  767:     */     }
/*  768:     */     
/*  769:     */     public void setDbVersion(int dbVersion)
/*  770:     */     {
/*  771: 761 */       this.dbVersion = dbVersion;
/*  772:     */     }
/*  773:     */     
/*  774:     */     public DbUtils.DbUpgradeListener getDbUpgradeListener()
/*  775:     */     {
/*  776: 766 */       return this.dbUpgradeListener;
/*  777:     */     }
/*  778:     */     
/*  779:     */     public void setDbUpgradeListener(DbUtils.DbUpgradeListener dbUpgradeListener)
/*  780:     */     {
/*  781: 771 */       this.dbUpgradeListener = dbUpgradeListener;
/*  782:     */     }
/*  783:     */     
/*  784:     */     public String getDbDir()
/*  785:     */     {
/*  786: 776 */       return this.dbDir;
/*  787:     */     }
/*  788:     */     
/*  789:     */     public void setDbDir(String dbDir)
/*  790:     */     {
/*  791: 787 */       this.dbDir = dbDir;
/*  792:     */     }
/*  793:     */   }
/*  794:     */   
/*  795:     */   private SQLiteDatabase createDatabase(DaoConfig config)
/*  796:     */   {
/*  797: 798 */     SQLiteDatabase result = null;
/*  798:     */     
/*  799: 800 */     String dbDir = config.getDbDir();
/*  800: 801 */     if (!TextUtils.isEmpty(dbDir))
/*  801:     */     {
/*  802: 803 */       File dir = new File(dbDir);
/*  803: 804 */       if ((dir.exists()) || (dir.mkdirs()))
/*  804:     */       {
/*  805: 806 */         File dbFile = new File(dbDir, config.getDbName());
/*  806: 807 */         result = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
/*  807:     */       }
/*  808:     */     }
/*  809:     */     else
/*  810:     */     {
/*  811: 811 */       result = config.getContext().openOrCreateDatabase(config.getDbName(), 0, null);
/*  812:     */     }
/*  813: 813 */     return result;
/*  814:     */   }
/*  815:     */   
/*  816:     */   private void saveOrUpdateWithoutTransaction(Object entity)
/*  817:     */     throws DbException
/*  818:     */   {
/*  819: 820 */     Table table = Table.get(this, entity.getClass());
/*  820: 821 */     Id id = table.id;
/*  821: 822 */     if (id.isAutoIncrement())
/*  822:     */     {
/*  823: 824 */       if (id.getColumnValue(entity) != null) {
/*  824: 826 */         execNonQuery(SqlInfoBuilder.buildUpdateSqlInfo(this, entity, new String[0]));
/*  825:     */       } else {
/*  826: 829 */         saveBindingIdWithoutTransaction(entity);
/*  827:     */       }
/*  828:     */     }
/*  829:     */     else {
/*  830: 833 */       execNonQuery(SqlInfoBuilder.buildReplaceSqlInfo(this, entity));
/*  831:     */     }
/*  832:     */   }
/*  833:     */   
/*  834:     */   private boolean saveBindingIdWithoutTransaction(Object entity)
/*  835:     */     throws DbException
/*  836:     */   {
/*  837: 839 */     Class<?> entityType = entity.getClass();
/*  838: 840 */     Table table = Table.get(this, entityType);
/*  839: 841 */     Id idColumn = table.id;
/*  840: 842 */     if (idColumn.isAutoIncrement())
/*  841:     */     {
/*  842: 844 */       execNonQuery(SqlInfoBuilder.buildInsertSqlInfo(this, entity));
/*  843: 845 */       long id = getLastAutoIncrementId(table.tableName);
/*  844: 846 */       if (id == -1L) {
/*  845: 848 */         return false;
/*  846:     */       }
/*  847: 850 */       idColumn.setAutoIncrementId(entity, id);
/*  848: 851 */       return true;
/*  849:     */     }
/*  850: 854 */     execNonQuery(SqlInfoBuilder.buildInsertSqlInfo(this, entity));
/*  851: 855 */     return true;
/*  852:     */   }
/*  853:     */   
/*  854:     */   private long getLastAutoIncrementId(String tableName)
/*  855:     */     throws DbException
/*  856:     */   {
/*  857: 864 */     long id = -1L;
/*  858: 865 */     Cursor cursor = execQuery("SELECT seq FROM sqlite_sequence WHERE name='" + tableName + "'");
/*  859: 866 */     if (cursor != null) {
/*  860:     */       try
/*  861:     */       {
/*  862: 870 */         if (cursor.moveToNext()) {
/*  863: 872 */           id = cursor.getLong(0);
/*  864:     */         }
/*  865:     */       }
/*  866:     */       catch (Throwable e)
/*  867:     */       {
/*  868: 876 */         throw new DbException(e);
/*  869:     */       }
/*  870:     */       finally
/*  871:     */       {
/*  872: 879 */         IOUtils.closeQuietly(cursor);
/*  873:     */       }
/*  874:     */     }
/*  875: 882 */     return id;
/*  876:     */   }
/*  877:     */   
/*  878:     */   public void createTableIfNotExist(Class<?> entityType)
/*  879:     */     throws DbException
/*  880:     */   {
/*  881: 887 */     if (!tableIsExist(entityType))
/*  882:     */     {
/*  883: 889 */       SqlInfo sqlInfo = SqlInfoBuilder.buildCreateTableSqlInfo(this, entityType);
/*  884: 890 */       execNonQuery(sqlInfo);
/*  885: 891 */       String execAfterTableCreated = TableUtils.getExecAfterTableCreated(entityType);
/*  886: 892 */       if (!TextUtils.isEmpty(execAfterTableCreated)) {
/*  887: 894 */         execNonQuery(execAfterTableCreated);
/*  888:     */       }
/*  889:     */     }
/*  890:     */   }
/*  891:     */   
/*  892:     */   public boolean tableIsExist(Class<?> entityType)
/*  893:     */     throws DbException
/*  894:     */   {
/*  895: 901 */     Table table = Table.get(this, entityType);
/*  896: 902 */     if (table.isCheckedDatabase()) {
/*  897: 904 */       return true;
/*  898:     */     }
/*  899: 907 */     Cursor cursor = execQuery("SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table' AND name='" + table.tableName + "'");
/*  900: 908 */     if (cursor != null)
/*  901:     */     {
/*  902:     */       try
/*  903:     */       {
/*  904: 912 */         if (cursor.moveToNext())
/*  905:     */         {
/*  906: 914 */           int count = cursor.getInt(0);
/*  907: 915 */           if (count > 0)
/*  908:     */           {
/*  909: 917 */             table.setCheckedDatabase(true);
/*  910: 918 */             return true;
/*  911:     */           }
/*  912:     */         }
/*  913:     */       }
/*  914:     */       catch (Throwable e)
/*  915:     */       {
/*  916: 923 */         throw new DbException(e);
/*  917:     */       }
/*  918:     */       finally
/*  919:     */       {
/*  920: 926 */         IOUtils.closeQuietly(cursor);
/*  921:     */       }
/*  922: 926 */       IOUtils.closeQuietly(cursor);
/*  923:     */     }
/*  924: 930 */     return false;
/*  925:     */   }
/*  926:     */   
/*  927:     */   public void dropDb()
/*  928:     */     throws DbException
/*  929:     */   {
/*  930: 935 */     Cursor cursor = execQuery("SELECT name FROM sqlite_master WHERE type='table' AND name<>'sqlite_sequence'");
/*  931: 936 */     if (cursor != null) {
/*  932:     */       try
/*  933:     */       {
/*  934: 940 */         while (cursor.moveToNext()) {
/*  935:     */           try
/*  936:     */           {
/*  937: 944 */             String tableName = cursor.getString(0);
/*  938: 945 */             execNonQuery("DROP TABLE " + tableName);
/*  939: 946 */             Table.remove(this, tableName);
/*  940:     */           }
/*  941:     */           catch (Throwable e)
/*  942:     */           {
/*  943: 949 */             LogUtils.e(e.getMessage(), e);
/*  944:     */           }
/*  945:     */         }
/*  946:     */       }
/*  947:     */       catch (Throwable e)
/*  948:     */       {
/*  949: 955 */         throw new DbException(e);
/*  950:     */       }
/*  951:     */       finally
/*  952:     */       {
/*  953: 958 */         IOUtils.closeQuietly(cursor);
/*  954:     */       }
/*  955:     */     }
/*  956:     */   }
/*  957:     */   
/*  958:     */   public void dropTable(Class<?> entityType)
/*  959:     */     throws DbException
/*  960:     */   {
/*  961: 965 */     if (!tableIsExist(entityType)) {
/*  962: 966 */       return;
/*  963:     */     }
/*  964: 967 */     String tableName = TableUtils.getTableName(entityType);
/*  965: 968 */     execNonQuery("DROP TABLE " + tableName);
/*  966: 969 */     Table.remove(this, entityType);
/*  967:     */   }
/*  968:     */   
/*  969:     */   public void close()
/*  970:     */   {
/*  971: 974 */     String dbName = this.daoConfig.getDbName();
/*  972: 975 */     if (daoMap.containsKey(dbName))
/*  973:     */     {
/*  974: 977 */       daoMap.remove(dbName);
/*  975: 978 */       this.database.close();
/*  976:     */     }
/*  977:     */   }
/*  978:     */   
/*  979:     */   private void debugSql(String sql)
/*  980:     */   {
/*  981: 986 */     if (this.debug) {
/*  982: 988 */       LogUtils.d(sql);
/*  983:     */     }
/*  984:     */   }
/*  985:     */   
/*  986: 992 */   private Lock writeLock = new ReentrantLock();
/*  987: 993 */   private volatile boolean writeLocked = false;
/*  988:     */   
/*  989:     */   private void beginTransaction()
/*  990:     */   {
/*  991: 997 */     if (this.allowTransaction)
/*  992:     */     {
/*  993: 999 */       this.database.beginTransaction();
/*  994:     */     }
/*  995:     */     else
/*  996:     */     {
/*  997:1002 */       this.writeLock.lock();
/*  998:1003 */       this.writeLocked = true;
/*  999:     */     }
/* 1000:     */   }
/* 1001:     */   
/* 1002:     */   private void setTransactionSuccessful()
/* 1003:     */   {
/* 1004:1009 */     if (this.allowTransaction) {
/* 1005:1011 */       this.database.setTransactionSuccessful();
/* 1006:     */     }
/* 1007:     */   }
/* 1008:     */   
/* 1009:     */   private void endTransaction()
/* 1010:     */   {
/* 1011:1017 */     if (this.allowTransaction) {
/* 1012:1019 */       this.database.endTransaction();
/* 1013:     */     }
/* 1014:1021 */     if (this.writeLocked)
/* 1015:     */     {
/* 1016:1023 */       this.writeLock.unlock();
/* 1017:1024 */       this.writeLocked = false;
/* 1018:     */     }
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   public void execNonQuery(SqlInfo sqlInfo)
/* 1022:     */     throws DbException
/* 1023:     */   {
/* 1024:1030 */     debugSql(sqlInfo.getSql());
/* 1025:     */     try
/* 1026:     */     {
/* 1027:1033 */       if (sqlInfo.getBindArgs() != null) {
/* 1028:1035 */         this.database.execSQL(sqlInfo.getSql(), sqlInfo.getBindArgsAsArray());
/* 1029:     */       } else {
/* 1030:1038 */         this.database.execSQL(sqlInfo.getSql());
/* 1031:     */       }
/* 1032:     */     }
/* 1033:     */     catch (Throwable e)
/* 1034:     */     {
/* 1035:1042 */       throw new DbException(e);
/* 1036:     */     }
/* 1037:     */   }
/* 1038:     */   
/* 1039:     */   public void execNonQuery(String sql)
/* 1040:     */     throws DbException
/* 1041:     */   {
/* 1042:1048 */     debugSql(sql);
/* 1043:     */     try
/* 1044:     */     {
/* 1045:1051 */       this.database.execSQL(sql);
/* 1046:     */     }
/* 1047:     */     catch (Throwable e)
/* 1048:     */     {
/* 1049:1054 */       throw new DbException(e);
/* 1050:     */     }
/* 1051:     */   }
/* 1052:     */   
/* 1053:     */   public Cursor execQuery(SqlInfo sqlInfo)
/* 1054:     */     throws DbException
/* 1055:     */   {
/* 1056:1060 */     debugSql(sqlInfo.getSql());
/* 1057:     */     try
/* 1058:     */     {
/* 1059:1063 */       return this.database.rawQuery(sqlInfo.getSql(), sqlInfo.getBindArgsAsStrArray());
/* 1060:     */     }
/* 1061:     */     catch (Throwable e)
/* 1062:     */     {
/* 1063:1066 */       throw new DbException(e);
/* 1064:     */     }
/* 1065:     */   }
/* 1066:     */   
/* 1067:     */   public Cursor execQuery(String sql)
/* 1068:     */     throws DbException
/* 1069:     */   {
/* 1070:1072 */     debugSql(sql);
/* 1071:     */     try
/* 1072:     */     {
/* 1073:1075 */       return this.database.rawQuery(sql, null);
/* 1074:     */     }
/* 1075:     */     catch (Throwable e)
/* 1076:     */     {
/* 1077:1078 */       throw new DbException(e);
/* 1078:     */     }
/* 1079:     */   }
/* 1080:     */   
/* 1081:1084 */   private final FindTempCache findTempCache = new FindTempCache(null);
/* 1082:     */   
/* 1083:     */   public static abstract interface DbUpgradeListener
/* 1084:     */   {
/* 1085:     */     public abstract void onUpgrade(DbUtils paramDbUtils, int paramInt1, int paramInt2);
/* 1086:     */   }
/* 1087:     */   
/* 1088:     */   private class FindTempCache
/* 1089:     */   {
/* 1090:1095 */     private final ConcurrentHashMap<String, Object> cache = new ConcurrentHashMap();
/* 1091:1097 */     private long seq = 0L;
/* 1092:     */     
/* 1093:     */     private FindTempCache() {}
/* 1094:     */     
/* 1095:     */     public void put(String sql, Object result)
/* 1096:     */     {
/* 1097:1101 */       if ((sql != null) && (result != null)) {
/* 1098:1103 */         this.cache.put(sql, result);
/* 1099:     */       }
/* 1100:     */     }
/* 1101:     */     
/* 1102:     */     public Object get(String sql)
/* 1103:     */     {
/* 1104:1109 */       return this.cache.get(sql);
/* 1105:     */     }
/* 1106:     */     
/* 1107:     */     public void setSeq(long seq)
/* 1108:     */     {
/* 1109:1114 */       if (this.seq != seq)
/* 1110:     */       {
/* 1111:1116 */         this.cache.clear();
/* 1112:1117 */         this.seq = seq;
/* 1113:     */       }
/* 1114:     */     }
/* 1115:     */   }
/* 1116:     */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.DbUtils
 * JD-Core Version:    0.7.0.1
 */