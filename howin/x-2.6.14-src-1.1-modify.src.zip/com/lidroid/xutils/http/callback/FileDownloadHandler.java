/*   1:    */ package com.lidroid.xutils.http.callback;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.BufferedInputStream;
/*   6:    */ import java.io.BufferedOutputStream;
/*   7:    */ import java.io.File;
/*   8:    */ import java.io.FileOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ import org.apache.http.HttpEntity;
/*  11:    */ 
/*  12:    */ public class FileDownloadHandler
/*  13:    */ {
/*  14:    */   public File handleEntity(HttpEntity entity, RequestCallBackHandler callBackHandler, String target, boolean isResume, String responseFileName)
/*  15:    */     throws IOException
/*  16:    */   {
/*  17: 29 */     if ((entity == null) || (TextUtils.isEmpty(target))) {
/*  18: 31 */       return null;
/*  19:    */     }
/*  20: 34 */     File targetFile = new File(target);
/*  21: 36 */     if (!targetFile.exists())
/*  22:    */     {
/*  23: 38 */       File dir = targetFile.getParentFile();
/*  24: 39 */       if ((dir.exists()) || (dir.mkdirs())) {
/*  25: 41 */         targetFile.createNewFile();
/*  26:    */       }
/*  27:    */     }
/*  28: 45 */     long current = 0L;
/*  29: 46 */     BufferedInputStream bis = null;
/*  30: 47 */     BufferedOutputStream bos = null;
/*  31:    */     try
/*  32:    */     {
/*  33: 50 */       FileOutputStream fileOutputStream = null;
/*  34: 51 */       if (isResume)
/*  35:    */       {
/*  36: 53 */         current = targetFile.length();
/*  37: 54 */         fileOutputStream = new FileOutputStream(target, true);
/*  38:    */       }
/*  39:    */       else
/*  40:    */       {
/*  41: 57 */         fileOutputStream = new FileOutputStream(target);
/*  42:    */       }
/*  43: 59 */       long total = entity.getContentLength() + current;
/*  44: 60 */       bis = new BufferedInputStream(entity.getContent());
/*  45: 61 */       bos = new BufferedOutputStream(fileOutputStream);
/*  46:    */       File localFile1;
/*  47: 63 */       if ((callBackHandler != null) && (!callBackHandler.updateProgress(total, current, true))) {
/*  48: 65 */         return targetFile;
/*  49:    */       }
/*  50: 68 */       byte[] tmp = new byte[4096];
/*  51:    */       int len;
/*  52: 70 */       while ((len = bis.read(tmp)) != -1)
/*  53:    */       {
/*  54:    */         int len;
/*  55: 72 */         bos.write(tmp, 0, len);
/*  56: 73 */         current += len;
/*  57: 74 */         if (callBackHandler != null) {
/*  58: 76 */           if (!callBackHandler.updateProgress(total, current, false)) {
/*  59: 78 */             return targetFile;
/*  60:    */           }
/*  61:    */         }
/*  62:    */       }
/*  63: 82 */       bos.flush();
/*  64: 83 */       if (callBackHandler != null) {
/*  65: 85 */         callBackHandler.updateProgress(total, current, true);
/*  66:    */       }
/*  67:    */     }
/*  68:    */     finally
/*  69:    */     {
/*  70: 89 */       IOUtils.closeQuietly(bis);
/*  71: 90 */       IOUtils.closeQuietly(bos);
/*  72:    */     }
/*  73: 89 */     IOUtils.closeQuietly(bis);
/*  74: 90 */     IOUtils.closeQuietly(bos);
/*  75: 93 */     if ((targetFile.exists()) && (!TextUtils.isEmpty(responseFileName)))
/*  76:    */     {
/*  77: 95 */       File newFile = new File(targetFile.getParent(), responseFileName);
/*  78: 96 */       while (newFile.exists()) {
/*  79: 98 */         newFile = new File(targetFile.getParent(), System.currentTimeMillis() + responseFileName);
/*  80:    */       }
/*  81:100 */       return targetFile.renameTo(newFile) ? newFile : targetFile;
/*  82:    */     }
/*  83:103 */     return targetFile;
/*  84:    */   }
/*  85:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.FileDownloadHandler
 * JD-Core Version:    0.7.0.1
 */