package com.lidroid.xutils.http.callback;

public abstract interface RequestCallBackHandler
{
  public abstract boolean updateProgress(long paramLong1, long paramLong2, boolean paramBoolean);
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.RequestCallBackHandler
 * JD-Core Version:    0.7.0.1
 */