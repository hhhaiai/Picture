/*  1:   */ package com.lidroid.xutils.http.callback;
/*  2:   */ 
/*  3:   */ import org.apache.http.Header;
/*  4:   */ import org.apache.http.HttpResponse;
/*  5:   */ import org.apache.http.client.methods.HttpGet;
/*  6:   */ import org.apache.http.client.methods.HttpRequestBase;
/*  7:   */ 
/*  8:   */ public class DefaultHttpRedirectHandler
/*  9:   */   implements HttpRedirectHandler
/* 10:   */ {
/* 11:   */   public HttpRequestBase getDirectRequest(HttpResponse response)
/* 12:   */   {
/* 13:30 */     if (response.containsHeader("Location"))
/* 14:   */     {
/* 15:32 */       String location = response.getFirstHeader("Location").getValue();
/* 16:33 */       HttpGet request = new HttpGet(location);
/* 17:34 */       if (response.containsHeader("Set-Cookie"))
/* 18:   */       {
/* 19:36 */         String cookie = response.getFirstHeader("Set-Cookie").getValue();
/* 20:37 */         request.addHeader("Cookie", cookie);
/* 21:   */       }
/* 22:39 */       return request;
/* 23:   */     }
/* 24:41 */     return null;
/* 25:   */   }
/* 26:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.DefaultHttpRedirectHandler
 * JD-Core Version:    0.7.0.1
 */