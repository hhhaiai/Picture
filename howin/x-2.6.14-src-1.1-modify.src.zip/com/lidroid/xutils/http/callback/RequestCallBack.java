/*   1:    */ package com.lidroid.xutils.http.callback;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.exception.HttpException;
/*   4:    */ import com.lidroid.xutils.http.HttpHandler;
/*   5:    */ import com.lidroid.xutils.http.ResponseInfo;
/*   6:    */ 
/*   7:    */ public abstract class RequestCallBack<T>
/*   8:    */ {
/*   9:    */   private static final int DEFAULT_RATE = 1000;
/*  10:    */   private static final int MIN_RATE = 200;
/*  11:    */   private String requestUrl;
/*  12:    */   protected Object userTag;
/*  13:    */   protected HttpHandler<T> mHttpHandler;
/*  14:    */   protected Object mData;
/*  15:    */   private int rate;
/*  16:    */   
/*  17:    */   public Object getmData()
/*  18:    */   {
/*  19: 39 */     return this.mData;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setmData(Object mData)
/*  23:    */   {
/*  24: 44 */     this.mData = mData;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public HttpHandler<T> getmHttpHandler()
/*  28:    */   {
/*  29: 49 */     return this.mHttpHandler;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setmHttpHandler(HttpHandler<T> mHttpHandler)
/*  33:    */   {
/*  34: 54 */     this.mHttpHandler = mHttpHandler;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public RequestCallBack()
/*  38:    */   {
/*  39: 59 */     this.rate = 1000;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public RequestCallBack(int rate)
/*  43:    */   {
/*  44: 64 */     this.rate = rate;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public RequestCallBack(Object userTag)
/*  48:    */   {
/*  49: 69 */     this.rate = 1000;
/*  50: 70 */     this.userTag = userTag;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public RequestCallBack(int rate, Object userTag)
/*  54:    */   {
/*  55: 75 */     this.rate = rate;
/*  56: 76 */     this.userTag = userTag;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public final int getRate()
/*  60:    */   {
/*  61: 83 */     if (this.rate < 200) {
/*  62: 85 */       return 200;
/*  63:    */     }
/*  64: 87 */     return this.rate;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public final void setRate(int rate)
/*  68:    */   {
/*  69: 92 */     this.rate = rate;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Object getUserTag()
/*  73:    */   {
/*  74: 97 */     return this.userTag;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setUserTag(Object userTag)
/*  78:    */   {
/*  79:102 */     this.userTag = userTag;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public final String getRequestUrl()
/*  83:    */   {
/*  84:107 */     return this.requestUrl;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public final void setRequestUrl(String requestUrl)
/*  88:    */   {
/*  89:112 */     this.requestUrl = requestUrl;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void onStart() {}
/*  93:    */   
/*  94:    */   public void onCancelled() {}
/*  95:    */   
/*  96:    */   public void onLoading(long total, long current, boolean isUploading) {}
/*  97:    */   
/*  98:    */   public abstract void onSuccess(ResponseInfo<T> paramResponseInfo);
/*  99:    */   
/* 100:    */   public void onSuccessBack(ResponseInfo<T> responseInfo) {}
/* 101:    */   
/* 102:    */   public void onFailure(HttpException error, String msg) {}
/* 103:    */   
/* 104:    */   public void onFinish() {}
/* 105:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.RequestCallBack
 * JD-Core Version:    0.7.0.1
 */