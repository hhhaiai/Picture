/*  1:   */ package com.lidroid.xutils.http.callback;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.util.IOUtils;
/*  4:   */ import com.lidroid.xutils.util.OtherUtils;
/*  5:   */ import java.io.BufferedReader;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.io.InputStream;
/*  8:   */ import java.io.InputStreamReader;
/*  9:   */ import org.apache.http.HttpEntity;
/* 10:   */ 
/* 11:   */ public class StringDownloadHandler
/* 12:   */ {
/* 13:   */   public String handleEntity(HttpEntity entity, RequestCallBackHandler callBackHandler, String charset)
/* 14:   */     throws IOException
/* 15:   */   {
/* 16:32 */     if (entity == null) {
/* 17:33 */       return null;
/* 18:   */     }
/* 19:35 */     long current = 0L;
/* 20:36 */     long total = entity.getContentLength();
/* 21:38 */     if ((callBackHandler != null) && (!callBackHandler.updateProgress(total, current, true))) {
/* 22:40 */       return null;
/* 23:   */     }
/* 24:43 */     InputStream inputStream = null;
/* 25:44 */     StringBuilder sb = new StringBuilder();
/* 26:   */     try
/* 27:   */     {
/* 28:47 */       inputStream = entity.getContent();
/* 29:48 */       BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, charset));
/* 30:49 */       String line = "";
/* 31:50 */       while ((line = reader.readLine()) != null)
/* 32:   */       {
/* 33:52 */         sb.append(line).append('\n');
/* 34:53 */         current += OtherUtils.sizeOfString(line, charset);
/* 35:54 */         if ((callBackHandler != null) && 
/* 36:   */         
/* 37:56 */           (!callBackHandler.updateProgress(total, current, false))) {
/* 38:   */           break;
/* 39:   */         }
/* 40:   */       }
/* 41:62 */       if (callBackHandler != null) {
/* 42:64 */         callBackHandler.updateProgress(total, current, true);
/* 43:   */       }
/* 44:   */     }
/* 45:   */     finally
/* 46:   */     {
/* 47:68 */       IOUtils.closeQuietly(inputStream);
/* 48:   */     }
/* 49:70 */     return sb.toString().trim();
/* 50:   */   }
/* 51:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.callback.StringDownloadHandler
 * JD-Core Version:    0.7.0.1
 */