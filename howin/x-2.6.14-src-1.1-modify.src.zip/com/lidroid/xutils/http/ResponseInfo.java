/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import java.util.Locale;
/*   4:    */ import org.apache.http.Header;
/*   5:    */ import org.apache.http.HttpEntity;
/*   6:    */ import org.apache.http.HttpResponse;
/*   7:    */ import org.apache.http.ProtocolVersion;
/*   8:    */ import org.apache.http.StatusLine;
/*   9:    */ 
/*  10:    */ public final class ResponseInfo<T>
/*  11:    */ {
/*  12:    */   private final HttpResponse response;
/*  13:    */   public T result;
/*  14:    */   public final boolean resultFormCache;
/*  15:    */   public final Locale locale;
/*  16:    */   public final int statusCode;
/*  17:    */   public final ProtocolVersion protocolVersion;
/*  18:    */   public final String reasonPhrase;
/*  19:    */   public final long contentLength;
/*  20:    */   public final Header contentType;
/*  21:    */   public final Header contentEncoding;
/*  22:    */   
/*  23:    */   public Header[] getAllHeaders()
/*  24:    */   {
/*  25: 31 */     if (this.response == null) {
/*  26: 32 */       return null;
/*  27:    */     }
/*  28: 33 */     return this.response.getAllHeaders();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Header[] getHeaders(String name)
/*  32:    */   {
/*  33: 38 */     if (this.response == null) {
/*  34: 39 */       return null;
/*  35:    */     }
/*  36: 40 */     return this.response.getHeaders(name);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Header getFirstHeader(String name)
/*  40:    */   {
/*  41: 45 */     if (this.response == null) {
/*  42: 46 */       return null;
/*  43:    */     }
/*  44: 47 */     return this.response.getFirstHeader(name);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Header getLastHeader(String name)
/*  48:    */   {
/*  49: 52 */     if (this.response == null) {
/*  50: 53 */       return null;
/*  51:    */     }
/*  52: 54 */     return this.response.getLastHeader(name);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public ResponseInfo(HttpResponse response, T result, boolean resultFormCache)
/*  56:    */   {
/*  57: 59 */     this.response = response;
/*  58: 60 */     this.result = result;
/*  59: 61 */     this.resultFormCache = resultFormCache;
/*  60: 63 */     if (response != null)
/*  61:    */     {
/*  62: 65 */       this.locale = response.getLocale();
/*  63:    */       
/*  64:    */ 
/*  65: 68 */       StatusLine statusLine = response.getStatusLine();
/*  66: 69 */       if (statusLine != null)
/*  67:    */       {
/*  68: 71 */         this.statusCode = statusLine.getStatusCode();
/*  69: 72 */         this.protocolVersion = statusLine.getProtocolVersion();
/*  70: 73 */         this.reasonPhrase = statusLine.getReasonPhrase();
/*  71:    */       }
/*  72:    */       else
/*  73:    */       {
/*  74: 76 */         this.statusCode = 0;
/*  75: 77 */         this.protocolVersion = null;
/*  76: 78 */         this.reasonPhrase = null;
/*  77:    */       }
/*  78: 82 */       HttpEntity entity = response.getEntity();
/*  79: 83 */       if (entity != null)
/*  80:    */       {
/*  81: 85 */         this.contentLength = entity.getContentLength();
/*  82: 86 */         this.contentType = entity.getContentType();
/*  83: 87 */         this.contentEncoding = entity.getContentEncoding();
/*  84:    */       }
/*  85:    */       else
/*  86:    */       {
/*  87: 90 */         this.contentLength = 0L;
/*  88: 91 */         this.contentType = null;
/*  89: 92 */         this.contentEncoding = null;
/*  90:    */       }
/*  91:    */     }
/*  92:    */     else
/*  93:    */     {
/*  94: 96 */       this.locale = null;
/*  95:    */       
/*  96:    */ 
/*  97: 99 */       this.statusCode = 0;
/*  98:100 */       this.protocolVersion = null;
/*  99:101 */       this.reasonPhrase = null;
/* 100:    */       
/* 101:    */ 
/* 102:104 */       this.contentLength = 0L;
/* 103:105 */       this.contentType = null;
/* 104:106 */       this.contentEncoding = null;
/* 105:    */     }
/* 106:    */   }
/* 107:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.ResponseInfo
 * JD-Core Version:    0.7.0.1
 */