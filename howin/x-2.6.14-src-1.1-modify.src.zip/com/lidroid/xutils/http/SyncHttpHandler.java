/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.HttpUtils;
/*   4:    */ import com.lidroid.xutils.exception.HttpException;
/*   5:    */ import com.lidroid.xutils.http.callback.DefaultHttpRedirectHandler;
/*   6:    */ import com.lidroid.xutils.http.callback.HttpRedirectHandler;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.net.URI;
/*   9:    */ import java.net.UnknownHostException;
/*  10:    */ import org.apache.http.HttpResponse;
/*  11:    */ import org.apache.http.StatusLine;
/*  12:    */ import org.apache.http.client.HttpRequestRetryHandler;
/*  13:    */ import org.apache.http.client.methods.HttpRequestBase;
/*  14:    */ import org.apache.http.impl.client.AbstractHttpClient;
/*  15:    */ import org.apache.http.protocol.HttpContext;
/*  16:    */ 
/*  17:    */ public class SyncHttpHandler
/*  18:    */ {
/*  19:    */   private final AbstractHttpClient client;
/*  20:    */   private final HttpContext context;
/*  21:    */   private HttpRedirectHandler httpRedirectHandler;
/*  22:    */   private String requestUrl;
/*  23:    */   private String requestMethod;
/*  24:    */   private String charset;
/*  25:    */   
/*  26:    */   public void setHttpRedirectHandler(HttpRedirectHandler httpRedirectHandler)
/*  27:    */   {
/*  28: 42 */     this.httpRedirectHandler = httpRedirectHandler;
/*  29:    */   }
/*  30:    */   
/*  31: 49 */   private int retriedTimes = 0;
/*  32:    */   
/*  33:    */   public SyncHttpHandler(AbstractHttpClient client, HttpContext context, String charset)
/*  34:    */   {
/*  35: 53 */     this.client = client;
/*  36: 54 */     this.context = context;
/*  37: 55 */     this.charset = charset;
/*  38:    */   }
/*  39:    */   
/*  40: 58 */   private long expiry = HttpCache.getDefaultExpiryTime();
/*  41:    */   
/*  42:    */   public void setExpiry(long expiry)
/*  43:    */   {
/*  44: 62 */     this.expiry = expiry;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public ResponseStream sendRequest(HttpRequestBase request)
/*  48:    */     throws HttpException
/*  49:    */   {
/*  50: 68 */     HttpRequestRetryHandler retryHandler = this.client.getHttpRequestRetryHandler();
/*  51:    */     boolean retry;
/*  52:    */     IOException exception;
/*  53:    */     do
/*  54:    */     {
/*  55: 71 */       retry = true;
/*  56: 72 */       exception = null;
/*  57:    */       try
/*  58:    */       {
/*  59: 75 */         this.requestUrl = request.getURI().toString();
/*  60: 76 */         this.requestMethod = request.getMethod();
/*  61: 77 */         if (HttpUtils.sHttpCache.isEnabled(this.requestMethod))
/*  62:    */         {
/*  63: 79 */           String result = HttpUtils.sHttpCache.get(this.requestUrl);
/*  64: 80 */           if (result != null) {
/*  65: 82 */             return new ResponseStream(result);
/*  66:    */           }
/*  67:    */         }
/*  68: 86 */         HttpResponse response = this.client.execute(request, this.context);
/*  69: 87 */         return handleResponse(response);
/*  70:    */       }
/*  71:    */       catch (UnknownHostException e)
/*  72:    */       {
/*  73: 90 */         exception = e;
/*  74: 91 */         retry = retryHandler.retryRequest(exception, ++this.retriedTimes, this.context);
/*  75:    */       }
/*  76:    */       catch (IOException e)
/*  77:    */       {
/*  78: 94 */         exception = e;
/*  79: 95 */         retry = retryHandler.retryRequest(exception, ++this.retriedTimes, this.context);
/*  80:    */       }
/*  81:    */       catch (NullPointerException e)
/*  82:    */       {
/*  83: 98 */         exception = new IOException(e.getMessage());
/*  84: 99 */         exception.initCause(e);
/*  85:100 */         retry = retryHandler.retryRequest(exception, ++this.retriedTimes, this.context);
/*  86:    */       }
/*  87:    */       catch (HttpException e)
/*  88:    */       {
/*  89:103 */         throw e;
/*  90:    */       }
/*  91:    */       catch (Throwable e)
/*  92:    */       {
/*  93:106 */         exception = new IOException(e.getMessage());
/*  94:107 */         exception.initCause(e);
/*  95:108 */         retry = retryHandler.retryRequest(exception, ++this.retriedTimes, this.context);
/*  96:    */       }
/*  97:110 */     } while (retry);
/*  98:112 */     throw new HttpException(exception);
/*  99:    */   }
/* 100:    */   
/* 101:    */   private ResponseStream handleResponse(HttpResponse response)
/* 102:    */     throws HttpException, IOException
/* 103:    */   {
/* 104:119 */     if (response == null) {
/* 105:121 */       throw new HttpException("response is null");
/* 106:    */     }
/* 107:123 */     StatusLine status = response.getStatusLine();
/* 108:124 */     int statusCode = status.getStatusCode();
/* 109:125 */     if (statusCode < 300)
/* 110:    */     {
/* 111:127 */       ResponseStream responseStream = new ResponseStream(response, this.charset, this.requestUrl, this.expiry);
/* 112:128 */       responseStream.setRequestMethod(this.requestMethod);
/* 113:129 */       return responseStream;
/* 114:    */     }
/* 115:130 */     if ((statusCode == 301) || (statusCode == 302))
/* 116:    */     {
/* 117:132 */       if (this.httpRedirectHandler == null) {
/* 118:134 */         this.httpRedirectHandler = new DefaultHttpRedirectHandler();
/* 119:    */       }
/* 120:136 */       HttpRequestBase request = this.httpRedirectHandler.getDirectRequest(response);
/* 121:137 */       if (request != null) {
/* 122:139 */         return sendRequest(request);
/* 123:    */       }
/* 124:    */     }
/* 125:    */     else
/* 126:    */     {
/* 127:141 */       if (statusCode == 416) {
/* 128:143 */         throw new HttpException(statusCode, "maybe the file has downloaded completely");
/* 129:    */       }
/* 130:146 */       throw new HttpException(statusCode, status.getReasonPhrase());
/* 131:    */     }
/* 132:148 */     return null;
/* 133:    */   }
/* 134:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.SyncHttpHandler
 * JD-Core Version:    0.7.0.1
 */