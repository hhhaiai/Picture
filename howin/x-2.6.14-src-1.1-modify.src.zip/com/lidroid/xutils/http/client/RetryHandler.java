/*   1:    */ package com.lidroid.xutils.http.client;
/*   2:    */ 
/*   3:    */ import android.os.SystemClock;
/*   4:    */ import com.lidroid.xutils.util.LogUtils;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InterruptedIOException;
/*   7:    */ import java.net.SocketException;
/*   8:    */ import java.net.UnknownHostException;
/*   9:    */ import java.util.HashSet;
/*  10:    */ import javax.net.ssl.SSLHandshakeException;
/*  11:    */ import org.apache.http.NoHttpResponseException;
/*  12:    */ import org.apache.http.client.HttpRequestRetryHandler;
/*  13:    */ import org.apache.http.client.methods.HttpRequestBase;
/*  14:    */ import org.apache.http.impl.client.RequestWrapper;
/*  15:    */ import org.apache.http.protocol.HttpContext;
/*  16:    */ 
/*  17:    */ public class RetryHandler
/*  18:    */   implements HttpRequestRetryHandler
/*  19:    */ {
/*  20:    */   private static final int RETRY_SLEEP_INTERVAL = 500;
/*  21: 39 */   private static HashSet<Class<?>> exceptionWhiteList = new HashSet();
/*  22: 41 */   private static HashSet<Class<?>> exceptionBlackList = new HashSet();
/*  23:    */   private final int maxRetries;
/*  24:    */   
/*  25:    */   static
/*  26:    */   {
/*  27: 45 */     exceptionWhiteList.add(NoHttpResponseException.class);
/*  28: 46 */     exceptionWhiteList.add(UnknownHostException.class);
/*  29: 47 */     exceptionWhiteList.add(SocketException.class);
/*  30:    */     
/*  31: 49 */     exceptionBlackList.add(InterruptedIOException.class);
/*  32: 50 */     exceptionBlackList.add(SSLHandshakeException.class);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public RetryHandler(int maxRetries)
/*  36:    */   {
/*  37: 57 */     this.maxRetries = maxRetries;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean retryRequest(IOException exception, int retriedTimes, HttpContext context)
/*  41:    */   {
/*  42: 63 */     boolean retry = true;
/*  43: 65 */     if ((exception == null) || (context == null)) {
/*  44: 67 */       return false;
/*  45:    */     }
/*  46: 70 */     Object isReqSent = context.getAttribute("http.request_sent");
/*  47: 71 */     boolean sent = isReqSent == null ? false : ((Boolean)isReqSent).booleanValue();
/*  48: 73 */     if (retriedTimes > this.maxRetries) {
/*  49: 75 */       retry = false;
/*  50: 76 */     } else if (exceptionBlackList.contains(exception.getClass())) {
/*  51: 78 */       retry = false;
/*  52: 79 */     } else if (exceptionWhiteList.contains(exception.getClass())) {
/*  53: 81 */       retry = true;
/*  54: 82 */     } else if (!sent) {
/*  55: 84 */       retry = true;
/*  56:    */     }
/*  57: 87 */     if (retry) {
/*  58:    */       try
/*  59:    */       {
/*  60: 91 */         Object currRequest = context.getAttribute("http.request");
/*  61: 92 */         if (currRequest != null)
/*  62:    */         {
/*  63: 94 */           if ((currRequest instanceof HttpRequestBase))
/*  64:    */           {
/*  65: 96 */             HttpRequestBase requestBase = (HttpRequestBase)currRequest;
/*  66: 97 */             retry = "GET".equals(requestBase.getMethod());
/*  67:    */           }
/*  68: 98 */           else if ((currRequest instanceof RequestWrapper))
/*  69:    */           {
/*  70:100 */             RequestWrapper requestWrapper = (RequestWrapper)currRequest;
/*  71:101 */             retry = "GET".equals(requestWrapper.getMethod());
/*  72:    */           }
/*  73:    */         }
/*  74:    */         else
/*  75:    */         {
/*  76:105 */           retry = false;
/*  77:106 */           LogUtils.e("retry error, curr request is null");
/*  78:    */         }
/*  79:    */       }
/*  80:    */       catch (Throwable e)
/*  81:    */       {
/*  82:110 */         retry = false;
/*  83:111 */         LogUtils.e("retry error", e);
/*  84:    */       }
/*  85:    */     }
/*  86:115 */     if (retry) {
/*  87:117 */       SystemClock.sleep(500L);
/*  88:    */     }
/*  89:121 */     return retry;
/*  90:    */   }
/*  91:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.RetryHandler
 * JD-Core Version:    0.7.0.1
 */