package com.lidroid.xutils.http.client.entity;

import com.lidroid.xutils.http.callback.RequestCallBackHandler;

public abstract interface UploadEntity
{
  public abstract void setCallBackHandler(RequestCallBackHandler paramRequestCallBackHandler);
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.UploadEntity
 * JD-Core Version:    0.7.0.1
 */