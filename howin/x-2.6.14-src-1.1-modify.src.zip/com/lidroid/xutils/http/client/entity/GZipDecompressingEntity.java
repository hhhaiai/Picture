/*  1:   */ package com.lidroid.xutils.http.client.entity;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.InputStream;
/*  5:   */ import java.util.zip.GZIPInputStream;
/*  6:   */ import org.apache.http.Header;
/*  7:   */ import org.apache.http.HttpEntity;
/*  8:   */ 
/*  9:   */ public class GZipDecompressingEntity
/* 10:   */   extends DecompressingEntity
/* 11:   */ {
/* 12:   */   public GZipDecompressingEntity(HttpEntity entity)
/* 13:   */   {
/* 14:37 */     super(entity);
/* 15:   */   }
/* 16:   */   
/* 17:   */   InputStream decorate(InputStream wrapped)
/* 18:   */     throws IOException
/* 19:   */   {
/* 20:43 */     return new GZIPInputStream(wrapped);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Header getContentEncoding()
/* 24:   */   {
/* 25:54 */     return null;
/* 26:   */   }
/* 27:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.GZipDecompressingEntity
 * JD-Core Version:    0.7.0.1
 */