/*  1:   */ package com.lidroid.xutils.http.client.entity;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*  4:   */ import com.lidroid.xutils.util.IOUtils;
/*  5:   */ import java.io.BufferedInputStream;
/*  6:   */ import java.io.File;
/*  7:   */ import java.io.FileInputStream;
/*  8:   */ import java.io.IOException;
/*  9:   */ import java.io.InterruptedIOException;
/* 10:   */ import java.io.OutputStream;
/* 11:   */ import org.apache.http.entity.FileEntity;
/* 12:   */ 
/* 13:   */ public class FileUploadEntity
/* 14:   */   extends FileEntity
/* 15:   */   implements UploadEntity
/* 16:   */ {
/* 17:   */   private long fileSize;
/* 18:   */   
/* 19:   */   public FileUploadEntity(File file, String contentType)
/* 20:   */   {
/* 21:32 */     super(file, contentType);
/* 22:33 */     this.fileSize = file.length();
/* 23:   */   }
/* 24:   */   
/* 25:37 */   private long uploadedSize = 0L;
/* 26:   */   
/* 27:   */   public void writeTo(OutputStream outStream)
/* 28:   */     throws IOException
/* 29:   */   {
/* 30:42 */     if (outStream == null) {
/* 31:44 */       throw new IllegalArgumentException("Output stream may not be null");
/* 32:   */     }
/* 33:46 */     BufferedInputStream inStream = null;
/* 34:   */     try
/* 35:   */     {
/* 36:49 */       inStream = new BufferedInputStream(new FileInputStream(this.file));
/* 37:50 */       byte[] tmp = new byte[4096];
/* 38:   */       int len;
/* 39:52 */       while ((len = inStream.read(tmp)) != -1)
/* 40:   */       {
/* 41:   */         int len;
/* 42:54 */         outStream.write(tmp, 0, len);
/* 43:55 */         this.uploadedSize += len;
/* 44:56 */         if (this.callBackHandler != null) {
/* 45:58 */           if (!this.callBackHandler.updateProgress(this.fileSize, this.uploadedSize, false)) {
/* 46:60 */             throw new InterruptedIOException("cancel");
/* 47:   */           }
/* 48:   */         }
/* 49:   */       }
/* 50:64 */       outStream.flush();
/* 51:65 */       if (this.callBackHandler != null) {
/* 52:67 */         this.callBackHandler.updateProgress(this.fileSize, this.uploadedSize, true);
/* 53:   */       }
/* 54:   */     }
/* 55:   */     finally
/* 56:   */     {
/* 57:71 */       IOUtils.closeQuietly(inStream);
/* 58:   */     }
/* 59:   */   }
/* 60:   */   
/* 61:75 */   private RequestCallBackHandler callBackHandler = null;
/* 62:   */   
/* 63:   */   public void setCallBackHandler(RequestCallBackHandler callBackHandler)
/* 64:   */   {
/* 65:80 */     this.callBackHandler = callBackHandler;
/* 66:   */   }
/* 67:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.FileUploadEntity
 * JD-Core Version:    0.7.0.1
 */