/*   1:    */ package com.lidroid.xutils.http.client.entity;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.InterruptedIOException;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import org.apache.http.entity.AbstractHttpEntity;
/*  10:    */ 
/*  11:    */ public class InputStreamUploadEntity
/*  12:    */   extends AbstractHttpEntity
/*  13:    */   implements UploadEntity
/*  14:    */ {
/*  15:    */   private static final int BUFFER_SIZE = 2048;
/*  16:    */   private final InputStream content;
/*  17:    */   private final long length;
/*  18:    */   
/*  19:    */   public InputStreamUploadEntity(InputStream inputStream, long length)
/*  20:    */   {
/*  21: 41 */     if (inputStream == null) {
/*  22: 43 */       throw new IllegalArgumentException("Source input stream may not be null");
/*  23:    */     }
/*  24: 45 */     this.content = inputStream;
/*  25: 46 */     this.length = length;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean isRepeatable()
/*  29:    */   {
/*  30: 51 */     return false;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public long getContentLength()
/*  34:    */   {
/*  35: 56 */     return this.length;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public InputStream getContent()
/*  39:    */     throws IOException
/*  40:    */   {
/*  41: 61 */     return this.content;
/*  42:    */   }
/*  43:    */   
/*  44: 64 */   private long uploadedSize = 0L;
/*  45:    */   
/*  46:    */   public void writeTo(OutputStream outStream)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 68 */     if (outStream == null) {
/*  50: 70 */       throw new IllegalArgumentException("Output stream may not be null");
/*  51:    */     }
/*  52: 72 */     InputStream inStream = this.content;
/*  53:    */     try
/*  54:    */     {
/*  55: 75 */       byte[] buffer = new byte[2048];
/*  56: 77 */       if (this.length < 0L)
/*  57:    */       {
/*  58:    */         int l;
/*  59: 80 */         while ((l = inStream.read(buffer)) != -1)
/*  60:    */         {
/*  61:    */           int l;
/*  62: 82 */           outStream.write(buffer, 0, l);
/*  63: 83 */           this.uploadedSize += l;
/*  64: 84 */           if (this.callBackHandler != null) {
/*  65: 86 */             if (!this.callBackHandler.updateProgress(this.uploadedSize + 1L, this.uploadedSize, false)) {
/*  66: 88 */               throw new InterruptedIOException("cancel");
/*  67:    */             }
/*  68:    */           }
/*  69:    */         }
/*  70:    */       }
/*  71:    */       else
/*  72:    */       {
/*  73: 95 */         long remaining = this.length;
/*  74: 96 */         while (remaining > 0L)
/*  75:    */         {
/*  76: 98 */           int l = inStream.read(buffer, 0, (int)Math.min(2048L, remaining));
/*  77: 99 */           if (l == -1) {
/*  78:    */             break;
/*  79:    */           }
/*  80:103 */           outStream.write(buffer, 0, l);
/*  81:104 */           remaining -= l;
/*  82:105 */           this.uploadedSize += l;
/*  83:106 */           if (this.callBackHandler != null) {
/*  84:108 */             if (!this.callBackHandler.updateProgress(this.length, this.uploadedSize, false)) {
/*  85:110 */               throw new InterruptedIOException("cancel");
/*  86:    */             }
/*  87:    */           }
/*  88:    */         }
/*  89:    */       }
/*  90:115 */       outStream.flush();
/*  91:116 */       if (this.callBackHandler != null) {
/*  92:118 */         this.callBackHandler.updateProgress(this.length, this.uploadedSize, true);
/*  93:    */       }
/*  94:    */     }
/*  95:    */     finally
/*  96:    */     {
/*  97:122 */       IOUtils.closeQuietly(inStream);
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean isStreaming()
/* 102:    */   {
/* 103:128 */     return true;
/* 104:    */   }
/* 105:    */   
/* 106:    */   /**
/* 107:    */    * @deprecated
/* 108:    */    */
/* 109:    */   public void consumeContent()
/* 110:    */     throws IOException
/* 111:    */   {
/* 112:141 */     this.content.close();
/* 113:    */   }
/* 114:    */   
/* 115:144 */   private RequestCallBackHandler callBackHandler = null;
/* 116:    */   
/* 117:    */   public void setCallBackHandler(RequestCallBackHandler callBackHandler)
/* 118:    */   {
/* 119:149 */     this.callBackHandler = callBackHandler;
/* 120:    */   }
/* 121:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.InputStreamUploadEntity
 * JD-Core Version:    0.7.0.1
 */