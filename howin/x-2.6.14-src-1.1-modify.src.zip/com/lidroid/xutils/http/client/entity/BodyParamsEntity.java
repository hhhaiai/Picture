/*   1:    */ package com.lidroid.xutils.http.client.entity;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.util.URLEncodedUtils;
/*   4:    */ import com.lidroid.xutils.util.LogUtils;
/*   5:    */ import java.io.ByteArrayInputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.io.UnsupportedEncodingException;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ import org.apache.http.NameValuePair;
/*  13:    */ import org.apache.http.entity.AbstractHttpEntity;
/*  14:    */ import org.apache.http.message.BasicNameValuePair;
/*  15:    */ 
/*  16:    */ public class BodyParamsEntity
/*  17:    */   extends AbstractHttpEntity
/*  18:    */   implements Cloneable
/*  19:    */ {
/*  20:    */   protected byte[] content;
/*  21: 37 */   private boolean dirty = true;
/*  22: 39 */   private String charset = "UTF-8";
/*  23:    */   private List<NameValuePair> params;
/*  24:    */   
/*  25:    */   public BodyParamsEntity()
/*  26:    */   {
/*  27: 45 */     this(null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public BodyParamsEntity(String charset)
/*  31:    */   {
/*  32: 51 */     if (charset != null) {
/*  33: 53 */       this.charset = charset;
/*  34:    */     }
/*  35: 55 */     setContentType("application/x-www-form-urlencoded");
/*  36: 56 */     this.params = new ArrayList();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public BodyParamsEntity(List<NameValuePair> params)
/*  40:    */   {
/*  41: 61 */     this(params, null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public BodyParamsEntity(List<NameValuePair> params, String charset)
/*  45:    */   {
/*  46: 67 */     if (charset != null) {
/*  47: 69 */       this.charset = charset;
/*  48:    */     }
/*  49: 71 */     setContentType("application/x-www-form-urlencoded");
/*  50: 72 */     this.params = params;
/*  51: 73 */     refreshContent();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public BodyParamsEntity addParameter(String name, String value)
/*  55:    */   {
/*  56: 78 */     this.params.add(new BasicNameValuePair(name, value));
/*  57: 79 */     this.dirty = true;
/*  58: 80 */     return this;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public BodyParamsEntity addParams(List<NameValuePair> params)
/*  62:    */   {
/*  63: 85 */     this.params.addAll(params);
/*  64: 86 */     this.dirty = true;
/*  65: 87 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private void refreshContent()
/*  69:    */   {
/*  70: 92 */     if (this.dirty)
/*  71:    */     {
/*  72:    */       try
/*  73:    */       {
/*  74: 96 */         this.content = URLEncodedUtils.format(this.params, this.charset).getBytes(this.charset);
/*  75:    */       }
/*  76:    */       catch (UnsupportedEncodingException e)
/*  77:    */       {
/*  78: 99 */         LogUtils.e(e.getMessage(), e);
/*  79:    */       }
/*  80:101 */       this.dirty = false;
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isRepeatable()
/*  85:    */   {
/*  86:107 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public long getContentLength()
/*  90:    */   {
/*  91:112 */     refreshContent();
/*  92:113 */     return this.content.length;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public InputStream getContent()
/*  96:    */     throws IOException
/*  97:    */   {
/*  98:118 */     refreshContent();
/*  99:119 */     return new ByteArrayInputStream(this.content);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void writeTo(OutputStream outStream)
/* 103:    */     throws IOException
/* 104:    */   {
/* 105:124 */     if (outStream == null) {
/* 106:126 */       throw new IllegalArgumentException("Output stream may not be null");
/* 107:    */     }
/* 108:128 */     refreshContent();
/* 109:129 */     outStream.write(this.content);
/* 110:130 */     outStream.flush();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public boolean isStreaming()
/* 114:    */   {
/* 115:140 */     return false;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public Object clone()
/* 119:    */     throws CloneNotSupportedException
/* 120:    */   {
/* 121:145 */     return super.clone();
/* 122:    */   }
/* 123:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.BodyParamsEntity
 * JD-Core Version:    0.7.0.1
 */