/*   1:    */ package com.lidroid.xutils.http.client.entity;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.InterruptedIOException;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import org.apache.http.HttpEntity;
/*  10:    */ import org.apache.http.entity.HttpEntityWrapper;
/*  11:    */ 
/*  12:    */ abstract class DecompressingEntity
/*  13:    */   extends HttpEntityWrapper
/*  14:    */   implements UploadEntity
/*  15:    */ {
/*  16:    */   private InputStream content;
/*  17:    */   private long uncompressedLength;
/*  18:    */   
/*  19:    */   public DecompressingEntity(HttpEntity wrapped)
/*  20:    */   {
/*  21: 52 */     super(wrapped);
/*  22: 53 */     this.uncompressedLength = wrapped.getContentLength();
/*  23:    */   }
/*  24:    */   
/*  25:    */   abstract InputStream decorate(InputStream paramInputStream)
/*  26:    */     throws IOException;
/*  27:    */   
/*  28:    */   private InputStream getDecompressingStream()
/*  29:    */     throws IOException
/*  30:    */   {
/*  31: 60 */     InputStream in = null;
/*  32:    */     try
/*  33:    */     {
/*  34: 63 */       in = this.wrappedEntity.getContent();
/*  35: 64 */       return decorate(in);
/*  36:    */     }
/*  37:    */     catch (IOException ex)
/*  38:    */     {
/*  39: 67 */       IOUtils.closeQuietly(in);
/*  40: 68 */       throw ex;
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public InputStream getContent()
/*  45:    */     throws IOException
/*  46:    */   {
/*  47: 78 */     if (this.wrappedEntity.isStreaming())
/*  48:    */     {
/*  49: 80 */       if (this.content == null) {
/*  50: 82 */         this.content = getDecompressingStream();
/*  51:    */       }
/*  52: 84 */       return this.content;
/*  53:    */     }
/*  54: 87 */     return getDecompressingStream();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public long getContentLength()
/*  58:    */   {
/*  59: 97 */     return -1L;
/*  60:    */   }
/*  61:    */   
/*  62:100 */   private long uploadedSize = 0L;
/*  63:    */   
/*  64:    */   public void writeTo(OutputStream outStream)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67:108 */     if (outStream == null) {
/*  68:110 */       throw new IllegalArgumentException("Output stream may not be null");
/*  69:    */     }
/*  70:112 */     InputStream inStream = null;
/*  71:    */     try
/*  72:    */     {
/*  73:115 */       inStream = getContent();
/*  74:    */       
/*  75:117 */       byte[] tmp = new byte[4096];
/*  76:    */       int len;
/*  77:119 */       while ((len = inStream.read(tmp)) != -1)
/*  78:    */       {
/*  79:    */         int len;
/*  80:121 */         outStream.write(tmp, 0, len);
/*  81:122 */         this.uploadedSize += len;
/*  82:123 */         if (this.callBackHandler != null) {
/*  83:125 */           if (!this.callBackHandler.updateProgress(this.uncompressedLength, this.uploadedSize, false)) {
/*  84:127 */             throw new InterruptedIOException("cancel");
/*  85:    */           }
/*  86:    */         }
/*  87:    */       }
/*  88:131 */       outStream.flush();
/*  89:132 */       if (this.callBackHandler != null) {
/*  90:134 */         this.callBackHandler.updateProgress(this.uncompressedLength, this.uploadedSize, true);
/*  91:    */       }
/*  92:    */     }
/*  93:    */     finally
/*  94:    */     {
/*  95:138 */       IOUtils.closeQuietly(inStream);
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:142 */   private RequestCallBackHandler callBackHandler = null;
/* 100:    */   
/* 101:    */   public void setCallBackHandler(RequestCallBackHandler callBackHandler)
/* 102:    */   {
/* 103:147 */     this.callBackHandler = callBackHandler;
/* 104:    */   }
/* 105:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.entity.DecompressingEntity
 * JD-Core Version:    0.7.0.1
 */