/*   1:    */ package com.lidroid.xutils.http.client.multipart.content;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.multipart.MultipartEntity.CallBackInfo;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.BufferedInputStream;
/*   6:    */ import java.io.File;
/*   7:    */ import java.io.FileInputStream;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.InputStream;
/*  10:    */ import java.io.InterruptedIOException;
/*  11:    */ import java.io.OutputStream;
/*  12:    */ 
/*  13:    */ public class FileBody
/*  14:    */   extends AbstractContentBody
/*  15:    */ {
/*  16:    */   private final File file;
/*  17:    */   private final String filename;
/*  18:    */   private final String charset;
/*  19:    */   
/*  20:    */   public FileBody(File file, String filename, String mimeType, String charset)
/*  21:    */   {
/*  22: 38 */     super(mimeType);
/*  23: 39 */     if (file == null) {
/*  24: 41 */       throw new IllegalArgumentException("File may not be null");
/*  25:    */     }
/*  26: 43 */     this.file = file;
/*  27: 44 */     if (filename != null) {
/*  28: 46 */       this.filename = filename;
/*  29:    */     } else {
/*  30: 49 */       this.filename = file.getName();
/*  31:    */     }
/*  32: 51 */     this.charset = charset;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public FileBody(File file, String mimeType, String charset)
/*  36:    */   {
/*  37: 59 */     this(file, null, mimeType, charset);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public FileBody(File file, String mimeType)
/*  41:    */   {
/*  42: 64 */     this(file, null, mimeType, null);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public FileBody(File file)
/*  46:    */   {
/*  47: 69 */     this(file, null, "application/octet-stream", null);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public InputStream getInputStream()
/*  51:    */     throws IOException
/*  52:    */   {
/*  53: 74 */     return new FileInputStream(this.file);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void writeTo(OutputStream out)
/*  57:    */     throws IOException
/*  58:    */   {
/*  59: 79 */     if (out == null) {
/*  60: 81 */       throw new IllegalArgumentException("Output stream may not be null");
/*  61:    */     }
/*  62: 83 */     BufferedInputStream in = null;
/*  63:    */     try
/*  64:    */     {
/*  65: 86 */       in = new BufferedInputStream(new FileInputStream(this.file));
/*  66: 87 */       byte[] tmp = new byte[4096];
/*  67:    */       int l;
/*  68: 89 */       while ((l = in.read(tmp)) != -1)
/*  69:    */       {
/*  70:    */         int l;
/*  71: 91 */         out.write(tmp, 0, l);
/*  72: 92 */         this.callBackInfo.pos += l;
/*  73: 93 */         if (!this.callBackInfo.doCallBack(false)) {
/*  74: 95 */           throw new InterruptedIOException("cancel");
/*  75:    */         }
/*  76:    */       }
/*  77: 98 */       out.flush();
/*  78:    */     }
/*  79:    */     finally
/*  80:    */     {
/*  81:101 */       IOUtils.closeQuietly(in);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String getTransferEncoding()
/*  86:    */   {
/*  87:107 */     return "binary";
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getCharset()
/*  91:    */   {
/*  92:112 */     return this.charset;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public long getContentLength()
/*  96:    */   {
/*  97:117 */     return this.file.length();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String getFilename()
/* 101:    */   {
/* 102:122 */     return this.filename;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public File getFile()
/* 106:    */   {
/* 107:127 */     return this.file;
/* 108:    */   }
/* 109:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.content.FileBody
 * JD-Core Version:    0.7.0.1
 */