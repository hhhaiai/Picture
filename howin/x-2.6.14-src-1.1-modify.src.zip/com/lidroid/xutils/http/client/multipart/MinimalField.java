/*  1:   */ package com.lidroid.xutils.http.client.multipart;
/*  2:   */ 
/*  3:   */ class MinimalField
/*  4:   */ {
/*  5:   */   private final String name;
/*  6:   */   private final String value;
/*  7:   */   
/*  8:   */   MinimalField(String name, String value)
/*  9:   */   {
/* 10:32 */     this.name = name;
/* 11:33 */     this.value = value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getName()
/* 15:   */   {
/* 16:38 */     return this.name;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getBody()
/* 20:   */   {
/* 21:43 */     return this.value;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:49 */     StringBuilder buffer = new StringBuilder();
/* 27:50 */     buffer.append(this.name);
/* 28:51 */     buffer.append(": ");
/* 29:52 */     buffer.append(this.value);
/* 30:53 */     return buffer.toString();
/* 31:   */   }
/* 32:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.MinimalField
 * JD-Core Version:    0.7.0.1
 */