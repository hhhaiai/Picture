/*   1:    */ package com.lidroid.xutils.http.client.multipart.content;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.multipart.MultipartEntity.CallBackInfo;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.InterruptedIOException;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ 
/*  10:    */ public class InputStreamBody
/*  11:    */   extends AbstractContentBody
/*  12:    */ {
/*  13:    */   private final InputStream in;
/*  14:    */   private final String filename;
/*  15:    */   private long length;
/*  16:    */   
/*  17:    */   public InputStreamBody(InputStream in, long length, String filename, String mimeType)
/*  18:    */   {
/*  19: 38 */     super(mimeType);
/*  20: 39 */     if (in == null) {
/*  21: 41 */       throw new IllegalArgumentException("Input stream may not be null");
/*  22:    */     }
/*  23: 43 */     this.in = in;
/*  24: 44 */     this.filename = filename;
/*  25: 45 */     this.length = length;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public InputStreamBody(InputStream in, long length, String filename)
/*  29:    */   {
/*  30: 50 */     this(in, length, filename, "application/octet-stream");
/*  31:    */   }
/*  32:    */   
/*  33:    */   public InputStreamBody(InputStream in, long length)
/*  34:    */   {
/*  35: 55 */     this(in, length, "no_name", "application/octet-stream");
/*  36:    */   }
/*  37:    */   
/*  38:    */   public InputStream getInputStream()
/*  39:    */   {
/*  40: 60 */     return this.in;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void writeTo(OutputStream out)
/*  44:    */     throws IOException
/*  45:    */   {
/*  46: 65 */     if (out == null) {
/*  47: 67 */       throw new IllegalArgumentException("Output stream may not be null");
/*  48:    */     }
/*  49:    */     try
/*  50:    */     {
/*  51: 71 */       byte[] tmp = new byte[4096];
/*  52:    */       int l;
/*  53: 73 */       while ((l = this.in.read(tmp)) != -1)
/*  54:    */       {
/*  55:    */         int l;
/*  56: 75 */         out.write(tmp, 0, l);
/*  57: 76 */         this.callBackInfo.pos += l;
/*  58: 77 */         if (!this.callBackInfo.doCallBack(false)) {
/*  59: 79 */           throw new InterruptedIOException("cancel");
/*  60:    */         }
/*  61:    */       }
/*  62: 82 */       out.flush();
/*  63:    */     }
/*  64:    */     finally
/*  65:    */     {
/*  66: 85 */       IOUtils.closeQuietly(this.in);
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getTransferEncoding()
/*  71:    */   {
/*  72: 91 */     return "binary";
/*  73:    */   }
/*  74:    */   
/*  75:    */   public String getCharset()
/*  76:    */   {
/*  77: 96 */     return null;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public long getContentLength()
/*  81:    */   {
/*  82:101 */     return this.length;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String getFilename()
/*  86:    */   {
/*  87:106 */     return this.filename;
/*  88:    */   }
/*  89:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.content.InputStreamBody
 * JD-Core Version:    0.7.0.1
 */