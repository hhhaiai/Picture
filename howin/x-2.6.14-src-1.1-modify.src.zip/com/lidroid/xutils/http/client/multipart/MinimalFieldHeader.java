/*   1:    */ package com.lidroid.xutils.http.client.multipart;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Locale;
/*  10:    */ import java.util.Map;
/*  11:    */ 
/*  12:    */ class MinimalFieldHeader
/*  13:    */   implements Iterable<MinimalField>
/*  14:    */ {
/*  15:    */   private final List<MinimalField> fields;
/*  16:    */   private final Map<String, List<MinimalField>> fieldMap;
/*  17:    */   
/*  18:    */   public MinimalFieldHeader()
/*  19:    */   {
/*  20: 32 */     this.fields = new LinkedList();
/*  21: 33 */     this.fieldMap = new HashMap();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void addField(MinimalField field)
/*  25:    */   {
/*  26: 38 */     if (field == null) {
/*  27: 40 */       return;
/*  28:    */     }
/*  29: 42 */     String key = field.getName().toLowerCase(Locale.US);
/*  30: 43 */     List<MinimalField> values = (List)this.fieldMap.get(key);
/*  31: 44 */     if (values == null)
/*  32:    */     {
/*  33: 46 */       values = new LinkedList();
/*  34: 47 */       this.fieldMap.put(key, values);
/*  35:    */     }
/*  36: 49 */     values.add(field);
/*  37: 50 */     this.fields.add(field);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public List<MinimalField> getFields()
/*  41:    */   {
/*  42: 55 */     return new ArrayList(this.fields);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public MinimalField getField(String name)
/*  46:    */   {
/*  47: 60 */     if (name == null) {
/*  48: 62 */       return null;
/*  49:    */     }
/*  50: 64 */     String key = name.toLowerCase(Locale.US);
/*  51: 65 */     List<MinimalField> list = (List)this.fieldMap.get(key);
/*  52: 66 */     if ((list != null) && (!list.isEmpty())) {
/*  53: 68 */       return (MinimalField)list.get(0);
/*  54:    */     }
/*  55: 70 */     return null;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public List<MinimalField> getFields(String name)
/*  59:    */   {
/*  60: 75 */     if (name == null) {
/*  61: 77 */       return null;
/*  62:    */     }
/*  63: 79 */     String key = name.toLowerCase(Locale.US);
/*  64: 80 */     List<MinimalField> list = (List)this.fieldMap.get(key);
/*  65: 81 */     if ((list == null) || (list.isEmpty())) {
/*  66: 83 */       return Collections.emptyList();
/*  67:    */     }
/*  68: 86 */     return new ArrayList(list);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public int removeFields(String name)
/*  72:    */   {
/*  73: 92 */     if (name == null) {
/*  74: 94 */       return 0;
/*  75:    */     }
/*  76: 96 */     String key = name.toLowerCase(Locale.US);
/*  77: 97 */     List<MinimalField> removed = (List)this.fieldMap.remove(key);
/*  78: 98 */     if ((removed == null) || (removed.isEmpty())) {
/*  79:100 */       return 0;
/*  80:    */     }
/*  81:102 */     this.fields.removeAll(removed);
/*  82:103 */     return removed.size();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setField(MinimalField field)
/*  86:    */   {
/*  87:108 */     if (field == null) {
/*  88:110 */       return;
/*  89:    */     }
/*  90:112 */     String key = field.getName().toLowerCase(Locale.US);
/*  91:113 */     List<MinimalField> list = (List)this.fieldMap.get(key);
/*  92:114 */     if ((list == null) || (list.isEmpty()))
/*  93:    */     {
/*  94:116 */       addField(field);
/*  95:117 */       return;
/*  96:    */     }
/*  97:119 */     list.clear();
/*  98:120 */     list.add(field);
/*  99:121 */     int firstOccurrence = -1;
/* 100:122 */     int index = 0;
/* 101:123 */     for (Iterator<MinimalField> it = this.fields.iterator(); it.hasNext(); index++)
/* 102:    */     {
/* 103:125 */       MinimalField f = (MinimalField)it.next();
/* 104:126 */       if (f.getName().equalsIgnoreCase(field.getName()))
/* 105:    */       {
/* 106:128 */         it.remove();
/* 107:129 */         if (firstOccurrence == -1) {
/* 108:131 */           firstOccurrence = index;
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:135 */     this.fields.add(firstOccurrence, field);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Iterator<MinimalField> iterator()
/* 116:    */   {
/* 117:140 */     return Collections.unmodifiableList(this.fields).iterator();
/* 118:    */   }
/* 119:    */   
/* 120:    */   public String toString()
/* 121:    */   {
/* 122:146 */     return this.fields.toString();
/* 123:    */   }
/* 124:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.MinimalFieldHeader
 * JD-Core Version:    0.7.0.1
 */