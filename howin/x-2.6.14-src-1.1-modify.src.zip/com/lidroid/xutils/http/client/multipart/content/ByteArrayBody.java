/*  1:   */ package com.lidroid.xutils.http.client.multipart.content;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.http.client.multipart.MultipartEntity.CallBackInfo;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.io.OutputStream;
/*  6:   */ 
/*  7:   */ public class ByteArrayBody
/*  8:   */   extends AbstractContentBody
/*  9:   */ {
/* 10:   */   private final byte[] data;
/* 11:   */   private final String filename;
/* 12:   */   
/* 13:   */   public ByteArrayBody(byte[] data, String mimeType, String filename)
/* 14:   */   {
/* 15:53 */     super(mimeType);
/* 16:54 */     if (data == null) {
/* 17:56 */       throw new IllegalArgumentException("byte[] may not be null");
/* 18:   */     }
/* 19:58 */     this.data = data;
/* 20:59 */     this.filename = filename;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public ByteArrayBody(byte[] data, String filename)
/* 24:   */   {
/* 25:72 */     this(data, "application/octet-stream", filename);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getFilename()
/* 29:   */   {
/* 30:77 */     return this.filename;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void writeTo(OutputStream out)
/* 34:   */     throws IOException
/* 35:   */   {
/* 36:82 */     out.write(this.data);
/* 37:83 */     this.callBackInfo.pos += this.data.length;
/* 38:84 */     this.callBackInfo.doCallBack(false);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String getCharset()
/* 42:   */   {
/* 43:89 */     return null;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public String getTransferEncoding()
/* 47:   */   {
/* 48:94 */     return "binary";
/* 49:   */   }
/* 50:   */   
/* 51:   */   public long getContentLength()
/* 52:   */   {
/* 53:99 */     return this.data.length;
/* 54:   */   }
/* 55:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.content.ByteArrayBody
 * JD-Core Version:    0.7.0.1
 */