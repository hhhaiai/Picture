/*   1:    */ package com.lidroid.xutils.http.client.multipart;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*   4:    */ import com.lidroid.xutils.http.client.entity.UploadEntity;
/*   5:    */ import com.lidroid.xutils.http.client.multipart.content.ContentBody;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.nio.charset.Charset;
/*  10:    */ import java.util.Random;
/*  11:    */ import org.apache.http.Header;
/*  12:    */ import org.apache.http.HttpEntity;
/*  13:    */ import org.apache.http.message.BasicHeader;
/*  14:    */ 
/*  15:    */ public class MultipartEntity
/*  16:    */   implements HttpEntity, UploadEntity
/*  17:    */ {
/*  18: 40 */   private CallBackInfo callBackInfo = new CallBackInfo();
/*  19:    */   
/*  20:    */   public void setCallBackHandler(RequestCallBackHandler callBackHandler)
/*  21:    */   {
/*  22: 45 */     this.callBackInfo.callBackHandler = callBackHandler;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static class CallBackInfo
/*  26:    */   {
/*  27: 51 */     public static final CallBackInfo DEFAULT = new CallBackInfo();
/*  28: 52 */     public RequestCallBackHandler callBackHandler = null;
/*  29: 53 */     public long totalLength = 0L;
/*  30: 54 */     public long pos = 0L;
/*  31:    */     
/*  32:    */     public boolean doCallBack(boolean forceUpdateUI)
/*  33:    */     {
/*  34: 62 */       if (this.callBackHandler != null) {
/*  35: 64 */         return this.callBackHandler.updateProgress(this.totalLength, this.pos, forceUpdateUI);
/*  36:    */       }
/*  37: 66 */       return true;
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41: 73 */   private static final char[] MULTIPART_CHARS = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
/*  42:    */   private final HttpMultipart multipart;
/*  43:    */   private Header contentType;
/*  44:    */   private long length;
/*  45:    */   private volatile boolean dirty;
/*  46:    */   private final String boundary;
/*  47:    */   private final Charset charset;
/*  48:    */   
/*  49:    */   public MultipartEntity(HttpMultipartMode mode, String boundary, Charset charset)
/*  50:    */   {
/*  51:103 */     if (boundary == null) {
/*  52:105 */       boundary = generateBoundary();
/*  53:    */     }
/*  54:107 */     this.boundary = boundary;
/*  55:108 */     if (mode == null) {
/*  56:110 */       mode = HttpMultipartMode.STRICT;
/*  57:    */     }
/*  58:112 */     this.charset = (charset != null ? charset : MIME.DEFAULT_CHARSET);
/*  59:113 */     this.multipart = new HttpMultipart(this.multipartSubtype, this.charset, this.boundary, mode);
/*  60:114 */     this.contentType = new BasicHeader("Content-Type", generateContentType(this.boundary, this.charset));
/*  61:115 */     this.dirty = true;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public MultipartEntity(HttpMultipartMode mode)
/*  65:    */   {
/*  66:127 */     this(mode, null, null);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public MultipartEntity()
/*  70:    */   {
/*  71:135 */     this(HttpMultipartMode.STRICT, null, null);
/*  72:    */   }
/*  73:    */   
/*  74:139 */   private String multipartSubtype = "form-data";
/*  75:    */   
/*  76:    */   public void setMultipartSubtype(String multipartSubtype)
/*  77:    */   {
/*  78:147 */     this.multipartSubtype = multipartSubtype;
/*  79:148 */     this.multipart.setSubType(multipartSubtype);
/*  80:149 */     this.contentType = new BasicHeader("Content-Type", generateContentType(this.boundary, this.charset));
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected String generateContentType(String boundary, Charset charset)
/*  84:    */   {
/*  85:154 */     StringBuilder buffer = new StringBuilder();
/*  86:155 */     buffer.append("multipart/" + this.multipartSubtype + "; boundary=");
/*  87:156 */     buffer.append(boundary);
/*  88:    */     
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:161 */     return buffer.toString();
/*  93:    */   }
/*  94:    */   
/*  95:    */   protected String generateBoundary()
/*  96:    */   {
/*  97:166 */     StringBuilder buffer = new StringBuilder();
/*  98:167 */     Random rand = new Random();
/*  99:168 */     int count = rand.nextInt(11) + 30;
/* 100:169 */     for (int i = 0; i < count; i++) {
/* 101:171 */       buffer.append(MULTIPART_CHARS[rand.nextInt(MULTIPART_CHARS.length)]);
/* 102:    */     }
/* 103:173 */     return buffer.toString();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void addPart(FormBodyPart bodyPart)
/* 107:    */   {
/* 108:178 */     this.multipart.addBodyPart(bodyPart);
/* 109:179 */     this.dirty = true;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void addPart(String name, ContentBody contentBody)
/* 113:    */   {
/* 114:184 */     addPart(new FormBodyPart(name, contentBody));
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void addPart(String name, ContentBody contentBody, String contentDisposition)
/* 118:    */   {
/* 119:189 */     addPart(new FormBodyPart(name, contentBody, contentDisposition));
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean isRepeatable()
/* 123:    */   {
/* 124:194 */     for (FormBodyPart part : this.multipart.getBodyParts())
/* 125:    */     {
/* 126:196 */       ContentBody body = part.getBody();
/* 127:197 */       if (body.getContentLength() < 0L) {
/* 128:199 */         return false;
/* 129:    */       }
/* 130:    */     }
/* 131:202 */     return true;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean isChunked()
/* 135:    */   {
/* 136:207 */     return !isRepeatable();
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean isStreaming()
/* 140:    */   {
/* 141:212 */     return !isRepeatable();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public long getContentLength()
/* 145:    */   {
/* 146:217 */     if (this.dirty)
/* 147:    */     {
/* 148:219 */       this.length = this.multipart.getTotalLength();
/* 149:220 */       this.dirty = false;
/* 150:    */     }
/* 151:222 */     return this.length;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public Header getContentType()
/* 155:    */   {
/* 156:227 */     return this.contentType;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public Header getContentEncoding()
/* 160:    */   {
/* 161:232 */     return null;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void consumeContent()
/* 165:    */     throws IOException, UnsupportedOperationException
/* 166:    */   {
/* 167:237 */     if (isStreaming()) {
/* 168:239 */       throw new UnsupportedOperationException("Streaming entity does not implement #consumeContent()");
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   public InputStream getContent()
/* 173:    */     throws IOException, UnsupportedOperationException
/* 174:    */   {
/* 175:245 */     throw new UnsupportedOperationException("Multipart form entity does not implement #getContent()");
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void writeTo(OutputStream outStream)
/* 179:    */     throws IOException
/* 180:    */   {
/* 181:250 */     this.callBackInfo.totalLength = getContentLength();
/* 182:251 */     this.multipart.writeTo(outStream, this.callBackInfo);
/* 183:    */   }
/* 184:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.MultipartEntity
 * JD-Core Version:    0.7.0.1
 */