/*   1:    */ package com.lidroid.xutils.http.client.multipart.content;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.multipart.MultipartEntity.CallBackInfo;
/*   4:    */ import java.io.ByteArrayInputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.io.InterruptedIOException;
/*   9:    */ import java.io.OutputStream;
/*  10:    */ import java.io.Reader;
/*  11:    */ import java.io.UnsupportedEncodingException;
/*  12:    */ import java.nio.charset.Charset;
/*  13:    */ 
/*  14:    */ public class StringBody
/*  15:    */   extends AbstractContentBody
/*  16:    */ {
/*  17:    */   private final byte[] content;
/*  18:    */   private final Charset charset;
/*  19:    */   
/*  20:    */   public static StringBody create(String text, String mimeType, Charset charset)
/*  21:    */     throws IllegalArgumentException
/*  22:    */   {
/*  23:    */     try
/*  24:    */     {
/*  25: 40 */       return new StringBody(text, mimeType, charset);
/*  26:    */     }
/*  27:    */     catch (UnsupportedEncodingException ex)
/*  28:    */     {
/*  29: 43 */       throw new IllegalArgumentException("Charset " + charset + " is not supported", ex);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static StringBody create(String text, Charset charset)
/*  34:    */     throws IllegalArgumentException
/*  35:    */   {
/*  36: 52 */     return create(text, null, charset);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static StringBody create(String text)
/*  40:    */     throws IllegalArgumentException
/*  41:    */   {
/*  42: 60 */     return create(text, null, null);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public StringBody(String text, String mimeType, Charset charset)
/*  46:    */     throws UnsupportedEncodingException
/*  47:    */   {
/*  48: 80 */     super(mimeType);
/*  49: 81 */     if (text == null) {
/*  50: 83 */       throw new IllegalArgumentException("Text may not be null");
/*  51:    */     }
/*  52: 85 */     if (charset == null) {
/*  53: 87 */       charset = Charset.forName("UTF-8");
/*  54:    */     }
/*  55: 89 */     this.content = text.getBytes(charset.name());
/*  56: 90 */     this.charset = charset;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public StringBody(String text, Charset charset)
/*  60:    */     throws UnsupportedEncodingException
/*  61:    */   {
/*  62:109 */     this(text, "text/plain", charset);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public StringBody(String text)
/*  66:    */     throws UnsupportedEncodingException
/*  67:    */   {
/*  68:125 */     this(text, "text/plain", null);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Reader getReader()
/*  72:    */   {
/*  73:130 */     return new InputStreamReader(new ByteArrayInputStream(this.content), this.charset);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void writeTo(OutputStream out)
/*  77:    */     throws IOException
/*  78:    */   {
/*  79:135 */     if (out == null) {
/*  80:137 */       throw new IllegalArgumentException("Output stream may not be null");
/*  81:    */     }
/*  82:139 */     InputStream in = new ByteArrayInputStream(this.content);
/*  83:140 */     byte[] tmp = new byte[4096];
/*  84:    */     int l;
/*  85:142 */     while ((l = in.read(tmp)) != -1)
/*  86:    */     {
/*  87:    */       int l;
/*  88:144 */       out.write(tmp, 0, l);
/*  89:145 */       this.callBackInfo.pos += l;
/*  90:146 */       if (!this.callBackInfo.doCallBack(false)) {
/*  91:148 */         throw new InterruptedIOException("cancel");
/*  92:    */       }
/*  93:    */     }
/*  94:151 */     out.flush();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String getTransferEncoding()
/*  98:    */   {
/*  99:156 */     return "8bit";
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String getCharset()
/* 103:    */   {
/* 104:161 */     return this.charset.name();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public long getContentLength()
/* 108:    */   {
/* 109:166 */     return this.content.length;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String getFilename()
/* 113:    */   {
/* 114:171 */     return null;
/* 115:    */   }
/* 116:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.content.StringBody
 * JD-Core Version:    0.7.0.1
 */