package com.lidroid.xutils.http.client.multipart;

public enum HttpMultipartMode
{
  STRICT,  BROWSER_COMPATIBLE;
}


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.HttpMultipartMode
 * JD-Core Version:    0.7.0.1
 */