/*  1:   */ package com.lidroid.xutils.http.client.multipart.content;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.http.client.multipart.MultipartEntity.CallBackInfo;
/*  4:   */ 
/*  5:   */ public abstract class AbstractContentBody
/*  6:   */   implements ContentBody
/*  7:   */ {
/*  8:   */   private final String mimeType;
/*  9:   */   private final String mediaType;
/* 10:   */   private final String subType;
/* 11:   */   
/* 12:   */   public AbstractContentBody(String mimeType)
/* 13:   */   {
/* 14:33 */     if (mimeType == null) {
/* 15:35 */       throw new IllegalArgumentException("MIME type may not be null");
/* 16:   */     }
/* 17:37 */     this.mimeType = mimeType;
/* 18:38 */     int i = mimeType.indexOf('/');
/* 19:39 */     if (i != -1)
/* 20:   */     {
/* 21:41 */       this.mediaType = mimeType.substring(0, i);
/* 22:42 */       this.subType = mimeType.substring(i + 1);
/* 23:   */     }
/* 24:   */     else
/* 25:   */     {
/* 26:45 */       this.mediaType = mimeType;
/* 27:46 */       this.subType = null;
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String getMimeType()
/* 32:   */   {
/* 33:52 */     return this.mimeType;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String getMediaType()
/* 37:   */   {
/* 38:57 */     return this.mediaType;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String getSubType()
/* 42:   */   {
/* 43:62 */     return this.subType;
/* 44:   */   }
/* 45:   */   
/* 46:65 */   protected MultipartEntity.CallBackInfo callBackInfo = MultipartEntity.CallBackInfo.DEFAULT;
/* 47:   */   
/* 48:   */   public void setCallBackInfo(MultipartEntity.CallBackInfo callBackInfo)
/* 49:   */   {
/* 50:70 */     this.callBackInfo = callBackInfo;
/* 51:   */   }
/* 52:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.content.AbstractContentBody
 * JD-Core Version:    0.7.0.1
 */