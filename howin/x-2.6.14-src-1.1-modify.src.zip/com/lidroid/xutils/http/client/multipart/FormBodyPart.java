/*   1:    */ package com.lidroid.xutils.http.client.multipart;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.multipart.content.ContentBody;
/*   4:    */ 
/*   5:    */ public class FormBodyPart
/*   6:    */ {
/*   7:    */   private final String name;
/*   8:    */   private final MinimalFieldHeader header;
/*   9:    */   private final ContentBody body;
/*  10:    */   
/*  11:    */   public FormBodyPart(String name, ContentBody body)
/*  12:    */   {
/*  13: 38 */     if (name == null) {
/*  14: 40 */       throw new IllegalArgumentException("Name may not be null");
/*  15:    */     }
/*  16: 42 */     if (body == null) {
/*  17: 44 */       throw new IllegalArgumentException("Body may not be null");
/*  18:    */     }
/*  19: 46 */     this.name = name;
/*  20: 47 */     this.body = body;
/*  21: 48 */     this.header = new MinimalFieldHeader();
/*  22:    */     
/*  23: 50 */     generateContentDisposition(body);
/*  24: 51 */     generateContentType(body);
/*  25: 52 */     generateTransferEncoding(body);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public FormBodyPart(String name, ContentBody body, String contentDisposition)
/*  29:    */   {
/*  30: 58 */     if (name == null) {
/*  31: 60 */       throw new IllegalArgumentException("Name may not be null");
/*  32:    */     }
/*  33: 62 */     if (body == null) {
/*  34: 64 */       throw new IllegalArgumentException("Body may not be null");
/*  35:    */     }
/*  36: 66 */     this.name = name;
/*  37: 67 */     this.body = body;
/*  38: 68 */     this.header = new MinimalFieldHeader();
/*  39: 70 */     if (contentDisposition != null) {
/*  40: 72 */       addField("Content-Disposition", contentDisposition);
/*  41:    */     } else {
/*  42: 75 */       generateContentDisposition(body);
/*  43:    */     }
/*  44: 77 */     generateContentType(body);
/*  45: 78 */     generateTransferEncoding(body);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getName()
/*  49:    */   {
/*  50: 83 */     return this.name;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public ContentBody getBody()
/*  54:    */   {
/*  55: 88 */     return this.body;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public MinimalFieldHeader getHeader()
/*  59:    */   {
/*  60: 93 */     return this.header;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void addField(String name, String value)
/*  64:    */   {
/*  65: 98 */     if (name == null) {
/*  66:100 */       throw new IllegalArgumentException("Field name may not be null");
/*  67:    */     }
/*  68:102 */     this.header.addField(new MinimalField(name, value));
/*  69:    */   }
/*  70:    */   
/*  71:    */   protected void generateContentDisposition(ContentBody body)
/*  72:    */   {
/*  73:107 */     StringBuilder buffer = new StringBuilder();
/*  74:108 */     buffer.append("form-data; name=\"");
/*  75:109 */     buffer.append(getName());
/*  76:110 */     buffer.append("\"");
/*  77:111 */     if (body.getFilename() != null)
/*  78:    */     {
/*  79:113 */       buffer.append("; filename=\"");
/*  80:114 */       buffer.append(body.getFilename());
/*  81:115 */       buffer.append("\"");
/*  82:    */     }
/*  83:117 */     addField("Content-Disposition", buffer.toString());
/*  84:    */   }
/*  85:    */   
/*  86:    */   protected void generateContentType(ContentBody body)
/*  87:    */   {
/*  88:122 */     StringBuilder buffer = new StringBuilder();
/*  89:123 */     buffer.append(body.getMimeType());
/*  90:124 */     if (body.getCharset() != null)
/*  91:    */     {
/*  92:126 */       buffer.append("; charset=");
/*  93:127 */       buffer.append(body.getCharset());
/*  94:    */     }
/*  95:129 */     addField("Content-Type", buffer.toString());
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected void generateTransferEncoding(ContentBody body)
/*  99:    */   {
/* 100:134 */     addField("Content-Transfer-Encoding", body.getTransferEncoding());
/* 101:    */   }
/* 102:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.FormBodyPart
 * JD-Core Version:    0.7.0.1
 */