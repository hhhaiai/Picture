/*   1:    */ package com.lidroid.xutils.http.client.multipart;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.client.multipart.content.ContentBody;
/*   4:    */ import java.io.ByteArrayOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InterruptedIOException;
/*   7:    */ import java.io.OutputStream;
/*   8:    */ import java.nio.ByteBuffer;
/*   9:    */ import java.nio.CharBuffer;
/*  10:    */ import java.nio.charset.Charset;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ import org.apache.http.util.ByteArrayBuffer;
/*  14:    */ 
/*  15:    */ class HttpMultipart
/*  16:    */ {
/*  17:    */   private static ByteArrayBuffer encode(Charset charset, String string)
/*  18:    */   {
/*  19: 43 */     ByteBuffer encoded = charset.encode(CharBuffer.wrap(string));
/*  20: 44 */     ByteArrayBuffer bab = new ByteArrayBuffer(encoded.remaining());
/*  21: 45 */     bab.append(encoded.array(), encoded.position(), encoded.remaining());
/*  22: 46 */     return bab;
/*  23:    */   }
/*  24:    */   
/*  25:    */   private static void writeBytes(ByteArrayBuffer b, OutputStream out)
/*  26:    */     throws IOException
/*  27:    */   {
/*  28: 51 */     out.write(b.buffer(), 0, b.length());
/*  29: 52 */     out.flush();
/*  30:    */   }
/*  31:    */   
/*  32:    */   private static void writeBytes(String s, Charset charset, OutputStream out)
/*  33:    */     throws IOException
/*  34:    */   {
/*  35: 57 */     ByteArrayBuffer b = encode(charset, s);
/*  36: 58 */     writeBytes(b, out);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private static void writeBytes(String s, OutputStream out)
/*  40:    */     throws IOException
/*  41:    */   {
/*  42: 63 */     ByteArrayBuffer b = encode(MIME.DEFAULT_CHARSET, s);
/*  43: 64 */     writeBytes(b, out);
/*  44:    */   }
/*  45:    */   
/*  46:    */   private static void writeField(MinimalField field, OutputStream out)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 69 */     writeBytes(field.getName(), out);
/*  50: 70 */     writeBytes(FIELD_SEP, out);
/*  51: 71 */     writeBytes(field.getBody(), out);
/*  52: 72 */     writeBytes(CR_LF, out);
/*  53:    */   }
/*  54:    */   
/*  55:    */   private static void writeField(MinimalField field, Charset charset, OutputStream out)
/*  56:    */     throws IOException
/*  57:    */   {
/*  58: 77 */     writeBytes(field.getName(), charset, out);
/*  59: 78 */     writeBytes(FIELD_SEP, out);
/*  60: 79 */     writeBytes(field.getBody(), charset, out);
/*  61: 80 */     writeBytes(CR_LF, out);
/*  62:    */   }
/*  63:    */   
/*  64: 83 */   private static final ByteArrayBuffer FIELD_SEP = encode(MIME.DEFAULT_CHARSET, ": ");
/*  65: 84 */   private static final ByteArrayBuffer CR_LF = encode(MIME.DEFAULT_CHARSET, "\r\n");
/*  66: 85 */   private static final ByteArrayBuffer TWO_DASHES = encode(MIME.DEFAULT_CHARSET, "--");
/*  67:    */   private String subType;
/*  68:    */   private final Charset charset;
/*  69:    */   private final String boundary;
/*  70:    */   private final List<FormBodyPart> parts;
/*  71:    */   private final HttpMultipartMode mode;
/*  72:    */   
/*  73:    */   public HttpMultipart(String subType, Charset charset, String boundary, HttpMultipartMode mode)
/*  74:    */   {
/*  75:112 */     if (subType == null) {
/*  76:114 */       throw new IllegalArgumentException("Multipart subtype may not be null");
/*  77:    */     }
/*  78:116 */     if (boundary == null) {
/*  79:118 */       throw new IllegalArgumentException("Multipart boundary may not be null");
/*  80:    */     }
/*  81:120 */     this.subType = subType;
/*  82:121 */     this.charset = (charset != null ? charset : MIME.DEFAULT_CHARSET);
/*  83:122 */     this.boundary = boundary;
/*  84:123 */     this.parts = new ArrayList();
/*  85:124 */     this.mode = mode;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public HttpMultipart(String subType, Charset charset, String boundary)
/*  89:    */   {
/*  90:143 */     this(subType, charset, boundary, HttpMultipartMode.STRICT);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public HttpMultipart(String subType, String boundary)
/*  94:    */   {
/*  95:148 */     this(subType, null, boundary);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setSubType(String subType)
/*  99:    */   {
/* 100:153 */     this.subType = subType;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getSubType()
/* 104:    */   {
/* 105:158 */     return this.subType;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Charset getCharset()
/* 109:    */   {
/* 110:163 */     return this.charset;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public HttpMultipartMode getMode()
/* 114:    */   {
/* 115:168 */     return this.mode;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public List<FormBodyPart> getBodyParts()
/* 119:    */   {
/* 120:173 */     return this.parts;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void addBodyPart(FormBodyPart part)
/* 124:    */   {
/* 125:178 */     if (part == null) {
/* 126:180 */       return;
/* 127:    */     }
/* 128:182 */     this.parts.add(part);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public String getBoundary()
/* 132:    */   {
/* 133:187 */     return this.boundary;
/* 134:    */   }
/* 135:    */   
/* 136:    */   private void doWriteTo(HttpMultipartMode mode, OutputStream out, boolean writeContent)
/* 137:    */     throws IOException
/* 138:    */   {
/* 139:192 */     doWriteTo(mode, out, MultipartEntity.CallBackInfo.DEFAULT, writeContent);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private void doWriteTo(HttpMultipartMode mode, OutputStream out, MultipartEntity.CallBackInfo callBackInfo, boolean writeContent)
/* 143:    */     throws IOException
/* 144:    */   {
/* 145:198 */     callBackInfo.pos = 0L;
/* 146:    */     
/* 147:200 */     ByteArrayBuffer boundary = encode(this.charset, getBoundary());
/* 148:201 */     for (FormBodyPart part : this.parts)
/* 149:    */     {
/* 150:203 */       if (!callBackInfo.doCallBack(true)) {
/* 151:205 */         throw new InterruptedIOException("cancel");
/* 152:    */       }
/* 153:207 */       writeBytes(TWO_DASHES, out);
/* 154:208 */       callBackInfo.pos += TWO_DASHES.length();
/* 155:209 */       writeBytes(boundary, out);
/* 156:210 */       callBackInfo.pos += boundary.length();
/* 157:211 */       writeBytes(CR_LF, out);
/* 158:212 */       callBackInfo.pos += CR_LF.length();
/* 159:    */       
/* 160:214 */       MinimalFieldHeader header = part.getHeader();
/* 161:216 */       switch (mode)
/* 162:    */       {
/* 163:    */       case BROWSER_COMPATIBLE: 
/* 164:219 */         for (MinimalField field : header)
/* 165:    */         {
/* 166:221 */           writeField(field, out);
/* 167:222 */           callBackInfo.pos += encode(MIME.DEFAULT_CHARSET, field.getName() + field.getBody()).length() + FIELD_SEP.length() + CR_LF.length();
/* 168:    */         }
/* 169:224 */         break;
/* 170:    */       case STRICT: 
/* 171:228 */         MinimalField cd = header.getField("Content-Disposition");
/* 172:229 */         writeField(cd, this.charset, out);
/* 173:230 */         callBackInfo.pos += encode(this.charset, cd.getName() + cd.getBody()).length() + FIELD_SEP.length() + CR_LF.length();
/* 174:231 */         String filename = part.getBody().getFilename();
/* 175:232 */         if (filename != null)
/* 176:    */         {
/* 177:234 */           MinimalField ct = header.getField("Content-Type");
/* 178:235 */           writeField(ct, this.charset, out);
/* 179:236 */           callBackInfo.pos += encode(this.charset, ct.getName() + ct.getBody()).length() + FIELD_SEP.length() + CR_LF.length();
/* 180:    */         }
/* 181:238 */         break;
/* 182:    */       }
/* 183:242 */       writeBytes(CR_LF, out);
/* 184:243 */       callBackInfo.pos += CR_LF.length();
/* 185:245 */       if (writeContent)
/* 186:    */       {
/* 187:247 */         ContentBody body = part.getBody();
/* 188:248 */         body.setCallBackInfo(callBackInfo);
/* 189:249 */         body.writeTo(out);
/* 190:    */       }
/* 191:251 */       writeBytes(CR_LF, out);
/* 192:252 */       callBackInfo.pos += CR_LF.length();
/* 193:    */     }
/* 194:254 */     writeBytes(TWO_DASHES, out);
/* 195:255 */     callBackInfo.pos += TWO_DASHES.length();
/* 196:256 */     writeBytes(boundary, out);
/* 197:257 */     callBackInfo.pos += boundary.length();
/* 198:258 */     writeBytes(TWO_DASHES, out);
/* 199:259 */     callBackInfo.pos += TWO_DASHES.length();
/* 200:260 */     writeBytes(CR_LF, out);
/* 201:261 */     callBackInfo.pos += CR_LF.length();
/* 202:262 */     callBackInfo.doCallBack(true);
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void writeTo(OutputStream out, MultipartEntity.CallBackInfo callBackInfo)
/* 206:    */     throws IOException
/* 207:    */   {
/* 208:274 */     doWriteTo(this.mode, out, callBackInfo, true);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public long getTotalLength()
/* 212:    */   {
/* 213:293 */     long contentLen = 0L;
/* 214:294 */     for (FormBodyPart part : this.parts)
/* 215:    */     {
/* 216:296 */       ContentBody body = part.getBody();
/* 217:297 */       long len = body.getContentLength();
/* 218:298 */       if (len >= 0L) {
/* 219:300 */         contentLen += len;
/* 220:    */       } else {
/* 221:303 */         return -1L;
/* 222:    */       }
/* 223:    */     }
/* 224:306 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 225:    */     try
/* 226:    */     {
/* 227:309 */       doWriteTo(this.mode, out, false);
/* 228:310 */       byte[] extra = out.toByteArray();
/* 229:311 */       return contentLen + extra.length;
/* 230:    */     }
/* 231:    */     catch (Throwable ex) {}
/* 232:315 */     return -1L;
/* 233:    */   }
/* 234:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.multipart.HttpMultipart
 * JD-Core Version:    0.7.0.1
 */