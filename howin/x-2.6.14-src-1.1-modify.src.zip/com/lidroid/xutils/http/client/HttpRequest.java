/*   1:    */ package com.lidroid.xutils.http.client;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.http.RequestParams;
/*   4:    */ import com.lidroid.xutils.http.RequestParams.HeaderItem;
/*   5:    */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*   6:    */ import com.lidroid.xutils.http.client.entity.UploadEntity;
/*   7:    */ import com.lidroid.xutils.http.client.util.URIBuilder;
/*   8:    */ import com.lidroid.xutils.util.LogUtils;
/*   9:    */ import com.lidroid.xutils.util.OtherUtils;
/*  10:    */ import java.net.URI;
/*  11:    */ import java.net.URISyntaxException;
/*  12:    */ import java.nio.charset.Charset;
/*  13:    */ import java.util.List;
/*  14:    */ import org.apache.http.Header;
/*  15:    */ import org.apache.http.HttpEntity;
/*  16:    */ import org.apache.http.HttpEntityEnclosingRequest;
/*  17:    */ import org.apache.http.NameValuePair;
/*  18:    */ import org.apache.http.client.methods.HttpRequestBase;
/*  19:    */ import org.apache.http.client.utils.CloneUtils;
/*  20:    */ 
/*  21:    */ public class HttpRequest
/*  22:    */   extends HttpRequestBase
/*  23:    */   implements HttpEntityEnclosingRequest
/*  24:    */ {
/*  25:    */   private HttpEntity entity;
/*  26:    */   private HttpMethod method;
/*  27:    */   private URIBuilder uriBuilder;
/*  28:    */   private Charset uriCharset;
/*  29:    */   
/*  30:    */   public HttpRequest(HttpMethod method)
/*  31:    */   {
/*  32: 54 */     this.method = method;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public HttpRequest(HttpMethod method, String uri)
/*  36:    */   {
/*  37: 60 */     this.method = method;
/*  38: 61 */     setURI(uri);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public HttpRequest(HttpMethod method, URI uri)
/*  42:    */   {
/*  43: 67 */     this.method = method;
/*  44: 68 */     setURI(uri);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public HttpRequest addQueryStringParameter(String name, String value)
/*  48:    */   {
/*  49: 73 */     this.uriBuilder.addParameter(name, value);
/*  50: 74 */     return this;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public HttpRequest addQueryStringParameter(NameValuePair nameValuePair)
/*  54:    */   {
/*  55: 79 */     this.uriBuilder.addParameter(nameValuePair.getName(), nameValuePair.getValue());
/*  56: 80 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public HttpRequest addQueryStringParams(List<NameValuePair> nameValuePairs)
/*  60:    */   {
/*  61: 85 */     if (nameValuePairs != null) {
/*  62: 87 */       for (NameValuePair nameValuePair : nameValuePairs) {
/*  63: 89 */         this.uriBuilder.addParameter(nameValuePair.getName(), nameValuePair.getValue());
/*  64:    */       }
/*  65:    */     }
/*  66: 92 */     return this;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setRequestParams(RequestParams param)
/*  70:    */   {
/*  71: 97 */     if (param != null)
/*  72:    */     {
/*  73: 99 */       if (this.uriCharset == null) {
/*  74:101 */         this.uriCharset = Charset.forName(param.getCharset());
/*  75:    */       }
/*  76:103 */       List<RequestParams.HeaderItem> headerItems = param.getHeaders();
/*  77:104 */       if (headerItems != null) {
/*  78:106 */         for (RequestParams.HeaderItem headerItem : headerItems) {
/*  79:108 */           if (headerItem.overwrite) {
/*  80:110 */             setHeader(headerItem.header);
/*  81:    */           } else {
/*  82:113 */             addHeader(headerItem.header);
/*  83:    */           }
/*  84:    */         }
/*  85:    */       }
/*  86:117 */       addQueryStringParams(param.getQueryStringParams());
/*  87:118 */       setEntity(param.getEntity());
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setRequestParams(RequestParams param, RequestCallBackHandler callBackHandler)
/*  92:    */   {
/*  93:124 */     if (param != null)
/*  94:    */     {
/*  95:126 */       if (this.uriCharset == null) {
/*  96:128 */         this.uriCharset = Charset.forName(param.getCharset());
/*  97:    */       }
/*  98:130 */       List<RequestParams.HeaderItem> headerItems = param.getHeaders();
/*  99:131 */       if (headerItems != null) {
/* 100:133 */         for (RequestParams.HeaderItem headerItem : headerItems) {
/* 101:135 */           if (headerItem.overwrite) {
/* 102:137 */             setHeader(headerItem.header);
/* 103:    */           } else {
/* 104:140 */             addHeader(headerItem.header);
/* 105:    */           }
/* 106:    */         }
/* 107:    */       }
/* 108:144 */       addQueryStringParams(param.getQueryStringParams());
/* 109:145 */       HttpEntity entity = param.getEntity();
/* 110:146 */       if (entity != null)
/* 111:    */       {
/* 112:148 */         if ((entity instanceof UploadEntity)) {
/* 113:150 */           ((UploadEntity)entity).setCallBackHandler(callBackHandler);
/* 114:    */         }
/* 115:152 */         setEntity(entity);
/* 116:    */       }
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public URI getURI()
/* 121:    */   {
/* 122:    */     try
/* 123:    */     {
/* 124:162 */       if (this.uriCharset == null) {
/* 125:164 */         this.uriCharset = OtherUtils.getCharsetFromHttpRequest(this);
/* 126:    */       }
/* 127:166 */       if (this.uriCharset == null) {
/* 128:168 */         this.uriCharset = Charset.forName("UTF-8");
/* 129:    */       }
/* 130:170 */       return this.uriBuilder.build(this.uriCharset);
/* 131:    */     }
/* 132:    */     catch (URISyntaxException e)
/* 133:    */     {
/* 134:173 */       LogUtils.e(e.getMessage(), e);
/* 135:    */     }
/* 136:174 */     return null;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void setURI(URI uri)
/* 140:    */   {
/* 141:181 */     this.uriBuilder = new URIBuilder(uri);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setURI(String uri)
/* 145:    */   {
/* 146:186 */     this.uriBuilder = new URIBuilder(uri);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public String getMethod()
/* 150:    */   {
/* 151:192 */     return this.method.toString();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public HttpEntity getEntity()
/* 155:    */   {
/* 156:198 */     return this.entity;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setEntity(HttpEntity entity)
/* 160:    */   {
/* 161:204 */     this.entity = entity;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean expectContinue()
/* 165:    */   {
/* 166:210 */     Header expect = getFirstHeader("Expect");
/* 167:211 */     return (expect != null) && ("100-continue".equalsIgnoreCase(expect.getValue()));
/* 168:    */   }
/* 169:    */   
/* 170:    */   public Object clone()
/* 171:    */     throws CloneNotSupportedException
/* 172:    */   {
/* 173:217 */     HttpRequest clone = (HttpRequest)super.clone();
/* 174:218 */     if (this.entity != null) {
/* 175:220 */       clone.entity = ((HttpEntity)CloneUtils.clone(this.entity));
/* 176:    */     }
/* 177:222 */     return clone;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static enum HttpMethod
/* 181:    */   {
/* 182:227 */     GET("GET"),  POST("POST"),  PUT("PUT"),  HEAD("HEAD"),  MOVE("MOVE"),  COPY("COPY"),  DELETE("DELETE"),  OPTIONS("OPTIONS"),  TRACE("TRACE"),  CONNECT("CONNECT");
/* 183:    */     
/* 184:    */     private final String value;
/* 185:    */     
/* 186:    */     private HttpMethod(String value)
/* 187:    */     {
/* 188:233 */       this.value = value;
/* 189:    */     }
/* 190:    */     
/* 191:    */     public String toString()
/* 192:    */     {
/* 193:239 */       return this.value;
/* 194:    */     }
/* 195:    */   }
/* 196:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.HttpRequest
 * JD-Core Version:    0.7.0.1
 */