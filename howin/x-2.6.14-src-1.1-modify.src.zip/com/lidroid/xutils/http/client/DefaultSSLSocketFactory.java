/*  1:   */ package com.lidroid.xutils.http.client;
/*  2:   */ 
/*  3:   */ import com.lidroid.xutils.util.LogUtils;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.net.Socket;
/*  6:   */ import java.security.KeyManagementException;
/*  7:   */ import java.security.KeyStore;
/*  8:   */ import java.security.KeyStoreException;
/*  9:   */ import java.security.NoSuchAlgorithmException;
/* 10:   */ import java.security.UnrecoverableKeyException;
/* 11:   */ import java.security.cert.CertificateException;
/* 12:   */ import java.security.cert.X509Certificate;
/* 13:   */ import javax.net.ssl.SSLContext;
/* 14:   */ import javax.net.ssl.TrustManager;
/* 15:   */ import javax.net.ssl.X509TrustManager;
/* 16:   */ 
/* 17:   */ public class DefaultSSLSocketFactory
/* 18:   */   extends org.apache.http.conn.ssl.SSLSocketFactory
/* 19:   */ {
/* 20:19 */   private SSLContext sslContext = SSLContext.getInstance("TLS");
/* 21:   */   private static KeyStore trustStore;
/* 22:   */   private static DefaultSSLSocketFactory instance;
/* 23:   */   
/* 24:   */   static
/* 25:   */   {
/* 26:   */     try
/* 27:   */     {
/* 28:27 */       trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
/* 29:28 */       trustStore.load(null, null);
/* 30:   */     }
/* 31:   */     catch (Throwable e)
/* 32:   */     {
/* 33:31 */       LogUtils.e(e.getMessage(), e);
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static DefaultSSLSocketFactory getSocketFactory()
/* 38:   */   {
/* 39:39 */     if (instance == null) {
/* 40:   */       try
/* 41:   */       {
/* 42:43 */         instance = new DefaultSSLSocketFactory();
/* 43:   */       }
/* 44:   */       catch (Throwable e)
/* 45:   */       {
/* 46:46 */         LogUtils.e(e.getMessage(), e);
/* 47:   */       }
/* 48:   */     }
/* 49:49 */     return instance;
/* 50:   */   }
/* 51:   */   
/* 52:   */   private DefaultSSLSocketFactory()
/* 53:   */     throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException
/* 54:   */   {
/* 55:54 */     super(trustStore);
/* 56:   */     
/* 57:56 */     TrustManager trustAllCerts = new X509TrustManager()
/* 58:   */     {
/* 59:   */       public X509Certificate[] getAcceptedIssuers()
/* 60:   */       {
/* 61:60 */         return null;
/* 62:   */       }
/* 63:   */       
/* 64:   */       public void checkClientTrusted(X509Certificate[] chain, String authType)
/* 65:   */         throws CertificateException
/* 66:   */       {}
/* 67:   */       
/* 68:   */       public void checkServerTrusted(X509Certificate[] chain, String authType)
/* 69:   */         throws CertificateException
/* 70:   */       {}
/* 71:72 */     };
/* 72:73 */     this.sslContext.init(null, new TrustManager[] { trustAllCerts }, null);
/* 73:   */     
/* 74:75 */     setHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
/* 75:   */   }
/* 76:   */   
/* 77:   */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
/* 78:   */     throws IOException
/* 79:   */   {
/* 80:81 */     return this.sslContext.getSocketFactory().createSocket(socket, host, port, autoClose);
/* 81:   */   }
/* 82:   */   
/* 83:   */   public Socket createSocket()
/* 84:   */     throws IOException
/* 85:   */   {
/* 86:87 */     return this.sslContext.getSocketFactory().createSocket();
/* 87:   */   }
/* 88:   */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.DefaultSSLSocketFactory
 * JD-Core Version:    0.7.0.1
 */