/*   1:    */ package com.lidroid.xutils.http.client.util;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.util.LogUtils;
/*   5:    */ import java.net.URI;
/*   6:    */ import java.net.URISyntaxException;
/*   7:    */ import java.nio.charset.Charset;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.List;
/*  11:    */ import org.apache.http.NameValuePair;
/*  12:    */ import org.apache.http.conn.util.InetAddressUtils;
/*  13:    */ import org.apache.http.message.BasicNameValuePair;
/*  14:    */ 
/*  15:    */ public class URIBuilder
/*  16:    */ {
/*  17:    */   private String scheme;
/*  18:    */   private String encodedSchemeSpecificPart;
/*  19:    */   private String encodedAuthority;
/*  20:    */   private String userInfo;
/*  21:    */   private String encodedUserInfo;
/*  22:    */   private String host;
/*  23:    */   private int port;
/*  24:    */   private String path;
/*  25:    */   private String encodedPath;
/*  26:    */   private String encodedQuery;
/*  27:    */   private List<NameValuePair> queryParams;
/*  28:    */   private String fragment;
/*  29:    */   private String encodedFragment;
/*  30:    */   
/*  31:    */   public URIBuilder()
/*  32:    */   {
/*  33: 50 */     this.port = -1;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public URIBuilder(String uri)
/*  37:    */   {
/*  38:    */     try
/*  39:    */     {
/*  40: 57 */       digestURI(new URI(uri));
/*  41:    */     }
/*  42:    */     catch (URISyntaxException e)
/*  43:    */     {
/*  44: 60 */       LogUtils.e(e.getMessage(), e);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public URIBuilder(URI uri)
/*  49:    */   {
/*  50: 66 */     digestURI(uri);
/*  51:    */   }
/*  52:    */   
/*  53:    */   private void digestURI(URI uri)
/*  54:    */   {
/*  55: 71 */     this.scheme = uri.getScheme();
/*  56: 72 */     this.encodedSchemeSpecificPart = uri.getRawSchemeSpecificPart();
/*  57: 73 */     this.encodedAuthority = uri.getRawAuthority();
/*  58: 74 */     this.host = uri.getHost();
/*  59: 75 */     this.port = uri.getPort();
/*  60: 76 */     this.encodedUserInfo = uri.getRawUserInfo();
/*  61: 77 */     this.userInfo = uri.getUserInfo();
/*  62: 78 */     this.encodedPath = uri.getRawPath();
/*  63: 79 */     this.path = uri.getPath();
/*  64: 80 */     this.encodedQuery = uri.getRawQuery();
/*  65: 81 */     this.queryParams = parseQuery(uri.getRawQuery());
/*  66: 82 */     this.encodedFragment = uri.getRawFragment();
/*  67: 83 */     this.fragment = uri.getFragment();
/*  68:    */   }
/*  69:    */   
/*  70:    */   private List<NameValuePair> parseQuery(String query)
/*  71:    */   {
/*  72: 88 */     if (!TextUtils.isEmpty(query)) {
/*  73: 90 */       return URLEncodedUtils.parse(query);
/*  74:    */     }
/*  75: 92 */     return null;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public URI build(Charset charset)
/*  79:    */     throws URISyntaxException
/*  80:    */   {
/*  81:102 */     return new URI(buildString(charset));
/*  82:    */   }
/*  83:    */   
/*  84:    */   private String buildString(Charset charset)
/*  85:    */   {
/*  86:107 */     StringBuilder sb = new StringBuilder();
/*  87:108 */     if (this.scheme != null) {
/*  88:110 */       sb.append(this.scheme).append(':');
/*  89:    */     }
/*  90:112 */     if (this.encodedSchemeSpecificPart != null)
/*  91:    */     {
/*  92:114 */       sb.append(this.encodedSchemeSpecificPart);
/*  93:    */     }
/*  94:    */     else
/*  95:    */     {
/*  96:117 */       if (this.encodedAuthority != null)
/*  97:    */       {
/*  98:119 */         sb.append("//").append(this.encodedAuthority);
/*  99:    */       }
/* 100:120 */       else if (this.host != null)
/* 101:    */       {
/* 102:122 */         sb.append("//");
/* 103:123 */         if (this.encodedUserInfo != null) {
/* 104:125 */           sb.append(this.encodedUserInfo).append("@");
/* 105:126 */         } else if (this.userInfo != null) {
/* 106:128 */           sb.append(encodeUserInfo(this.userInfo, charset)).append("@");
/* 107:    */         }
/* 108:130 */         if (InetAddressUtils.isIPv6Address(this.host)) {
/* 109:132 */           sb.append("[").append(this.host).append("]");
/* 110:    */         } else {
/* 111:135 */           sb.append(this.host);
/* 112:    */         }
/* 113:137 */         if (this.port >= 0) {
/* 114:139 */           sb.append(":").append(this.port);
/* 115:    */         }
/* 116:    */       }
/* 117:142 */       if (this.encodedPath != null) {
/* 118:144 */         sb.append(normalizePath(this.encodedPath));
/* 119:145 */       } else if (this.path != null) {
/* 120:147 */         sb.append(encodePath(normalizePath(this.path), charset));
/* 121:    */       }
/* 122:149 */       if (this.encodedQuery != null) {
/* 123:151 */         sb.append("?").append(this.encodedQuery);
/* 124:152 */       } else if (this.queryParams != null) {
/* 125:154 */         sb.append("?").append(encodeQuery(this.queryParams, charset));
/* 126:    */       }
/* 127:    */     }
/* 128:157 */     if (this.encodedFragment != null) {
/* 129:159 */       sb.append("#").append(this.encodedFragment);
/* 130:160 */     } else if (this.fragment != null) {
/* 131:162 */       sb.append("#").append(encodeFragment(this.fragment, charset));
/* 132:    */     }
/* 133:164 */     return sb.toString();
/* 134:    */   }
/* 135:    */   
/* 136:    */   private String encodeUserInfo(String userInfo, Charset charset)
/* 137:    */   {
/* 138:169 */     return URLEncodedUtils.encUserInfo(userInfo, charset);
/* 139:    */   }
/* 140:    */   
/* 141:    */   private String encodePath(String path, Charset charset)
/* 142:    */   {
/* 143:174 */     return URLEncodedUtils.encPath(path, charset).replace("+", "20%");
/* 144:    */   }
/* 145:    */   
/* 146:    */   private String encodeQuery(List<NameValuePair> params, Charset charset)
/* 147:    */   {
/* 148:179 */     return URLEncodedUtils.format(params, charset);
/* 149:    */   }
/* 150:    */   
/* 151:    */   private String encodeFragment(String fragment, Charset charset)
/* 152:    */   {
/* 153:184 */     return URLEncodedUtils.encFragment(fragment, charset);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public URIBuilder setScheme(String scheme)
/* 157:    */   {
/* 158:192 */     this.scheme = scheme;
/* 159:193 */     return this;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public URIBuilder setUserInfo(String userInfo)
/* 163:    */   {
/* 164:202 */     this.userInfo = userInfo;
/* 165:203 */     this.encodedSchemeSpecificPart = null;
/* 166:204 */     this.encodedAuthority = null;
/* 167:205 */     this.encodedUserInfo = null;
/* 168:206 */     return this;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public URIBuilder setUserInfo(String username, String password)
/* 172:    */   {
/* 173:215 */     return setUserInfo(username + ':' + password);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public URIBuilder setHost(String host)
/* 177:    */   {
/* 178:223 */     this.host = host;
/* 179:224 */     this.encodedSchemeSpecificPart = null;
/* 180:225 */     this.encodedAuthority = null;
/* 181:226 */     return this;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public URIBuilder setPort(int port)
/* 185:    */   {
/* 186:234 */     this.port = (port < 0 ? -1 : port);
/* 187:235 */     this.encodedSchemeSpecificPart = null;
/* 188:236 */     this.encodedAuthority = null;
/* 189:237 */     return this;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public URIBuilder setPath(String path)
/* 193:    */   {
/* 194:246 */     this.path = path;
/* 195:247 */     this.encodedSchemeSpecificPart = null;
/* 196:248 */     this.encodedPath = null;
/* 197:249 */     return this;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public URIBuilder setQuery(String query)
/* 201:    */   {
/* 202:259 */     this.queryParams = parseQuery(query);
/* 203:260 */     this.encodedQuery = null;
/* 204:261 */     this.encodedSchemeSpecificPart = null;
/* 205:262 */     return this;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public URIBuilder addParameter(String param, String value)
/* 209:    */   {
/* 210:271 */     if (this.queryParams == null) {
/* 211:273 */       this.queryParams = new ArrayList();
/* 212:    */     }
/* 213:275 */     this.queryParams.add(new BasicNameValuePair(param, value));
/* 214:276 */     this.encodedQuery = null;
/* 215:277 */     this.encodedSchemeSpecificPart = null;
/* 216:278 */     return this;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public URIBuilder setParameter(String param, String value)
/* 220:    */   {
/* 221:288 */     if (this.queryParams == null) {
/* 222:290 */       this.queryParams = new ArrayList();
/* 223:    */     }
/* 224:292 */     if (!this.queryParams.isEmpty()) {
/* 225:294 */       for (Iterator<NameValuePair> it = this.queryParams.iterator(); it.hasNext();)
/* 226:    */       {
/* 227:296 */         NameValuePair nvp = (NameValuePair)it.next();
/* 228:297 */         if (nvp.getName().equals(param)) {
/* 229:299 */           it.remove();
/* 230:    */         }
/* 231:    */       }
/* 232:    */     }
/* 233:303 */     this.queryParams.add(new BasicNameValuePair(param, value));
/* 234:304 */     this.encodedQuery = null;
/* 235:305 */     this.encodedSchemeSpecificPart = null;
/* 236:306 */     return this;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public URIBuilder setFragment(String fragment)
/* 240:    */   {
/* 241:315 */     this.fragment = fragment;
/* 242:316 */     this.encodedFragment = null;
/* 243:317 */     return this;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public String getScheme()
/* 247:    */   {
/* 248:322 */     return this.scheme;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public String getUserInfo()
/* 252:    */   {
/* 253:327 */     return this.userInfo;
/* 254:    */   }
/* 255:    */   
/* 256:    */   public String getHost()
/* 257:    */   {
/* 258:332 */     return this.host;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public int getPort()
/* 262:    */   {
/* 263:337 */     return this.port;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public String getPath()
/* 267:    */   {
/* 268:342 */     return this.path;
/* 269:    */   }
/* 270:    */   
/* 271:    */   public List<NameValuePair> getQueryParams()
/* 272:    */   {
/* 273:347 */     if (this.queryParams != null) {
/* 274:349 */       return new ArrayList(this.queryParams);
/* 275:    */     }
/* 276:352 */     return new ArrayList();
/* 277:    */   }
/* 278:    */   
/* 279:    */   public String getFragment()
/* 280:    */   {
/* 281:358 */     return this.fragment;
/* 282:    */   }
/* 283:    */   
/* 284:    */   private static String normalizePath(String path)
/* 285:    */   {
/* 286:363 */     if (path == null) {
/* 287:365 */       return null;
/* 288:    */     }
/* 289:367 */     for (int n = 0; n < path.length(); n++) {
/* 290:370 */       if (path.charAt(n) != '/') {
/* 291:    */         break;
/* 292:    */       }
/* 293:    */     }
/* 294:375 */     if (n > 1) {
/* 295:377 */       path = path.substring(n - 1);
/* 296:    */     }
/* 297:379 */     return path;
/* 298:    */   }
/* 299:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.util.URIBuilder
 * JD-Core Version:    0.7.0.1
 */