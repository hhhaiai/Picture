/*   1:    */ package com.lidroid.xutils.http.client.util;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import java.net.URI;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.nio.CharBuffer;
/*   7:    */ import java.nio.charset.Charset;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.BitSet;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Scanner;
/*  13:    */ import org.apache.http.Header;
/*  14:    */ import org.apache.http.HeaderElement;
/*  15:    */ import org.apache.http.HttpEntity;
/*  16:    */ import org.apache.http.NameValuePair;
/*  17:    */ import org.apache.http.message.BasicHeaderValueParser;
/*  18:    */ import org.apache.http.message.BasicNameValuePair;
/*  19:    */ import org.apache.http.message.ParserCursor;
/*  20:    */ import org.apache.http.util.CharArrayBuffer;
/*  21:    */ 
/*  22:    */ public class URLEncodedUtils
/*  23:    */ {
/*  24:    */   public static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
/*  25:    */   private static final String PARAMETER_SEPARATOR = "&";
/*  26:    */   private static final String NAME_VALUE_SEPARATOR = "=";
/*  27:    */   
/*  28:    */   public static boolean isEncoded(HttpEntity entity)
/*  29:    */   {
/*  30: 53 */     Header h = entity.getContentType();
/*  31: 54 */     if (h != null)
/*  32:    */     {
/*  33: 56 */       HeaderElement[] elems = h.getElements();
/*  34: 57 */       if (elems.length > 0)
/*  35:    */       {
/*  36: 59 */         String contentType = elems[0].getName();
/*  37: 60 */         return contentType.equalsIgnoreCase("application/x-www-form-urlencoded");
/*  38:    */       }
/*  39: 63 */       return false;
/*  40:    */     }
/*  41: 67 */     return false;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static List<NameValuePair> parse(URI uri)
/*  45:    */   {
/*  46: 84 */     String query = uri.getRawQuery();
/*  47: 85 */     if (!TextUtils.isEmpty(query))
/*  48:    */     {
/*  49: 87 */       List<NameValuePair> result = new ArrayList();
/*  50: 88 */       Scanner scanner = new Scanner(query);
/*  51: 89 */       parse(result, scanner);
/*  52: 90 */       return result;
/*  53:    */     }
/*  54: 93 */     return Collections.emptyList();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static void parse(List<NameValuePair> parameters, Scanner scanner)
/*  58:    */   {
/*  59:111 */     scanner.useDelimiter("&");
/*  60:112 */     while (scanner.hasNext())
/*  61:    */     {
/*  62:114 */       String name = null;
/*  63:115 */       String value = null;
/*  64:116 */       String token = scanner.next();
/*  65:117 */       int i = token.indexOf("=");
/*  66:118 */       if (i != -1)
/*  67:    */       {
/*  68:120 */         name = token.substring(0, i).trim();
/*  69:121 */         value = token.substring(i + 1).trim();
/*  70:    */       }
/*  71:    */       else
/*  72:    */       {
/*  73:124 */         name = token.trim();
/*  74:    */       }
/*  75:126 */       parameters.add(new BasicNameValuePair(name, value));
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:130 */   private static final char[] DELIM = { '&' };
/*  80:    */   
/*  81:    */   public static List<NameValuePair> parse(String s)
/*  82:    */   {
/*  83:142 */     if (s == null) {
/*  84:144 */       return Collections.emptyList();
/*  85:    */     }
/*  86:146 */     BasicHeaderValueParser parser = BasicHeaderValueParser.DEFAULT;
/*  87:147 */     CharArrayBuffer buffer = new CharArrayBuffer(s.length());
/*  88:148 */     buffer.append(s);
/*  89:149 */     ParserCursor cursor = new ParserCursor(0, buffer.length());
/*  90:150 */     List<NameValuePair> list = new ArrayList();
/*  91:151 */     while (!cursor.atEnd())
/*  92:    */     {
/*  93:153 */       NameValuePair nvp = parser.parseNameValuePair(buffer, cursor, DELIM);
/*  94:154 */       if (nvp.getName().length() > 0) {
/*  95:156 */         list.add(new BasicNameValuePair(nvp.getName(), nvp.getValue()));
/*  96:    */       }
/*  97:    */     }
/*  98:159 */     return list;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static String format(List<? extends NameValuePair> parameters, String charset)
/* 102:    */   {
/* 103:174 */     StringBuilder result = new StringBuilder();
/* 104:175 */     for (NameValuePair parameter : parameters)
/* 105:    */     {
/* 106:177 */       String encodedName = encodeFormFields(parameter.getName(), charset);
/* 107:178 */       String encodedValue = encodeFormFields(parameter.getValue(), charset);
/* 108:179 */       if (result.length() > 0) {
/* 109:181 */         result.append("&");
/* 110:    */       }
/* 111:183 */       result.append(encodedName);
/* 112:184 */       if (encodedValue != null)
/* 113:    */       {
/* 114:186 */         result.append("=");
/* 115:187 */         result.append(encodedValue);
/* 116:    */       }
/* 117:    */     }
/* 118:190 */     return result.toString();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static String format(Iterable<? extends NameValuePair> parameters, Charset charset)
/* 122:    */   {
/* 123:206 */     StringBuilder result = new StringBuilder();
/* 124:207 */     for (NameValuePair parameter : parameters)
/* 125:    */     {
/* 126:209 */       String encodedName = encodeFormFields(parameter.getName(), charset);
/* 127:210 */       String encodedValue = encodeFormFields(parameter.getValue(), charset);
/* 128:211 */       if (result.length() > 0) {
/* 129:213 */         result.append("&");
/* 130:    */       }
/* 131:215 */       result.append(encodedName);
/* 132:216 */       if (encodedValue != null)
/* 133:    */       {
/* 134:218 */         result.append("=");
/* 135:219 */         result.append(encodedValue);
/* 136:    */       }
/* 137:    */     }
/* 138:222 */     return result.toString();
/* 139:    */   }
/* 140:    */   
/* 141:231 */   private static final BitSet UNRESERVED = new BitSet(256);
/* 142:237 */   private static final BitSet PUNCT = new BitSet(256);
/* 143:242 */   private static final BitSet USERINFO = new BitSet(256);
/* 144:247 */   private static final BitSet PATHSAFE = new BitSet(256);
/* 145:252 */   private static final BitSet FRAGMENT = new BitSet(256);
/* 146:261 */   private static final BitSet RESERVED = new BitSet(256);
/* 147:268 */   private static final BitSet URLENCODER = new BitSet(256);
/* 148:    */   private static final int RADIX = 16;
/* 149:    */   
/* 150:    */   static
/* 151:    */   {
/* 152:274 */     for (int i = 97; i <= 122; i++) {
/* 153:276 */       UNRESERVED.set(i);
/* 154:    */     }
/* 155:278 */     for (int i = 65; i <= 90; i++) {
/* 156:280 */       UNRESERVED.set(i);
/* 157:    */     }
/* 158:283 */     for (int i = 48; i <= 57; i++) {
/* 159:285 */       UNRESERVED.set(i);
/* 160:    */     }
/* 161:287 */     UNRESERVED.set(95);
/* 162:288 */     UNRESERVED.set(45);
/* 163:289 */     UNRESERVED.set(46);
/* 164:290 */     UNRESERVED.set(42);
/* 165:291 */     URLENCODER.or(UNRESERVED);
/* 166:292 */     UNRESERVED.set(33);
/* 167:293 */     UNRESERVED.set(126);
/* 168:294 */     UNRESERVED.set(39);
/* 169:295 */     UNRESERVED.set(40);
/* 170:296 */     UNRESERVED.set(41);
/* 171:    */     
/* 172:298 */     PUNCT.set(44);
/* 173:299 */     PUNCT.set(59);
/* 174:300 */     PUNCT.set(58);
/* 175:301 */     PUNCT.set(36);
/* 176:302 */     PUNCT.set(38);
/* 177:303 */     PUNCT.set(43);
/* 178:304 */     PUNCT.set(61);
/* 179:    */     
/* 180:306 */     USERINFO.or(UNRESERVED);
/* 181:307 */     USERINFO.or(PUNCT);
/* 182:    */     
/* 183:    */ 
/* 184:310 */     PATHSAFE.or(UNRESERVED);
/* 185:311 */     PATHSAFE.set(47);
/* 186:312 */     PATHSAFE.set(59);
/* 187:313 */     PATHSAFE.set(58);
/* 188:314 */     PATHSAFE.set(64);
/* 189:315 */     PATHSAFE.set(38);
/* 190:316 */     PATHSAFE.set(61);
/* 191:317 */     PATHSAFE.set(43);
/* 192:318 */     PATHSAFE.set(36);
/* 193:319 */     PATHSAFE.set(44);
/* 194:    */     
/* 195:321 */     RESERVED.set(59);
/* 196:322 */     RESERVED.set(47);
/* 197:323 */     RESERVED.set(63);
/* 198:324 */     RESERVED.set(58);
/* 199:325 */     RESERVED.set(64);
/* 200:326 */     RESERVED.set(38);
/* 201:327 */     RESERVED.set(61);
/* 202:328 */     RESERVED.set(43);
/* 203:329 */     RESERVED.set(36);
/* 204:330 */     RESERVED.set(44);
/* 205:331 */     RESERVED.set(91);
/* 206:332 */     RESERVED.set(93);
/* 207:    */     
/* 208:334 */     FRAGMENT.or(RESERVED);
/* 209:335 */     FRAGMENT.or(UNRESERVED);
/* 210:    */   }
/* 211:    */   
/* 212:    */   private static String urlencode(String content, Charset charset, BitSet safechars, boolean blankAsPlus)
/* 213:    */   {
/* 214:342 */     if (content == null) {
/* 215:344 */       return null;
/* 216:    */     }
/* 217:346 */     StringBuilder buf = new StringBuilder();
/* 218:347 */     ByteBuffer bb = charset.encode(content);
/* 219:348 */     while (bb.hasRemaining())
/* 220:    */     {
/* 221:350 */       int b = bb.get() & 0xFF;
/* 222:351 */       if (safechars.get(b))
/* 223:    */       {
/* 224:353 */         buf.append((char)b);
/* 225:    */       }
/* 226:354 */       else if ((blankAsPlus) && (b == 32))
/* 227:    */       {
/* 228:356 */         buf.append('+');
/* 229:    */       }
/* 230:    */       else
/* 231:    */       {
/* 232:359 */         buf.append("%");
/* 233:360 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 234:361 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 235:362 */         buf.append(hex1);
/* 236:363 */         buf.append(hex2);
/* 237:    */       }
/* 238:    */     }
/* 239:366 */     return buf.toString();
/* 240:    */   }
/* 241:    */   
/* 242:    */   private static String urldecode(String content, Charset charset, boolean plusAsBlank)
/* 243:    */   {
/* 244:384 */     if (content == null) {
/* 245:386 */       return null;
/* 246:    */     }
/* 247:388 */     ByteBuffer bb = ByteBuffer.allocate(content.length());
/* 248:389 */     CharBuffer cb = CharBuffer.wrap(content);
/* 249:390 */     while (cb.hasRemaining())
/* 250:    */     {
/* 251:392 */       char c = cb.get();
/* 252:393 */       if ((c == '%') && (cb.remaining() >= 2))
/* 253:    */       {
/* 254:395 */         char uc = cb.get();
/* 255:396 */         char lc = cb.get();
/* 256:397 */         int u = Character.digit(uc, 16);
/* 257:398 */         int l = Character.digit(lc, 16);
/* 258:399 */         if ((u != -1) && (l != -1))
/* 259:    */         {
/* 260:401 */           bb.put((byte)((u << 4) + l));
/* 261:    */         }
/* 262:    */         else
/* 263:    */         {
/* 264:404 */           bb.put((byte)37);
/* 265:405 */           bb.put((byte)uc);
/* 266:406 */           bb.put((byte)lc);
/* 267:    */         }
/* 268:    */       }
/* 269:408 */       else if ((plusAsBlank) && (c == '+'))
/* 270:    */       {
/* 271:410 */         bb.put((byte)32);
/* 272:    */       }
/* 273:    */       else
/* 274:    */       {
/* 275:413 */         bb.put((byte)c);
/* 276:    */       }
/* 277:    */     }
/* 278:416 */     bb.flip();
/* 279:417 */     return charset.decode(bb).toString();
/* 280:    */   }
/* 281:    */   
/* 282:    */   private static String decodeFormFields(String content, String charset)
/* 283:    */   {
/* 284:431 */     if (content == null) {
/* 285:433 */       return null;
/* 286:    */     }
/* 287:435 */     return urldecode(content, charset != null ? Charset.forName(charset) : Charset.forName("UTF-8"), true);
/* 288:    */   }
/* 289:    */   
/* 290:    */   private static String decodeFormFields(String content, Charset charset)
/* 291:    */   {
/* 292:449 */     if (content == null) {
/* 293:451 */       return null;
/* 294:    */     }
/* 295:453 */     return urldecode(content, charset != null ? charset : Charset.forName("UTF-8"), true);
/* 296:    */   }
/* 297:    */   
/* 298:    */   private static String encodeFormFields(String content, String charset)
/* 299:    */   {
/* 300:471 */     if (content == null) {
/* 301:473 */       return null;
/* 302:    */     }
/* 303:475 */     return urlencode(content, charset != null ? Charset.forName(charset) : Charset.forName("UTF-8"), URLENCODER, true);
/* 304:    */   }
/* 305:    */   
/* 306:    */   private static String encodeFormFields(String content, Charset charset)
/* 307:    */   {
/* 308:493 */     if (content == null) {
/* 309:495 */       return null;
/* 310:    */     }
/* 311:497 */     return urlencode(content, charset != null ? charset : Charset.forName("UTF-8"), URLENCODER, true);
/* 312:    */   }
/* 313:    */   
/* 314:    */   static String encUserInfo(String content, Charset charset)
/* 315:    */   {
/* 316:513 */     return urlencode(content, charset, USERINFO, false);
/* 317:    */   }
/* 318:    */   
/* 319:    */   static String encFragment(String content, Charset charset)
/* 320:    */   {
/* 321:529 */     return urlencode(content, charset, FRAGMENT, false);
/* 322:    */   }
/* 323:    */   
/* 324:    */   static String encPath(String content, Charset charset)
/* 325:    */   {
/* 326:545 */     return urlencode(content, charset, PATHSAFE, false);
/* 327:    */   }
/* 328:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.client.util.URLEncodedUtils
 * JD-Core Version:    0.7.0.1
 */