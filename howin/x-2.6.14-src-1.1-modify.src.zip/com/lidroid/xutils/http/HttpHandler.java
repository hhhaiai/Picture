/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import android.os.SystemClock;
/*   4:    */ import com.lidroid.xutils.HttpUtils;
/*   5:    */ import com.lidroid.xutils.exception.HttpException;
/*   6:    */ import com.lidroid.xutils.http.callback.DefaultHttpRedirectHandler;
/*   7:    */ import com.lidroid.xutils.http.callback.FileDownloadHandler;
/*   8:    */ import com.lidroid.xutils.http.callback.HttpRedirectHandler;
/*   9:    */ import com.lidroid.xutils.http.callback.RequestCallBack;
/*  10:    */ import com.lidroid.xutils.http.callback.RequestCallBackHandler;
/*  11:    */ import com.lidroid.xutils.http.callback.StringDownloadHandler;
/*  12:    */ import com.lidroid.xutils.task.PriorityAsyncTask;
/*  13:    */ import com.lidroid.xutils.util.OtherUtils;
/*  14:    */ import java.io.File;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.net.URI;
/*  17:    */ import java.net.UnknownHostException;
/*  18:    */ import org.apache.http.HttpEntity;
/*  19:    */ import org.apache.http.HttpResponse;
/*  20:    */ import org.apache.http.ProtocolException;
/*  21:    */ import org.apache.http.StatusLine;
/*  22:    */ import org.apache.http.client.HttpRequestRetryHandler;
/*  23:    */ import org.apache.http.client.RedirectHandler;
/*  24:    */ import org.apache.http.client.methods.HttpRequestBase;
/*  25:    */ import org.apache.http.impl.client.AbstractHttpClient;
/*  26:    */ import org.apache.http.protocol.HttpContext;
/*  27:    */ 
/*  28:    */ public class HttpHandler<T>
/*  29:    */   extends PriorityAsyncTask<Object, Object, Void>
/*  30:    */   implements RequestCallBackHandler
/*  31:    */ {
/*  32:    */   private final AbstractHttpClient client;
/*  33:    */   private final HttpContext context;
/*  34:    */   private HttpRedirectHandler httpRedirectHandler;
/*  35:    */   private String requestUrl;
/*  36:    */   private String requestMethod;
/*  37:    */   private HttpRequestBase request;
/*  38:    */   
/*  39:    */   public void setHttpRedirectHandler(HttpRedirectHandler httpRedirectHandler)
/*  40:    */   {
/*  41: 49 */     if (httpRedirectHandler != null) {
/*  42: 51 */       this.httpRedirectHandler = httpRedirectHandler;
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46: 58 */   private boolean isUploading = true;
/*  47:    */   private RequestCallBack<T> callback;
/*  48: 61 */   private int retriedCount = 0;
/*  49: 62 */   private String fileSavePath = null;
/*  50: 63 */   private boolean isDownloadingFile = false;
/*  51: 64 */   private boolean autoResume = false;
/*  52: 67 */   private boolean autoRename = false;
/*  53:    */   private String charset;
/*  54:    */   
/*  55:    */   public HttpHandler(AbstractHttpClient client, HttpContext context, String charset, RequestCallBack<T> callback)
/*  56:    */   {
/*  57: 74 */     this.client = client;
/*  58: 75 */     this.context = context;
/*  59: 76 */     this.callback = callback;
/*  60: 77 */     this.charset = charset;
/*  61: 78 */     this.client.setRedirectHandler(notUseApacheRedirectHandler);
/*  62:    */   }
/*  63:    */   
/*  64: 81 */   private State state = State.WAITING;
/*  65:    */   
/*  66:    */   public State getState()
/*  67:    */   {
/*  68: 85 */     return this.state;
/*  69:    */   }
/*  70:    */   
/*  71: 88 */   private long expiry = HttpCache.getDefaultExpiryTime();
/*  72:    */   private static final int UPDATE_START = 1;
/*  73:    */   private static final int UPDATE_LOADING = 2;
/*  74:    */   private static final int UPDATE_FAILURE = 3;
/*  75:    */   private static final int UPDATE_SUCCESS = 4;
/*  76:    */   private long lastUpdateTime;
/*  77:    */   
/*  78:    */   public void setExpiry(long expiry)
/*  79:    */   {
/*  80: 92 */     this.expiry = expiry;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setRequestCallBack(RequestCallBack<T> callback)
/*  84:    */   {
/*  85: 97 */     this.callback = callback;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public RequestCallBack<T> getRequestCallBack()
/*  89:    */   {
/*  90:102 */     return this.callback;
/*  91:    */   }
/*  92:    */   
/*  93:    */   private ResponseInfo<T> sendRequest(HttpRequestBase request)
/*  94:    */     throws HttpException
/*  95:    */   {
/*  96:110 */     HttpRequestRetryHandler retryHandler = this.client.getHttpRequestRetryHandler();
/*  97:    */     boolean retry;
/*  98:    */     IOException exception;
/*  99:    */     do
/* 100:    */     {
/* 101:114 */       if ((this.autoResume) && (this.isDownloadingFile))
/* 102:    */       {
/* 103:116 */         File downloadFile = new File(this.fileSavePath);
/* 104:117 */         long fileLen = 0L;
/* 105:118 */         if ((downloadFile.isFile()) && (downloadFile.exists())) {
/* 106:120 */           fileLen = downloadFile.length();
/* 107:    */         }
/* 108:122 */         if (fileLen > 0L) {
/* 109:124 */           request.setHeader("RANGE", "bytes=" + fileLen + "-");
/* 110:    */         }
/* 111:    */       }
/* 112:128 */       retry = true;
/* 113:129 */       exception = null;
/* 114:    */       try
/* 115:    */       {
/* 116:132 */         this.requestMethod = request.getMethod();
/* 117:133 */         if (HttpUtils.sHttpCache.isEnabled(this.requestMethod))
/* 118:    */         {
/* 119:135 */           String result = HttpUtils.sHttpCache.get(this.requestUrl);
/* 120:136 */           if (result != null) {
/* 121:138 */             return new ResponseInfo(null, result, true);
/* 122:    */           }
/* 123:    */         }
/* 124:142 */         ResponseInfo<T> responseInfo = null;
/* 125:    */         HttpResponse response;
/* 126:143 */         if (!isCancelled()) {
/* 127:145 */           response = this.client.execute(request, this.context);
/* 128:    */         }
/* 129:146 */         return handleResponse(response);
/* 130:    */       }
/* 131:    */       catch (UnknownHostException e)
/* 132:    */       {
/* 133:151 */         exception = e;
/* 134:152 */         retry = retryHandler.retryRequest(exception, ++this.retriedCount, this.context);
/* 135:    */       }
/* 136:    */       catch (IOException e)
/* 137:    */       {
/* 138:155 */         exception = e;
/* 139:156 */         retry = retryHandler.retryRequest(exception, ++this.retriedCount, this.context);
/* 140:    */       }
/* 141:    */       catch (NullPointerException e)
/* 142:    */       {
/* 143:159 */         exception = new IOException(e.getMessage());
/* 144:160 */         exception.initCause(e);
/* 145:161 */         retry = retryHandler.retryRequest(exception, ++this.retriedCount, this.context);
/* 146:    */       }
/* 147:    */       catch (HttpException e)
/* 148:    */       {
/* 149:164 */         throw e;
/* 150:    */       }
/* 151:    */       catch (Throwable e)
/* 152:    */       {
/* 153:167 */         exception = new IOException(e.getMessage());
/* 154:168 */         exception.initCause(e);
/* 155:169 */         retry = retryHandler.retryRequest(exception, ++this.retriedCount, this.context);
/* 156:    */       }
/* 157:171 */     } while (retry);
/* 158:173 */     throw new HttpException(exception);
/* 159:    */   }
/* 160:    */   
/* 161:    */   protected Void doInBackground(Object... params)
/* 162:    */   {
/* 163:181 */     if ((this.state == State.CANCELLED) || (params == null) || (params.length == 0)) {
/* 164:182 */       return null;
/* 165:    */     }
/* 166:184 */     if (params.length > 3)
/* 167:    */     {
/* 168:186 */       this.fileSavePath = String.valueOf(params[1]);
/* 169:187 */       this.isDownloadingFile = (this.fileSavePath != null);
/* 170:188 */       this.autoResume = ((Boolean)params[2]).booleanValue();
/* 171:189 */       this.autoRename = ((Boolean)params[3]).booleanValue();
/* 172:    */     }
/* 173:    */     try
/* 174:    */     {
/* 175:194 */       if (this.state == State.CANCELLED) {
/* 176:195 */         return null;
/* 177:    */       }
/* 178:197 */       this.request = ((HttpRequestBase)params[0]);
/* 179:198 */       this.requestUrl = this.request.getURI().toString();
/* 180:199 */       if (this.callback != null) {
/* 181:201 */         this.callback.setRequestUrl(this.requestUrl);
/* 182:    */       }
/* 183:204 */       publishProgress(new Object[] { Integer.valueOf(1) });
/* 184:    */       
/* 185:206 */       this.lastUpdateTime = SystemClock.uptimeMillis();
/* 186:    */       
/* 187:208 */       ResponseInfo<T> responseInfo = sendRequest(this.request);
/* 188:209 */       if (responseInfo != null)
/* 189:    */       {
/* 190:211 */         if (this.callback != null) {
/* 191:213 */           this.callback.onSuccessBack(responseInfo);
/* 192:    */         }
/* 193:215 */         publishProgress(new Object[] { Integer.valueOf(4), responseInfo });
/* 194:216 */         return null;
/* 195:    */       }
/* 196:    */     }
/* 197:    */     catch (HttpException e)
/* 198:    */     {
/* 199:220 */       publishProgress(new Object[] { Integer.valueOf(3), e, e.getMessage() });
/* 200:    */     }
/* 201:223 */     return null;
/* 202:    */   }
/* 203:    */   
/* 204:    */   protected void onProgressUpdate(Object... values)
/* 205:    */   {
/* 206:235 */     if ((this.state == State.CANCELLED) || (values == null) || (values.length == 0) || (this.callback == null)) {
/* 207:236 */       return;
/* 208:    */     }
/* 209:237 */     switch (((Integer)values[0]).intValue())
/* 210:    */     {
/* 211:    */     case 1: 
/* 212:240 */       this.state = State.STARTED;
/* 213:241 */       this.callback.onStart();
/* 214:242 */       break;
/* 215:    */     case 2: 
/* 216:244 */       if (values.length != 3) {
/* 217:245 */         return;
/* 218:    */       }
/* 219:246 */       this.state = State.LOADING;
/* 220:247 */       this.callback.onLoading(Long.valueOf(String.valueOf(values[1])).longValue(), Long.valueOf(String.valueOf(values[2])).longValue(), this.isUploading);
/* 221:248 */       break;
/* 222:    */     case 3: 
/* 223:250 */       if (values.length != 3) {
/* 224:251 */         return;
/* 225:    */       }
/* 226:252 */       this.state = State.FAILURE;
/* 227:253 */       this.callback.onFailure((HttpException)values[1], (String)values[2]);
/* 228:254 */       this.callback.onFinish();
/* 229:255 */       break;
/* 230:    */     case 4: 
/* 231:257 */       if (values.length != 2) {
/* 232:258 */         return;
/* 233:    */       }
/* 234:259 */       this.state = State.SUCCESS;
/* 235:260 */       this.callback.onSuccess((ResponseInfo)values[1]);
/* 236:261 */       this.callback.onFinish();
/* 237:262 */       break;
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private ResponseInfo<T> handleResponse(HttpResponse response)
/* 242:    */     throws HttpException, IOException
/* 243:    */   {
/* 244:271 */     if (response == null) {
/* 245:273 */       throw new HttpException("response is null");
/* 246:    */     }
/* 247:275 */     if (isCancelled()) {
/* 248:276 */       return null;
/* 249:    */     }
/* 250:278 */     StatusLine status = response.getStatusLine();
/* 251:279 */     int statusCode = status.getStatusCode();
/* 252:280 */     if (statusCode < 300)
/* 253:    */     {
/* 254:282 */       Object result = null;
/* 255:283 */       HttpEntity entity = response.getEntity();
/* 256:284 */       if (entity != null)
/* 257:    */       {
/* 258:286 */         this.isUploading = false;
/* 259:287 */         if (this.isDownloadingFile)
/* 260:    */         {
/* 261:289 */           this.autoResume = ((this.autoResume) && (OtherUtils.isSupportRange(response)));
/* 262:290 */           String responseFileName = this.autoRename ? OtherUtils.getFileNameFromHttpResponse(response) : null;
/* 263:291 */           FileDownloadHandler downloadHandler = new FileDownloadHandler();
/* 264:292 */           result = downloadHandler.handleEntity(entity, this, this.fileSavePath, this.autoResume, responseFileName);
/* 265:    */         }
/* 266:    */         else
/* 267:    */         {
/* 268:295 */           StringDownloadHandler downloadHandler = new StringDownloadHandler();
/* 269:296 */           result = downloadHandler.handleEntity(entity, this, this.charset);
/* 270:297 */           if (HttpUtils.sHttpCache.isEnabled(this.requestMethod)) {
/* 271:299 */             HttpUtils.sHttpCache.put(this.requestUrl, (String)result, this.expiry);
/* 272:    */           }
/* 273:    */         }
/* 274:    */       }
/* 275:303 */       return new ResponseInfo(response, result, false);
/* 276:    */     }
/* 277:304 */     if ((statusCode == 301) || (statusCode == 302))
/* 278:    */     {
/* 279:306 */       if (this.httpRedirectHandler == null) {
/* 280:308 */         this.httpRedirectHandler = new DefaultHttpRedirectHandler();
/* 281:    */       }
/* 282:310 */       HttpRequestBase request = this.httpRedirectHandler.getDirectRequest(response);
/* 283:311 */       if (request != null) {
/* 284:313 */         return sendRequest(request);
/* 285:    */       }
/* 286:    */     }
/* 287:    */     else
/* 288:    */     {
/* 289:315 */       if (statusCode == 416) {
/* 290:317 */         throw new HttpException(statusCode, "maybe the file has downloaded completely");
/* 291:    */       }
/* 292:320 */       throw new HttpException(statusCode, status.getReasonPhrase());
/* 293:    */     }
/* 294:322 */     return null;
/* 295:    */   }
/* 296:    */   
/* 297:    */   public void cancel()
/* 298:    */   {
/* 299:331 */     this.state = State.CANCELLED;
/* 300:333 */     if ((this.request != null) && (!this.request.isAborted())) {
/* 301:    */       try
/* 302:    */       {
/* 303:337 */         this.request.abort();
/* 304:    */       }
/* 305:    */       catch (Throwable localThrowable) {}
/* 306:    */     }
/* 307:342 */     if (!isCancelled()) {
/* 308:    */       try
/* 309:    */       {
/* 310:346 */         cancel(true);
/* 311:    */       }
/* 312:    */       catch (Throwable localThrowable1) {}
/* 313:    */     }
/* 314:352 */     if (this.callback != null)
/* 315:    */     {
/* 316:354 */       this.callback.onCancelled();
/* 317:355 */       this.callback.onFinish();
/* 318:    */     }
/* 319:    */   }
/* 320:    */   
/* 321:    */   public boolean updateProgress(long total, long current, boolean forceUpdateUI)
/* 322:    */   {
/* 323:364 */     if ((this.callback != null) && (this.state != State.CANCELLED)) {
/* 324:366 */       if (forceUpdateUI)
/* 325:    */       {
/* 326:368 */         publishProgress(new Object[] { Integer.valueOf(2), Long.valueOf(total), Long.valueOf(current) });
/* 327:    */       }
/* 328:    */       else
/* 329:    */       {
/* 330:371 */         long currTime = SystemClock.uptimeMillis();
/* 331:372 */         if (currTime - this.lastUpdateTime >= this.callback.getRate())
/* 332:    */         {
/* 333:374 */           this.lastUpdateTime = currTime;
/* 334:375 */           publishProgress(new Object[] { Integer.valueOf(2), Long.valueOf(total), Long.valueOf(current) });
/* 335:    */         }
/* 336:    */       }
/* 337:    */     }
/* 338:379 */     return this.state != State.CANCELLED;
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static enum State
/* 342:    */   {
/* 343:384 */     WAITING(0),  STARTED(1),  LOADING(2),  FAILURE(3),  CANCELLED(4),  SUCCESS(5);
/* 344:    */     
/* 345:385 */     private int value = 0;
/* 346:    */     
/* 347:    */     private State(int value)
/* 348:    */     {
/* 349:389 */       this.value = value;
/* 350:    */     }
/* 351:    */     
/* 352:    */     public static State valueOf(int value)
/* 353:    */     {
/* 354:394 */       switch (value)
/* 355:    */       {
/* 356:    */       case 0: 
/* 357:397 */         return WAITING;
/* 358:    */       case 1: 
/* 359:399 */         return STARTED;
/* 360:    */       case 2: 
/* 361:401 */         return LOADING;
/* 362:    */       case 3: 
/* 363:403 */         return FAILURE;
/* 364:    */       case 4: 
/* 365:405 */         return CANCELLED;
/* 366:    */       case 5: 
/* 367:407 */         return SUCCESS;
/* 368:    */       }
/* 369:409 */       return FAILURE;
/* 370:    */     }
/* 371:    */     
/* 372:    */     public int value()
/* 373:    */     {
/* 374:415 */       return this.value;
/* 375:    */     }
/* 376:    */   }
/* 377:    */   
/* 378:419 */   private static final NotUseApacheRedirectHandler notUseApacheRedirectHandler = new NotUseApacheRedirectHandler(null);
/* 379:    */   
/* 380:    */   private static final class NotUseApacheRedirectHandler
/* 381:    */     implements RedirectHandler
/* 382:    */   {
/* 383:    */     public boolean isRedirectRequested(HttpResponse httpResponse, HttpContext httpContext)
/* 384:    */     {
/* 385:426 */       return false;
/* 386:    */     }
/* 387:    */     
/* 388:    */     public URI getLocationURI(HttpResponse httpResponse, HttpContext httpContext)
/* 389:    */       throws ProtocolException
/* 390:    */     {
/* 391:432 */       return null;
/* 392:    */     }
/* 393:    */   }
/* 394:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.HttpHandler
 * JD-Core Version:    0.7.0.1
 */