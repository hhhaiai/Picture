/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.http.client.entity.BodyParamsEntity;
/*   5:    */ import com.lidroid.xutils.http.client.multipart.HttpMultipartMode;
/*   6:    */ import com.lidroid.xutils.http.client.multipart.MultipartEntity;
/*   7:    */ import com.lidroid.xutils.http.client.multipart.content.ContentBody;
/*   8:    */ import com.lidroid.xutils.http.client.multipart.content.FileBody;
/*   9:    */ import com.lidroid.xutils.http.client.multipart.content.InputStreamBody;
/*  10:    */ import com.lidroid.xutils.http.client.multipart.content.StringBody;
/*  11:    */ import com.lidroid.xutils.task.Priority;
/*  12:    */ import com.lidroid.xutils.util.LogUtils;
/*  13:    */ import java.io.File;
/*  14:    */ import java.io.InputStream;
/*  15:    */ import java.io.UnsupportedEncodingException;
/*  16:    */ import java.nio.charset.Charset;
/*  17:    */ import java.util.ArrayList;
/*  18:    */ import java.util.HashMap;
/*  19:    */ import java.util.List;
/*  20:    */ import java.util.Map.Entry;
/*  21:    */ import org.apache.http.Header;
/*  22:    */ import org.apache.http.HttpEntity;
/*  23:    */ import org.apache.http.NameValuePair;
/*  24:    */ import org.apache.http.message.BasicHeader;
/*  25:    */ import org.apache.http.message.BasicNameValuePair;
/*  26:    */ 
/*  27:    */ public class RequestParams
/*  28:    */ {
/*  29: 47 */   private String charset = "UTF-8";
/*  30:    */   private List<HeaderItem> headers;
/*  31:    */   private List<NameValuePair> queryStringParams;
/*  32:    */   private HttpEntity bodyEntity;
/*  33:    */   private List<NameValuePair> bodyParams;
/*  34:    */   private HashMap<String, ContentBody> fileParams;
/*  35:    */   private Priority priority;
/*  36:    */   
/*  37:    */   public RequestParams() {}
/*  38:    */   
/*  39:    */   public RequestParams(String charset)
/*  40:    */   {
/*  41: 63 */     if (!TextUtils.isEmpty(charset)) {
/*  42: 65 */       this.charset = charset;
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Priority getPriority()
/*  47:    */   {
/*  48: 71 */     return this.priority;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setPriority(Priority priority)
/*  52:    */   {
/*  53: 76 */     this.priority = priority;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getCharset()
/*  57:    */   {
/*  58: 81 */     return this.charset;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setContentType(String contentType)
/*  62:    */   {
/*  63: 86 */     setHeader("Content-Type", contentType);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void addHeader(Header header)
/*  67:    */   {
/*  68: 97 */     if (this.headers == null) {
/*  69: 99 */       this.headers = new ArrayList();
/*  70:    */     }
/*  71:101 */     this.headers.add(new HeaderItem(header));
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void addHeader(String name, String value)
/*  75:    */   {
/*  76:113 */     if (this.headers == null) {
/*  77:115 */       this.headers = new ArrayList();
/*  78:    */     }
/*  79:117 */     this.headers.add(new HeaderItem(name, value));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void addHeaders(List<Header> headers)
/*  83:    */   {
/*  84:127 */     if (this.headers == null) {
/*  85:129 */       this.headers = new ArrayList();
/*  86:    */     }
/*  87:131 */     for (Header header : headers) {
/*  88:133 */       this.headers.add(new HeaderItem(header));
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setHeader(Header header)
/*  93:    */   {
/*  94:146 */     if (this.headers == null) {
/*  95:148 */       this.headers = new ArrayList();
/*  96:    */     }
/*  97:150 */     this.headers.add(new HeaderItem(header, true));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void setHeader(String name, String value)
/* 101:    */   {
/* 102:163 */     if (this.headers == null) {
/* 103:165 */       this.headers = new ArrayList();
/* 104:    */     }
/* 105:167 */     this.headers.add(new HeaderItem(name, value, true));
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setHeaders(List<Header> headers)
/* 109:    */   {
/* 110:177 */     if (this.headers == null) {
/* 111:179 */       this.headers = new ArrayList();
/* 112:    */     }
/* 113:181 */     for (Header header : headers) {
/* 114:183 */       this.headers.add(new HeaderItem(header, true));
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void addQueryStringParameter(String name, String value)
/* 119:    */   {
/* 120:189 */     if (this.queryStringParams == null) {
/* 121:191 */       this.queryStringParams = new ArrayList();
/* 122:    */     }
/* 123:193 */     this.queryStringParams.add(new BasicNameValuePair(name, value));
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void addQueryStringParameter(NameValuePair nameValuePair)
/* 127:    */   {
/* 128:198 */     if (this.queryStringParams == null) {
/* 129:200 */       this.queryStringParams = new ArrayList();
/* 130:    */     }
/* 131:202 */     this.queryStringParams.add(nameValuePair);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void addQueryStringParameter(List<NameValuePair> nameValuePairs)
/* 135:    */   {
/* 136:207 */     if (this.queryStringParams == null) {
/* 137:209 */       this.queryStringParams = new ArrayList();
/* 138:    */     }
/* 139:211 */     if ((nameValuePairs != null) && (nameValuePairs.size() > 0)) {
/* 140:213 */       for (NameValuePair pair : nameValuePairs) {
/* 141:215 */         this.queryStringParams.add(pair);
/* 142:    */       }
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void addBodyParameter(String name, String value)
/* 147:    */   {
/* 148:222 */     if (this.bodyParams == null) {
/* 149:224 */       this.bodyParams = new ArrayList();
/* 150:    */     }
/* 151:226 */     this.bodyParams.add(new BasicNameValuePair(name, value));
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void addBodyParameter(NameValuePair nameValuePair)
/* 155:    */   {
/* 156:231 */     if (this.bodyParams == null) {
/* 157:233 */       this.bodyParams = new ArrayList();
/* 158:    */     }
/* 159:235 */     this.bodyParams.add(nameValuePair);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void addBodyParameter(List<NameValuePair> nameValuePairs)
/* 163:    */   {
/* 164:240 */     if (this.bodyParams == null) {
/* 165:242 */       this.bodyParams = new ArrayList();
/* 166:    */     }
/* 167:244 */     if ((nameValuePairs != null) && (nameValuePairs.size() > 0)) {
/* 168:246 */       for (NameValuePair pair : nameValuePairs) {
/* 169:248 */         this.bodyParams.add(pair);
/* 170:    */       }
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void addBodyParameter(String key, File file)
/* 175:    */   {
/* 176:255 */     if (this.fileParams == null) {
/* 177:257 */       this.fileParams = new HashMap();
/* 178:    */     }
/* 179:259 */     this.fileParams.put(key, new FileBody(file));
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void addBodyParameter(String key, File file, String mimeType)
/* 183:    */   {
/* 184:264 */     if (this.fileParams == null) {
/* 185:266 */       this.fileParams = new HashMap();
/* 186:    */     }
/* 187:268 */     this.fileParams.put(key, new FileBody(file, mimeType));
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void addBodyParameter(String key, File file, String mimeType, String charset)
/* 191:    */   {
/* 192:273 */     if (this.fileParams == null) {
/* 193:275 */       this.fileParams = new HashMap();
/* 194:    */     }
/* 195:277 */     this.fileParams.put(key, new FileBody(file, mimeType, charset));
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void addBodyParameter(String key, File file, String fileName, String mimeType, String charset)
/* 199:    */   {
/* 200:282 */     if (this.fileParams == null) {
/* 201:284 */       this.fileParams = new HashMap();
/* 202:    */     }
/* 203:286 */     this.fileParams.put(key, new FileBody(file, fileName, mimeType, charset));
/* 204:    */   }
/* 205:    */   
/* 206:    */   public void addBodyParameter(String key, InputStream stream, long length)
/* 207:    */   {
/* 208:291 */     if (this.fileParams == null) {
/* 209:293 */       this.fileParams = new HashMap();
/* 210:    */     }
/* 211:295 */     this.fileParams.put(key, new InputStreamBody(stream, length));
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void addBodyParameter(String key, InputStream stream, long length, String fileName)
/* 215:    */   {
/* 216:300 */     if (this.fileParams == null) {
/* 217:302 */       this.fileParams = new HashMap();
/* 218:    */     }
/* 219:304 */     this.fileParams.put(key, new InputStreamBody(stream, length, fileName));
/* 220:    */   }
/* 221:    */   
/* 222:    */   public void addBodyParameter(String key, InputStream stream, long length, String fileName, String mimeType)
/* 223:    */   {
/* 224:309 */     if (this.fileParams == null) {
/* 225:311 */       this.fileParams = new HashMap();
/* 226:    */     }
/* 227:313 */     this.fileParams.put(key, new InputStreamBody(stream, length, fileName, mimeType));
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void setBodyEntity(HttpEntity bodyEntity)
/* 231:    */   {
/* 232:318 */     this.bodyEntity = bodyEntity;
/* 233:319 */     if (this.bodyParams != null)
/* 234:    */     {
/* 235:321 */       this.bodyParams.clear();
/* 236:322 */       this.bodyParams = null;
/* 237:    */     }
/* 238:324 */     if (this.fileParams != null)
/* 239:    */     {
/* 240:326 */       this.fileParams.clear();
/* 241:327 */       this.fileParams = null;
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   public HttpEntity getEntity()
/* 246:    */   {
/* 247:337 */     if (this.bodyEntity != null) {
/* 248:339 */       return this.bodyEntity;
/* 249:    */     }
/* 250:342 */     HttpEntity result = null;
/* 251:344 */     if ((this.fileParams != null) && (!this.fileParams.isEmpty()))
/* 252:    */     {
/* 253:347 */       MultipartEntity multipartEntity = new MultipartEntity(HttpMultipartMode.STRICT, null, Charset.forName(this.charset));
/* 254:349 */       if ((this.bodyParams != null) && (!this.bodyParams.isEmpty())) {
/* 255:351 */         for (NameValuePair param : this.bodyParams) {
/* 256:    */           try
/* 257:    */           {
/* 258:355 */             multipartEntity.addPart(param.getName(), new StringBody(param.getValue()));
/* 259:    */           }
/* 260:    */           catch (UnsupportedEncodingException e)
/* 261:    */           {
/* 262:358 */             LogUtils.e(e.getMessage(), e);
/* 263:    */           }
/* 264:    */         }
/* 265:    */       }
/* 266:363 */       for (Map.Entry<String, ContentBody> entry : this.fileParams.entrySet()) {
/* 267:365 */         multipartEntity.addPart((String)entry.getKey(), (ContentBody)entry.getValue());
/* 268:    */       }
/* 269:368 */       result = multipartEntity;
/* 270:    */     }
/* 271:369 */     else if ((this.bodyParams != null) && (!this.bodyParams.isEmpty()))
/* 272:    */     {
/* 273:371 */       result = new BodyParamsEntity(this.bodyParams, this.charset);
/* 274:    */     }
/* 275:374 */     return result;
/* 276:    */   }
/* 277:    */   
/* 278:    */   public List<NameValuePair> getQueryStringParams()
/* 279:    */   {
/* 280:379 */     return this.queryStringParams;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public List<HeaderItem> getHeaders()
/* 284:    */   {
/* 285:384 */     return this.headers;
/* 286:    */   }
/* 287:    */   
/* 288:    */   public class HeaderItem
/* 289:    */   {
/* 290:    */     public final boolean overwrite;
/* 291:    */     public final Header header;
/* 292:    */     
/* 293:    */     public HeaderItem(Header header)
/* 294:    */     {
/* 295:394 */       this.overwrite = false;
/* 296:395 */       this.header = header;
/* 297:    */     }
/* 298:    */     
/* 299:    */     public HeaderItem(Header header, boolean overwrite)
/* 300:    */     {
/* 301:400 */       this.overwrite = overwrite;
/* 302:401 */       this.header = header;
/* 303:    */     }
/* 304:    */     
/* 305:    */     public HeaderItem(String name, String value)
/* 306:    */     {
/* 307:406 */       this.overwrite = false;
/* 308:407 */       this.header = new BasicHeader(name, value);
/* 309:    */     }
/* 310:    */     
/* 311:    */     public HeaderItem(String name, String value, boolean overwrite)
/* 312:    */     {
/* 313:412 */       this.overwrite = overwrite;
/* 314:413 */       this.header = new BasicHeader(name, value);
/* 315:    */     }
/* 316:    */   }
/* 317:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.RequestParams
 * JD-Core Version:    0.7.0.1
 */