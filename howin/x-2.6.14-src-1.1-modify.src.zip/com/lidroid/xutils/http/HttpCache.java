/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils;
/*   4:    */ import com.lidroid.xutils.cache.LruMemoryCache;
/*   5:    */ import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
/*   6:    */ import java.util.concurrent.ConcurrentHashMap;
/*   7:    */ 
/*   8:    */ public class HttpCache
/*   9:    */ {
/*  10:    */   private final LruMemoryCache<String, String> mMemoryCache;
/*  11:    */   private static final int DEFAULT_CACHE_SIZE = 102400;
/*  12:    */   private static final long DEFAULT_EXPIRY_TIME = 60000L;
/*  13: 38 */   private int cacheSize = 102400;
/*  14: 40 */   private static long defaultExpiryTime = 60000L;
/*  15:    */   
/*  16:    */   public HttpCache()
/*  17:    */   {
/*  18: 47 */     this(102400, 60000L);
/*  19:    */   }
/*  20:    */   
/*  21:    */   public HttpCache(int strLength, long defaultExpiryTime)
/*  22:    */   {
/*  23: 52 */     this.cacheSize = strLength;
/*  24: 53 */     defaultExpiryTime = defaultExpiryTime;
/*  25:    */     
/*  26: 55 */     this.mMemoryCache = new LruMemoryCache(this.cacheSize)
/*  27:    */     {
/*  28:    */       protected int sizeOf(String key, String value)
/*  29:    */       {
/*  30: 60 */         if (value == null) {
/*  31: 61 */           return 0;
/*  32:    */         }
/*  33: 62 */         return value.length();
/*  34:    */       }
/*  35:    */     };
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setCacheSize(int strLength)
/*  39:    */   {
/*  40: 69 */     this.mMemoryCache.setMaxSize(strLength);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void setDefaultExpiryTime(long defaultExpiryTime)
/*  44:    */   {
/*  45: 74 */     defaultExpiryTime = defaultExpiryTime;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static long getDefaultExpiryTime()
/*  49:    */   {
/*  50: 79 */     return defaultExpiryTime;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void put(String url, String result)
/*  54:    */   {
/*  55: 84 */     put(url, result, defaultExpiryTime);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void put(String url, String result, long expiry)
/*  59:    */   {
/*  60: 89 */     if ((url == null) || (result == null) || (expiry < 1L)) {
/*  61: 90 */       return;
/*  62:    */     }
/*  63: 92 */     this.mMemoryCache.put(url, result, System.currentTimeMillis() + expiry);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String get(String url)
/*  67:    */   {
/*  68: 97 */     return url != null ? (String)this.mMemoryCache.get(url) : null;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void clear()
/*  72:    */   {
/*  73:102 */     this.mMemoryCache.evictAll();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isEnabled(HttpRequest.HttpMethod method)
/*  77:    */   {
/*  78:107 */     if (method == null) {
/*  79:108 */       return false;
/*  80:    */     }
/*  81:110 */     Boolean enabled = (Boolean)httpMethod_enabled_map.get(method.toString());
/*  82:111 */     return enabled == null ? false : enabled.booleanValue();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean isEnabled(String method)
/*  86:    */   {
/*  87:116 */     if (TextUtils.isEmpty(method)) {
/*  88:117 */       return false;
/*  89:    */     }
/*  90:119 */     Boolean enabled = (Boolean)httpMethod_enabled_map.get(method.toUpperCase());
/*  91:120 */     return enabled == null ? false : enabled.booleanValue();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setEnabled(HttpRequest.HttpMethod method, boolean enabled)
/*  95:    */   {
/*  96:125 */     httpMethod_enabled_map.put(method.toString(), Boolean.valueOf(enabled));
/*  97:    */   }
/*  98:    */   
/*  99:132 */   private static final ConcurrentHashMap<String, Boolean> httpMethod_enabled_map = new ConcurrentHashMap(10);
/* 100:    */   
/* 101:    */   static
/* 102:    */   {
/* 103:133 */     httpMethod_enabled_map.put(HttpRequest.HttpMethod.GET.toString(), Boolean.valueOf(true));
/* 104:    */   }
/* 105:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.HttpCache
 * JD-Core Version:    0.7.0.1
 */