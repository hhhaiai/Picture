/*   1:    */ package com.lidroid.xutils.http;
/*   2:    */ 
/*   3:    */ import com.lidroid.xutils.HttpUtils;
/*   4:    */ import com.lidroid.xutils.util.IOUtils;
/*   5:    */ import java.io.BufferedInputStream;
/*   6:    */ import java.io.BufferedOutputStream;
/*   7:    */ import java.io.BufferedReader;
/*   8:    */ import java.io.FileOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.InputStream;
/*  11:    */ import java.io.InputStreamReader;
/*  12:    */ import java.util.Locale;
/*  13:    */ import org.apache.http.HttpEntity;
/*  14:    */ import org.apache.http.HttpResponse;
/*  15:    */ import org.apache.http.StatusLine;
/*  16:    */ 
/*  17:    */ public class ResponseStream
/*  18:    */   extends InputStream
/*  19:    */ {
/*  20:    */   private HttpResponse baseResponse;
/*  21:    */   private InputStream baseStream;
/*  22:    */   private String charset;
/*  23:    */   private String requestUrl;
/*  24:    */   private String requestMethod;
/*  25:    */   private long expiry;
/*  26:    */   private String _directResult;
/*  27:    */   
/*  28:    */   public ResponseStream(HttpResponse baseResponse, String requestUrl, long expiry)
/*  29:    */     throws IOException
/*  30:    */   {
/*  31: 43 */     this(baseResponse, "UTF-8", requestUrl, expiry);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public ResponseStream(HttpResponse baseResponse, String charset, String requestUrl, long expiry)
/*  35:    */     throws IOException
/*  36:    */   {
/*  37: 48 */     if (baseResponse == null) {
/*  38: 50 */       throw new IllegalArgumentException("baseResponse may not be null");
/*  39:    */     }
/*  40: 53 */     this.baseResponse = baseResponse;
/*  41: 54 */     this.baseStream = baseResponse.getEntity().getContent();
/*  42: 55 */     this.charset = charset;
/*  43: 56 */     this.requestUrl = requestUrl;
/*  44: 57 */     this.expiry = expiry;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public ResponseStream(String result)
/*  48:    */     throws IOException
/*  49:    */   {
/*  50: 64 */     if (result == null) {
/*  51: 66 */       throw new IllegalArgumentException("result may not be null");
/*  52:    */     }
/*  53: 69 */     this._directResult = result;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getRequestUrl()
/*  57:    */   {
/*  58: 74 */     return this.requestUrl;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public String getRequestMethod()
/*  62:    */   {
/*  63: 79 */     return this.requestMethod;
/*  64:    */   }
/*  65:    */   
/*  66:    */   void setRequestMethod(String requestMethod)
/*  67:    */   {
/*  68: 84 */     this.requestMethod = requestMethod;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public InputStream getBaseStream()
/*  72:    */   {
/*  73: 89 */     return this.baseStream;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public HttpResponse getBaseResponse()
/*  77:    */   {
/*  78: 94 */     return this.baseResponse;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int getStatusCode()
/*  82:    */   {
/*  83: 99 */     if (this._directResult != null) {
/*  84:100 */       return 200;
/*  85:    */     }
/*  86:101 */     return this.baseResponse.getStatusLine().getStatusCode();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Locale getLocale()
/*  90:    */   {
/*  91:106 */     if (this._directResult != null) {
/*  92:107 */       return Locale.getDefault();
/*  93:    */     }
/*  94:108 */     return this.baseResponse.getLocale();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String getReasonPhrase()
/*  98:    */   {
/*  99:113 */     if (this._directResult != null) {
/* 100:114 */       return "";
/* 101:    */     }
/* 102:115 */     return this.baseResponse.getStatusLine().getReasonPhrase();
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String readString()
/* 106:    */     throws IOException
/* 107:    */   {
/* 108:120 */     if (this._directResult != null) {
/* 109:121 */       return this._directResult;
/* 110:    */     }
/* 111:122 */     if (this.baseStream == null) {
/* 112:123 */       return null;
/* 113:    */     }
/* 114:    */     try
/* 115:    */     {
/* 116:126 */       BufferedReader reader = new BufferedReader(new InputStreamReader(this.baseStream, this.charset));
/* 117:127 */       StringBuilder sb = new StringBuilder();
/* 118:128 */       String line = "";
/* 119:129 */       while ((line = reader.readLine()) != null) {
/* 120:131 */         sb.append(line);
/* 121:    */       }
/* 122:133 */       this._directResult = sb.toString();
/* 123:134 */       if ((this.requestUrl != null) && (HttpUtils.sHttpCache.isEnabled(this.requestMethod))) {
/* 124:136 */         HttpUtils.sHttpCache.put(this.requestUrl, this._directResult, this.expiry);
/* 125:    */       }
/* 126:138 */       return this._directResult;
/* 127:    */     }
/* 128:    */     finally
/* 129:    */     {
/* 130:141 */       IOUtils.closeQuietly(this.baseStream);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void readFile(String savePath)
/* 135:    */     throws IOException
/* 136:    */   {
/* 137:147 */     if (this._directResult != null) {
/* 138:148 */       return;
/* 139:    */     }
/* 140:149 */     if (this.baseStream == null) {
/* 141:150 */       return;
/* 142:    */     }
/* 143:151 */     BufferedOutputStream out = null;
/* 144:    */     try
/* 145:    */     {
/* 146:154 */       out = new BufferedOutputStream(new FileOutputStream(savePath));
/* 147:155 */       BufferedInputStream ins = new BufferedInputStream(this.baseStream);
/* 148:156 */       byte[] buffer = new byte[4096];
/* 149:157 */       int len = 0;
/* 150:158 */       while ((len = ins.read(buffer)) != -1) {
/* 151:160 */         out.write(buffer, 0, len);
/* 152:    */       }
/* 153:162 */       out.flush();
/* 154:    */     }
/* 155:    */     finally
/* 156:    */     {
/* 157:165 */       IOUtils.closeQuietly(out);
/* 158:166 */       IOUtils.closeQuietly(this.baseStream);
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   public int read()
/* 163:    */     throws IOException
/* 164:    */   {
/* 165:173 */     if (this.baseStream == null) {
/* 166:174 */       return -1;
/* 167:    */     }
/* 168:175 */     return this.baseStream.read();
/* 169:    */   }
/* 170:    */   
/* 171:    */   public int available()
/* 172:    */     throws IOException
/* 173:    */   {
/* 174:181 */     if (this.baseStream == null) {
/* 175:182 */       return 0;
/* 176:    */     }
/* 177:183 */     return this.baseStream.available();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void close()
/* 181:    */     throws IOException
/* 182:    */   {
/* 183:189 */     if (this.baseStream == null) {
/* 184:190 */       return;
/* 185:    */     }
/* 186:191 */     this.baseStream.close();
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void mark(int readLimit)
/* 190:    */   {
/* 191:197 */     if (this.baseStream == null) {
/* 192:198 */       return;
/* 193:    */     }
/* 194:199 */     this.baseStream.mark(readLimit);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public boolean markSupported()
/* 198:    */   {
/* 199:205 */     if (this.baseStream == null) {
/* 200:206 */       return false;
/* 201:    */     }
/* 202:207 */     return this.baseStream.markSupported();
/* 203:    */   }
/* 204:    */   
/* 205:    */   public int read(byte[] buffer)
/* 206:    */     throws IOException
/* 207:    */   {
/* 208:213 */     if (this.baseStream == null) {
/* 209:214 */       return -1;
/* 210:    */     }
/* 211:215 */     return this.baseStream.read(buffer);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public int read(byte[] buffer, int offset, int length)
/* 215:    */     throws IOException
/* 216:    */   {
/* 217:221 */     if (this.baseStream == null) {
/* 218:222 */       return -1;
/* 219:    */     }
/* 220:223 */     return this.baseStream.read(buffer, offset, length);
/* 221:    */   }
/* 222:    */   
/* 223:    */   public synchronized void reset()
/* 224:    */     throws IOException
/* 225:    */   {
/* 226:229 */     if (this.baseStream == null) {
/* 227:230 */       return;
/* 228:    */     }
/* 229:231 */     this.baseStream.reset();
/* 230:    */   }
/* 231:    */   
/* 232:    */   public long skip(long byteCount)
/* 233:    */     throws IOException
/* 234:    */   {
/* 235:237 */     if (this.baseStream == null) {
/* 236:238 */       return 0L;
/* 237:    */     }
/* 238:239 */     return this.baseStream.skip(byteCount);
/* 239:    */   }
/* 240:    */   
/* 241:    */   public long getContentLength()
/* 242:    */   {
/* 243:244 */     if (this.baseStream == null) {
/* 244:245 */       return 0L;
/* 245:    */     }
/* 246:246 */     return this.baseResponse.getEntity().getContentLength();
/* 247:    */   }
/* 248:    */ }


/* Location:           E:\docs\1\x-2.6.14-src-1.1-modify.jar
 * Qualified Name:     com.lidroid.xutils.http.ResponseStream
 * JD-Core Version:    0.7.0.1
 */